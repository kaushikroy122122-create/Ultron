# Mimi AI Voice Assistant

See [UPGRADE_README.md](./UPGRADE_README.md) for setup, multi-provider API configuration, Android packaging steps, and known limitations.

This remains the original React + TypeScript + Vite + Express + Gemini project with targeted upgrades; it is not a replacement scaffold.
