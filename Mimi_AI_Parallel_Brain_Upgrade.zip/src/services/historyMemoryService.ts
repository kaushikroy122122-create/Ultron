import { db, handleFirestoreError, OperationType, isPlaceholderConfig } from "./firebaseService";
import { collection, addDoc, getDocs, deleteDoc, doc, updateDoc, serverTimestamp, query, orderBy } from "firebase/firestore";

export interface Memory {
  id: string;
  fact: string;
  category: string;
  timestamp: any;
}

export interface SearchLog {
  id: string;
  query: string;
  timestamp: any;
}

export interface ConversationLog {
  id: string;
  userId: string;
  createdAt: any;
  lastMessage?: string;
}

export interface VoiceLog {
  id: string;
  event: string;
  text?: string;
  duration?: number;
  timestamp: any;
}

export interface CommandLog {
  id: string;
  command: string;
  response: string;
  appName?: string;
  status: "success" | "failed";
  timestamp: any;
}

// Local storage persistent fallback helpers
const getLocalArray = <T>(key: string): T[] => {
  try {
    const val = localStorage.getItem(key);
    return val ? JSON.parse(val) : [];
  } catch (e) {
    return [];
  }
};

const setLocalArray = <T>(key: string, data: T[]): void => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error("Local storage fallback sync error: ", e);
  }
};

export const historyMemoryService = {
  // Save search query
  async saveSearch(userId: string, queryText: string): Promise<void> {
    if (!userId || !queryText?.trim()) return;
    
    if (isPlaceholderConfig) {
      const key = `mimi_searches_${userId}`;
      const searches = getLocalArray<SearchLog>(key);
      searches.unshift({
        id: Math.random().toString(36).substring(7),
        query: queryText.trim(),
        timestamp: new Date().toISOString()
      });
      setLocalArray(key, searches.slice(0, 50));
      return;
    }

    try {
      const searchesRef = collection(db, "users", userId, "searches");
      await addDoc(searchesRef, {
        query: queryText.trim(),
        timestamp: serverTimestamp()
      });
    } catch (error) {
      console.warn("Firestore error, falling back to localStorage for saveSearch:", error);
      const key = `mimi_searches_${userId}`;
      const searches = getLocalArray<SearchLog>(key);
      searches.unshift({
        id: Math.random().toString(36).substring(7),
        query: queryText.trim(),
        timestamp: new Date().toISOString()
      });
      setLocalArray(key, searches.slice(0, 50));
    }
  },

  // Get searches
  async getSearches(userId: string): Promise<SearchLog[]> {
    if (!userId) return [];
    
    if (isPlaceholderConfig) {
      return getLocalArray<SearchLog>(`mimi_searches_${userId}`);
    }

    try {
      const searchesRef = collection(db, "users", userId, "searches");
      const q = query(searchesRef, orderBy("timestamp", "desc"));
      const snap = await getDocs(q);
      return snap.docs.map(doc => ({
        id: doc.id,
        query: doc.data().query,
        timestamp: doc.data().timestamp
      }));
    } catch (error) {
      console.warn("Firestore error, falling back to localStorage for getSearches:", error);
      return getLocalArray<SearchLog>(`mimi_searches_${userId}`);
    }
  },

  // Clear searches
  async clearSearches(userId: string): Promise<void> {
    if (!userId) return;
    
    if (isPlaceholderConfig) {
      setLocalArray(`mimi_searches_${userId}`, []);
      return;
    }

    try {
      const searchesRef = collection(db, "users", userId, "searches");
      const snap = await getDocs(searchesRef);
      const batchPromises = snap.docs.map(d => deleteDoc(doc(db, "users", userId, "searches", d.id)));
      await Promise.all(batchPromises);
    } catch (error) {
      console.warn("Firestore error, falling back to localStorage for clearSearches:", error);
      setLocalArray(`mimi_searches_${userId}`, []);
    }
  },

  // Save long term memory
  async saveMemory(userId: string, fact: string, category: string = "general"): Promise<Memory | null> {
    if (!userId || !fact?.trim()) return null;
    
    if (isPlaceholderConfig) {
      const key = `mimi_memories_${userId}`;
      const memories = getLocalArray<Memory>(key);
      const newMem = {
        id: "mem_" + Math.random().toString(36).substring(7),
        fact: fact.trim(),
        category: category.trim(),
        timestamp: new Date().toISOString()
      };
      memories.unshift(newMem);
      setLocalArray(key, memories);
      return newMem;
    }

    try {
      const memoriesRef = collection(db, "users", userId, "memories");
      const newDoc = await addDoc(memoriesRef, {
        fact: fact.trim(),
        category: category.trim(),
        timestamp: serverTimestamp()
      });
      return {
        id: newDoc.id,
        fact: fact.trim(),
        category: category.trim(),
        timestamp: new Date()
      };
    } catch (error) {
      console.warn("Firestore error, falling back to localStorage for saveMemory:", error);
      const key = `mimi_memories_${userId}`;
      const memories = getLocalArray<Memory>(key);
      const newMem = {
        id: "mem_" + Math.random().toString(36).substring(7),
        fact: fact.trim(),
        category: category.trim(),
        timestamp: new Date().toISOString()
      };
      memories.unshift(newMem);
      setLocalArray(key, memories);
      return newMem;
    }
  },

  // Update memory
  async updateMemory(userId: string, memoryId: string, fact: string, category: string): Promise<void> {
    if (!userId || !memoryId) return;
    
    if (isPlaceholderConfig || memoryId.startsWith("mem_")) {
      const key = `mimi_memories_${userId}`;
      const memories = getLocalArray<Memory>(key);
      const idx = memories.findIndex(m => m.id === memoryId);
      if (idx !== -1) {
        memories[idx] = { 
          ...memories[idx], 
          fact: fact.trim(), 
          category: category.trim(), 
          timestamp: new Date().toISOString() 
        };
        setLocalArray(key, memories);
      }
      return;
    }

    try {
      const memoryRef = doc(db, "users", userId, "memories", memoryId);
      await updateDoc(memoryRef, {
        fact: fact.trim(),
        category: category.trim(),
        timestamp: serverTimestamp()
      });
    } catch (error) {
      console.warn("Firestore error, falling back to localStorage for updateMemory:", error);
      const key = `mimi_memories_${userId}`;
      const memories = getLocalArray<Memory>(key);
      const idx = memories.findIndex(m => m.id === memoryId);
      if (idx !== -1) {
        memories[idx] = { 
          ...memories[idx], 
          fact: fact.trim(), 
          category: category.trim(), 
          timestamp: new Date().toISOString() 
        };
        setLocalArray(key, memories);
      }
    }
  },

  // Delete memory
  async deleteMemory(userId: string, memoryId: string): Promise<void> {
    if (!userId || !memoryId) return;
    
    if (isPlaceholderConfig || memoryId.startsWith("mem_")) {
      const key = `mimi_memories_${userId}`;
      const memories = getLocalArray<Memory>(key);
      setLocalArray(key, memories.filter(m => m.id !== memoryId));
      return;
    }

    try {
      const memoryRef = doc(db, "users", userId, "memories", memoryId);
      await deleteDoc(memoryRef);
    } catch (error) {
      console.warn("Firestore error, falling back to localStorage for deleteMemory:", error);
      const key = `mimi_memories_${userId}`;
      const memories = getLocalArray<Memory>(key);
      setLocalArray(key, memories.filter(m => m.id !== memoryId));
    }
  },

  // Get memories
  async getMemories(userId: string): Promise<Memory[]> {
    if (!userId) return [];
    
    if (isPlaceholderConfig) {
      return getLocalArray<Memory>(`mimi_memories_${userId}`);
    }

    try {
      const memoriesRef = collection(db, "users", userId, "memories");
      const q = query(memoriesRef, orderBy("timestamp", "desc"));
      const snap = await getDocs(q);
      return snap.docs.map(doc => ({
        id: doc.id,
        fact: doc.data().fact,
        category: doc.data().category || "general",
        timestamp: doc.data().timestamp
      }));
    } catch (error) {
      console.warn("Firestore error, falling back to localStorage for getMemories:", error);
      return getLocalArray<Memory>(`mimi_memories_${userId}`);
    }
  },

  // Get all conversations
  async getConversations(userId: string): Promise<ConversationLog[]> {
    if (!userId) return [];
    
    if (isPlaceholderConfig) {
      return getLocalArray<ConversationLog>(`mimi_conversations_${userId}`);
    }

    try {
      const conversationsRef = collection(db, "users", userId, "conversations");
      const q = query(conversationsRef, orderBy("createdAt", "desc"));
      const snap = await getDocs(q);
      return snap.docs.map(doc => ({
        id: doc.id,
        userId: doc.data().userId,
        createdAt: doc.data().createdAt,
        lastMessage: doc.data().lastMessage
      }));
    } catch (error) {
      console.warn("Firestore error, falling back to localStorage for getConversations:", error);
      return getLocalArray<ConversationLog>(`mimi_conversations_${userId}`);
    }
  },

  // Start new conversation
  async startNewConversation(userId: string): Promise<string | null> {
    if (!userId) return null;
    
    if (isPlaceholderConfig) {
      const key = `mimi_conversations_${userId}`;
      const convs = getLocalArray<ConversationLog>(key);
      const newId = "conv_" + Math.random().toString(36).substring(7);
      convs.unshift({
        id: newId,
        userId,
        createdAt: new Date().toISOString(),
        lastMessage: ""
      });
      setLocalArray(key, convs);
      return newId;
    }

    try {
      const conversationsRef = collection(db, "users", userId, "conversations");
      const newConv = await addDoc(conversationsRef, {
        userId,
        createdAt: serverTimestamp()
      });
      return newConv.id;
    } catch (error) {
      console.warn("Firestore error, falling back to localStorage for startNewConversation:", error);
      const key = `mimi_conversations_${userId}`;
      const convs = getLocalArray<ConversationLog>(key);
      const newId = "conv_" + Math.random().toString(36).substring(7);
      convs.unshift({
        id: newId,
        userId,
        createdAt: new Date().toISOString(),
        lastMessage: ""
      });
      setLocalArray(key, convs);
      return newId;
    }
  },

  // Delete conversation
  async deleteConversation(userId: string, conversationId: string): Promise<void> {
    if (!userId || !conversationId) return;
    
    if (isPlaceholderConfig || conversationId.startsWith("conv_")) {
      const key = `mimi_conversations_${userId}`;
      const convs = getLocalArray<ConversationLog>(key);
      setLocalArray(key, convs.filter(c => c.id !== conversationId));
      return;
    }

    try {
      const convRef = doc(db, "users", userId, "conversations", conversationId);
      await deleteDoc(convRef);
    } catch (error) {
      console.warn("Firestore error, falling back to localStorage for deleteConversation:", error);
      const key = `mimi_conversations_${userId}`;
      const convs = getLocalArray<ConversationLog>(key);
      setLocalArray(key, convs.filter(c => c.id !== conversationId));
    }
  },

  // Save voice log
  async saveVoiceLog(userId: string, event: string, text?: string, duration?: number): Promise<void> {
    if (!userId || !event?.trim()) return;
    
    if (isPlaceholderConfig) {
      const key = `mimi_voice_logs_${userId}`;
      const logs = getLocalArray<VoiceLog>(key);
      logs.unshift({
        id: Math.random().toString(36).substring(7),
        event: event.trim(),
        text: text?.trim() || "",
        duration: duration || 0,
        timestamp: new Date().toISOString()
      });
      setLocalArray(key, logs.slice(0, 100));
      return;
    }

    try {
      const logsRef = collection(db, "users", userId, "voice_logs");
      await addDoc(logsRef, {
        event: event.trim(),
        text: text?.trim() || "",
        duration: duration || 0,
        timestamp: serverTimestamp()
      });
    } catch (error) {
      console.warn("Firestore error, falling back to localStorage for saveVoiceLog:", error);
      const key = `mimi_voice_logs_${userId}`;
      const logs = getLocalArray<VoiceLog>(key);
      logs.unshift({
        id: Math.random().toString(36).substring(7),
        event: event.trim(),
        text: text?.trim() || "",
        duration: duration || 0,
        timestamp: new Date().toISOString()
      });
      setLocalArray(key, logs.slice(0, 100));
    }
  },

  // Get voice logs
  async getVoiceLogs(userId: string): Promise<VoiceLog[]> {
    if (!userId) return [];
    
    if (isPlaceholderConfig) {
      return getLocalArray<VoiceLog>(`mimi_voice_logs_${userId}`);
    }

    try {
      const logsRef = collection(db, "users", userId, "voice_logs");
      const q = query(logsRef, orderBy("timestamp", "desc"));
      const snap = await getDocs(q);
      return snap.docs.map(doc => ({
        id: doc.id,
        event: doc.data().event,
        text: doc.data().text || "",
        duration: doc.data().duration || 0,
        timestamp: doc.data().timestamp
      }));
    } catch (error) {
      console.warn("Firestore error, falling back to localStorage for getVoiceLogs:", error);
      return getLocalArray<VoiceLog>(`mimi_voice_logs_${userId}`);
    }
  },

  // Clear voice logs
  async clearVoiceLogs(userId: string): Promise<void> {
    if (!userId) return;
    
    if (isPlaceholderConfig) {
      setLocalArray(`mimi_voice_logs_${userId}`, []);
      return;
    }

    try {
      const logsRef = collection(db, "users", userId, "voice_logs");
      const snap = await getDocs(logsRef);
      const batchPromises = snap.docs.map(d => deleteDoc(doc(db, "users", userId, "voice_logs", d.id)));
      await Promise.all(batchPromises);
    } catch (error) {
      console.warn("Firestore error, falling back to localStorage for clearVoiceLogs:", error);
      setLocalArray(`mimi_voice_logs_${userId}`, []);
    }
  },

  // Save command log
  async saveCommandLog(userId: string, command: string, response: string, appName?: string, status: "success" | "failed" = "success"): Promise<void> {
    if (!userId || !command?.trim()) return;
    
    if (isPlaceholderConfig) {
      const key = `mimi_commands_${userId}`;
      const logs = getLocalArray<CommandLog>(key);
      logs.unshift({
        id: Math.random().toString(36).substring(7),
        command: command.trim(),
        response: response?.trim() || "",
        appName: appName?.trim() || "System",
        status,
        timestamp: new Date().toISOString()
      });
      setLocalArray(key, logs.slice(0, 100));
      return;
    }

    try {
      const logsRef = collection(db, "users", userId, "commands");
      await addDoc(logsRef, {
        command: command.trim(),
        response: response?.trim() || "",
        appName: appName?.trim() || "System",
        status,
        timestamp: serverTimestamp()
      });
    } catch (error) {
      console.warn("Firestore error, falling back to localStorage for saveCommandLog:", error);
      const key = `mimi_commands_${userId}`;
      const logs = getLocalArray<CommandLog>(key);
      logs.unshift({
        id: Math.random().toString(36).substring(7),
        command: command.trim(),
        response: response?.trim() || "",
        appName: appName?.trim() || "System",
        status,
        timestamp: new Date().toISOString()
      });
      setLocalArray(key, logs.slice(0, 100));
    }
  },

  // Get command logs
  async getCommandLogs(userId: string): Promise<CommandLog[]> {
    if (!userId) return [];
    
    if (isPlaceholderConfig) {
      return getLocalArray<CommandLog>(`mimi_commands_${userId}`);
    }

    try {
      const logsRef = collection(db, "users", userId, "commands");
      const q = query(logsRef, orderBy("timestamp", "desc"));
      const snap = await getDocs(q);
      return snap.docs.map(doc => ({
        id: doc.id,
        command: doc.data().command,
        response: doc.data().response || "",
        appName: doc.data().appName || "System",
        status: doc.data().status || "success",
        timestamp: doc.data().timestamp
      }));
    } catch (error) {
      console.warn("Firestore error, falling back to localStorage for getCommandLogs:", error);
      return getLocalArray<CommandLog>(`mimi_commands_${userId}`);
    }
  },

  // Clear command logs
  async clearCommandLogs(userId: string): Promise<void> {
    if (!userId) return;
    
    if (isPlaceholderConfig) {
      setLocalArray(`mimi_commands_${userId}`, []);
      return;
    }

    try {
      const logsRef = collection(db, "users", userId, "commands");
      const snap = await getDocs(logsRef);
      const batchPromises = snap.docs.map(d => deleteDoc(doc(db, "users", userId, "commands", d.id)));
      await Promise.all(batchPromises);
    } catch (error) {
      console.warn("Firestore error, falling back to localStorage for clearCommandLogs:", error);
      setLocalArray(`mimi_commands_${userId}`, []);
    }
  }
};
