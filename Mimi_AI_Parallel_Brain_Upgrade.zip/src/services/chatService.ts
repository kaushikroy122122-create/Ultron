export interface ChatSpace {
  name: string; // e.g. "spaces/AAAAAAA"
  displayName?: string;
  spaceType?: "SPACE" | "DIRECT_MESSAGE" | "GROUP_CHAT";
  singleUserBotDm?: boolean;
}

export interface ChatMessage {
  name: string; // e.g. "spaces/AAAAAAA/messages/BBBBBBB"
  sender: {
    name: string;
    displayName: string;
    avatarUrl?: string;
    type?: "HUMAN" | "BOT";
  };
  text: string;
  createTime: string;
}

export async function listChatSpaces(accessToken: string): Promise<ChatSpace[]> {
  const url = 'https://chat.googleapis.com/v1/spaces?pageSize=100';
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to fetch Google Chat Spaces: ${res.statusText}`);
  }
  const data = await res.json();
  return data.spaces || [];
}

export async function listChatMessages(accessToken: string, spaceName: string): Promise<ChatMessage[]> {
  // spaceName is of format "spaces/XXXXXX"
  const url = `https://chat.googleapis.com/v1/${spaceName}/messages?pageSize=50`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to retrieve chat messages: ${res.statusText}`);
  }
  const data = await res.json();
  // Messages are usually returned in chronological order or sorted. Let's return them as they are
  return data.messages || [];
}

export async function sendChatMessage(accessToken: string, spaceName: string, text: string): Promise<ChatMessage> {
  const url = `https://chat.googleapis.com/v1/${spaceName}/messages`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ text })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to send Google Chat message: ${res.statusText}`);
  }
  return await res.json();
}
