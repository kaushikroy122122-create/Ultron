export interface GoogleContact {
  resourceName: string; // e.g., "people/c12345"
  etag: string;
  name?: string;
  email?: string;
  phone?: string;
  avatarUrl?: string;
}

export async function listGoogleContacts(accessToken: string): Promise<GoogleContact[]> {
  const url = 'https://people.googleapis.com/v1/people/me/connections?personFields=names,emailAddresses,phoneNumbers,photos&pageSize=100';
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to fetch Google Contacts: ${res.statusText}`);
  }
  const data = await res.json();
  const connections = data.connections || [];
  
  return connections.map((conn: any) => {
    const nameObj = conn.names?.[0];
    const emailObj = conn.emailAddresses?.[0];
    const phoneObj = conn.phoneNumbers?.[0];
    const photoObj = conn.photos?.[0];
    
    return {
      resourceName: conn.resourceName,
      etag: conn.etag,
      name: nameObj?.displayName || nameObj?.unstructuredName || "Unnamed Contact",
      email: emailObj?.value || "",
      phone: phoneObj?.value || "",
      avatarUrl: photoObj?.url || ""
    };
  });
}

export async function createGoogleContact(
  accessToken: string,
  contact: { givenName: string; familyName: string; email?: string; phone?: string }
): Promise<GoogleContact> {
  const url = 'https://people.googleapis.com/v1/people:createContact';
  
  const body: any = {
    names: [{ givenName: contact.givenName, familyName: contact.familyName }]
  };
  
  if (contact.email) {
    body.emailAddresses = [{ value: contact.email }];
  }
  if (contact.phone) {
    body.phoneNumbers = [{ value: contact.phone }];
  }

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to create contact: ${res.statusText}`);
  }
  
  const conn = await res.json();
  const nameObj = conn.names?.[0];
  const emailObj = conn.emailAddresses?.[0];
  const phoneObj = conn.phoneNumbers?.[0];
  const photoObj = conn.photos?.[0];
  
  return {
    resourceName: conn.resourceName,
    etag: conn.etag,
    name: nameObj?.displayName || "Unnamed Contact",
    email: emailObj?.value || "",
    phone: phoneObj?.value || "",
    avatarUrl: photoObj?.url || ""
  };
}

export async function deleteGoogleContact(accessToken: string, resourceName: string): Promise<void> {
  // resourceName is usually formatted like "people/cXXXXXXXX"
  const url = `https://people.googleapis.com/v1/${resourceName}:deleteContact`;
  const res = await fetch(url, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to delete contact: ${res.statusText}`);
  }
}
