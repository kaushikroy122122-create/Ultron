export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  webViewLink?: string;
  iconLink?: string;
  modifiedTime: string;
}

export async function listDriveFiles(accessToken: string, queryText?: string): Promise<DriveFile[]> {
  let url = 'https://www.googleapis.com/drive/v3/files?fields=files(id, name, mimeType, size, webViewLink, iconLink, modifiedTime)&pageSize=35&orderBy=modifiedTime desc';
  
  const queryParts = ["trashed = false"];
  if (queryText) {
    const escapedQuery = queryText.replace(/'/g, "\\'");
    queryParts.push(`name contains '${escapedQuery}'`);
  }
  
  url += `&q=${encodeURIComponent(queryParts.join(" and "))}`;
  
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Drive search failed: ${res.statusText}`);
  }
  const data = await res.json();
  return data.files || [];
}

export async function uploadDriveFile(accessToken: string, name: string, mimeType: string, content: string | Blob): Promise<DriveFile> {
  // 1. Create file with metadata
  const metadataRes = await fetch('https://www.googleapis.com/drive/v3/files', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ name, mimeType })
  });
  if (!metadataRes.ok) {
    const err = await metadataRes.json().catch(() => ({}));
    throw new Error(err.error?.message || `Drive metadata init failed: ${metadataRes.statusText}`);
  }
  const fileInfo = await metadataRes.json();
  const fileId = fileInfo.id;

  // 2. Patch with core media stream
  const uploadRes = await fetch(`https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=media`, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': mimeType
    },
    body: content
  });
  if (!uploadRes.ok) {
    const err = await uploadRes.json().catch(() => ({}));
    throw new Error(err.error?.message || `Drive media content upload failed: ${uploadRes.statusText}`);
  }
  return await uploadRes.json();
}

export async function deleteDriveFile(accessToken: string, fileId: string): Promise<void> {
  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Drive removal operation failed: ${res.statusText}`);
  }
}
