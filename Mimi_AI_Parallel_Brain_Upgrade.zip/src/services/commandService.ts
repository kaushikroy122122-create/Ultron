export interface CommandResult {
  action: string;
  url?: string;
  urlType?: "youtube" | "google" | "whatsapp" | "generic";
  query?: string;
  isBrowserAction: boolean;
  appName?: string;
  whatsappMessage?: string;
  whatsappPhone?: string;
  whatsappRecipient?: string;
}

export function processCommand(command: string, customSites: { id: string; name: string; url: string }[] = []): CommandResult {
  const lowerCmd = command.toLowerCase().trim();

  // ==========================================
  // WHATSAPP (MESSAGING / WHATSAPP ACCESS)
  // ==========================================
  // Matches english: "send a whatsapp message to [recipient] saying [message]"
  // Matches Bengali: "হোয়াটসঅ্যাপে [recipient] কে মেসেজ করো [message]" or "হোয়াটসঅ্যাপে [recipient] কে বলো [message]"
  const waEnMatch = lowerCmd.match(
    /^send\s+(?:a\s+)?whatsapp\s+(?:message\s+)?to\s+(.+?)\s+saying\s+(.+)$/
  );
  
  const waBnMatch1 = lowerCmd.match(
    /wh?at?sapp?e?\s+(.+?)\s+ke\s+(?:message|sms|মেসেজ|এসএমএস|বলো)\s+(.+)/
  ) || lowerCmd.match(
    /হোয়াটসঅ্যাপে?\s+(.+?)\s+কে\s+(?:মেসেজ|এসএমএস|বলো)\s+(.+)/
  );

  const waBnMatch2 = lowerCmd.match(
    /wh?at?sapp?e?\s+(.+?)\s+কে\s+(.+?)\s+(?:মেসেজ|এসএমএস|পাঠাও|সেন্ড করো)/
  ) || lowerCmd.match(
    /হোয়াটসঅ্যাপে?\s+(.+?)\s+কে\s+(.+?)\s+(?:মেসেজ|এসএমএস|পাঠাও|সেন্ড করো)/
  );

  if (waEnMatch || waBnMatch1 || waBnMatch2) {
    let recipient = "";
    let message = "";

    if (waEnMatch) {
      recipient = waEnMatch[1].trim();
      message = waEnMatch[2].trim();
    } else if (waBnMatch1) {
      recipient = waBnMatch1[1].trim();
      message = waBnMatch1[2].trim();
    } else if (waBnMatch2) {
      recipient = waBnMatch2[1].trim();
      message = waBnMatch2[2].trim();
    }

    // Clean recipient (e.g. "kaushik", "+88017...", "roy")
    const cleanPhone = recipient.replace(/[\s\-\(\)]/g, "");
    const isPhoneNumber = /^\+?\d+$/.test(cleanPhone) && cleanPhone.length >= 8;
    const phone = isPhoneNumber ? cleanPhone : "";

    return {
      action: `Sending WhatsApp message to ${recipient} saying "${message}"`,
      url: `https://web.whatsapp.com/send?phone=${phone || "123456"}&text=${encodeURIComponent(message)}`,
      urlType: "whatsapp",
      isBrowserAction: true,
      appName: "WhatsApp",
      whatsappRecipient: recipient,
      whatsappPhone: phone,
      whatsappMessage: message
    };
  }

  // Catch generic WhatsApp open
  if (
    lowerCmd.includes("open whatsapp") || 
    lowerCmd.includes("whatsapp access") || 
    lowerCmd.includes("হোয়াটসঅ্যাপ")
  ) {
    return {
      action: "Opening WhatsApp Web. Ready to send messages.",
      url: "https://web.whatsapp.com",
      urlType: "whatsapp",
      isBrowserAction: true,
      appName: "WhatsApp",
      whatsappRecipient: "Kaushik Roy",
      whatsappMessage: "Hi, how are you?"
    };
  }

  // ==========================================
  // GOOGLE ECOSYSTEM ACCESS HANDLERS
  // ==========================================
  const lowerOpenPattern = lowerCmd.replace(/^(open|খোল|খোলো|লঞ্চ করো|গো টু|go to|আমাকে দেখাও)\s+/g, "").trim();

  if (
    lowerCmd.includes("gmail") ||
    lowerCmd.includes("mail.google") ||
    lowerOpenPattern === "gmail" ||
    lowerOpenPattern === "জিমেইল" ||
    lowerOpenPattern === "মেইল"
  ) {
    return {
      action: "Opening Gmail Inbox node...",
      url: "https://mail.google.com",
      urlType: "generic",
      isBrowserAction: true,
      appName: "Gmail"
    };
  }

  if (
    lowerCmd.includes("google drive") ||
    lowerCmd.includes("drive.google") ||
    lowerOpenPattern === "drive" ||
    lowerOpenPattern === "গুগল ড্রাইভ" ||
    lowerOpenPattern === "ড্রাইভ"
  ) {
    return {
      action: "Opening Google Drive Cloud storage...",
      url: "https://drive.google.com",
      urlType: "generic",
      isBrowserAction: true,
      appName: "Google Drive"
    };
  }

  if (
    lowerCmd.includes("google photos") ||
    lowerCmd.includes("photos.google") ||
    lowerOpenPattern === "photos" ||
    lowerOpenPattern === "গুগল ফটোস" ||
    lowerOpenPattern === "ফটোস" ||
    lowerOpenPattern === "ফটো"
  ) {
    return {
      action: "Opening Google Photos gallery...",
      url: "https://photos.google.com",
      urlType: "generic",
      isBrowserAction: true,
      appName: "Google Photos"
    };
  }

  if (
    lowerCmd.includes("google docs") ||
    lowerCmd.includes("docs.google") ||
    lowerOpenPattern === "docs" ||
    lowerOpenPattern === "গুগল ডকস" ||
    lowerOpenPattern === "ডকস" ||
    lowerOpenPattern === "ডকুমেন্ট"
  ) {
    return {
      action: "Opening Google Docs document hub...",
      url: "https://docs.google.com",
      urlType: "generic",
      isBrowserAction: true,
      appName: "Google Docs"
    };
  }

  if (
    lowerCmd.includes("google sheets") ||
    lowerCmd.includes("sheets.google") ||
    lowerOpenPattern === "sheets" ||
    lowerOpenPattern === "গুগল শীটস" ||
    lowerOpenPattern === "শীটস" ||
    lowerOpenPattern === "স্প্রেডশীট"
  ) {
    return {
      action: "Opening Google Sheets spreadsheets...",
      url: "https://sheets.google.com",
      urlType: "generic",
      isBrowserAction: true,
      appName: "Google Sheets"
    };
  }

  if (
    lowerCmd.includes("google maps") ||
    lowerCmd.includes("maps.google") ||
    lowerOpenPattern === "maps" ||
    lowerOpenPattern === "ম্যাপস" ||
    lowerOpenPattern === "ম্যাপ" ||
    lowerOpenPattern === "গুগল ম্যাপ"
  ) {
    return {
      action: "Opening Google Maps navigation...",
      url: "https://maps.google.com",
      urlType: "generic",
      isBrowserAction: true,
      appName: "Google Maps"
    };
  }

  if (
    lowerCmd.includes("google calendar") ||
    lowerCmd.includes("calendar.google") ||
    lowerOpenPattern === "calendar" ||
    lowerOpenPattern === "গুগল ক্যালেন্ডার" ||
    lowerOpenPattern === "ক্যালেন্ডার"
  ) {
    return {
      action: "Opening Google Calendar scheduler...",
      url: "https://calendar.google.com",
      urlType: "generic",
      isBrowserAction: true,
      appName: "Google Calendar"
    };
  }

  if (
    lowerCmd.includes("google contacts") ||
    lowerCmd.includes("contacts.google") ||
    lowerOpenPattern === "contacts" ||
    lowerOpenPattern === "গুগল কন্টাক্টস" ||
    lowerOpenPattern === "কন্টাক্টস" ||
    lowerOpenPattern === "যোগাযোগকারী"
  ) {
    return {
      action: "Opening Google Contacts manager...",
      url: "https://contacts.google.com",
      urlType: "generic",
      isBrowserAction: true,
      appName: "Google Contacts"
    };
  }

  // ==========================================
  // YOUTUBE (SONG PLAYBACK & SEARCH)
  // ==========================================
  // Comprehensive music, lyrics, recording artist and play intent detection supporting English and Bengali
  const musicKeywords = [
    "song", "music", "play", "listen", "sing", "singer", "lyrics", "youtube", "yt", "playlist", "album", 
    "গান", "মিউজিক", "প্লে", "শোনাও", "চালাও", "শুনবো", "বাজাও", "ইউটিউব", "ইউটিউবে", "ভিডিও", "ভিডিয়ো", "গায়ক", 
    "গায়িকা", "শিল্পী", "লিরিক্স", "সুর", "রবীন্দ্রসংগীত", "নজরুলগীতি", "সঙ্গীত", "সংগীত", "কথা", "শুনতে চাই",
    "বাজিয়ে দাও", "বাজিয়ে দাও", "চলুক", "চাইতেছি", "শুনতে চাও"
  ];

  const singerKeywords = [
    "arijit", "shreya", "kishore", "lata", "asha", "sonu", "kumar sanu", "alka", "anupam roy", "manna dey",
    "hemanta", "geeta dutt", "zubeen", "darshan", "atif", "jubin", "armaan", "papon", "raftaar", "badshah",
    "অরিজিৎ", "শ্রেয়া", "কিশোর", "লতা", "আশা", "সোনু", "কুমার শানু", "আলকা", "মান্না দে", "হেমন্ত", "অনুপম", 
    "রূপম", "নচিকেতা", "কবীর সুমন", "শ্রেয়া ঘোষাল", "সোমু", "আতিফ", "জুবিন"
  ];

  const containsMusicKeyword = musicKeywords.some(kw => lowerCmd.includes(kw));
  const containsSingerKeyword = singerKeywords.some(kw => lowerCmd.includes(kw));

  const isMusicIntent = containsMusicKeyword || containsSingerKeyword;

  if (isMusicIntent) {
    let query = lowerCmd;
    
    // 1. First clean standard wrapping phrasing
    query = query.replace(/^(আমি|আমরা|তুমি|দয়া করে|দয়া করে|একটু|প্লিজ|please|kindly)\s+/gi, "");
    query = query.replace(/\s+(শুনতে চাই|শুনিয়ে দাও|শুনিয়ে দাও|শোনাও|চালাও|বাজাও|চালিয়ে দাও|চলুক|শুনবো|খুঁজে দাও|সার্চ করো|খোল|খোলো|লঞ্চ করো)$/gi, "");
    
    // 2. Clean browser/search references
    query = query.replace(/^(youtube|youtube-e|on youtube|chrome|chrome-e|google|google-e|search|play|ইউটিউব|ইউটিউবে|ইউটিউব এ|গুগল|গুগলে|গুগল এ|ক্রোম|ক্রোমে|ক্রোম এ|অন ইউটিউব|অন গুগল|অন ক্রোম|ক্রোমের মাধ্যমে|ক্রোম থেকে|গুগলের মাধ্যমে|গুগল থেকে)\s+/gi, "");
    query = query.replace(/\s+(youtube|on youtube|chrome|google|ইউটিউবে|গুগলে|ক্রোমে|ইউটিউব চালিয়ে|গুগল থেকে|ক্রোম থেকে|সার্চ করে|গুগল ক্রোম থেকে|মাধ্যমে)$/gi, "");
    
    // 3. Clean music references at boundary
    query = query.replace(/^(play|listen to|search for|find|শোনাও|চালাও|বাজাও|গান শোনাও|গান চালাও|গান বাজাও|প্লে করো)\s+/gi, "");
    query = query.replace(/\s+(গান|মিউজিক|ভিডিও|ভিডিয়ো|লিরিক্স|লিলিক্স|লিরিক|কথা|সুর|গান শোনাও|গান চালাও|গান বাজাও|প্লে করো|প্লে|মিউজিক প্লে)$/gi, "");
    
    // 4. Clean trailing connectors
    query = query.replace(/\s+(এর|আর|র|একটি|একটা|কোনো|কোন)$/gi, "");
    query = query.trim();

    // Fallback if details got fully wiped
    if (!query || query === "music" || query === "song" || query === "গান" || query === "মিউজিক" || query === "ভিডিও" || query === "youtube") {
      query = "Arijit Singh Bengali popular hit songs";
    }

    const friendlyBengaliResponse = `আমি গুগল ক্রোম ও ইউটিউব ইন্টিগ্রেশন ব্যবস্থার মাধ্যমে আপনার জন্য "${query}" গানটি অনুসন্ধান করে সরাসরি প্লেয়ারে চালু করছি। উপভোগ করুন!`;

    return {
      action: friendlyBengaliResponse,
      url: `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`,
      urlType: "youtube",
      query: query,
      isBrowserAction: true,
      appName: "YouTube"
    };
  }

  // ==========================================
  // CUSTOM SITES SEARCH AND OPENING
  // ==========================================
  if (customSites && customSites.length > 0) {
    for (const site of customSites) {
      const siteNameLower = site.name.toLowerCase();
      
      // Direct opening match e.g. "open wikipedia", "wikipedia খোল", "wikipedia খোলো"
      const isOpenCommand = 
        lowerCmd.includes(`open ${siteNameLower}`) ||
        lowerCmd.includes(`${siteNameLower} open`) ||
        lowerCmd.includes(`${siteNameLower} খোল`) ||
        lowerCmd.includes(`${siteNameLower} খোলো`) ||
        lowerCmd.includes(`খোল ${siteNameLower}`) ||
        lowerCmd.includes(`খোলো ${siteNameLower}`);
        
      if (isOpenCommand || lowerCmd === siteNameLower) {
        let cleanUrl = site.url;
        if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
          cleanUrl = "https://" + cleanUrl;
        }
        return {
          action: `Opening custom site ${site.name}`,
          url: cleanUrl,
          urlType: "generic",
          isBrowserAction: true,
          appName: site.name
        };
      }

      if (lowerCmd.includes(siteNameLower)) {
        // extract the query
        // e.g. "search [query] on [sitename]" or "[sitename] e [query] jante chai"
        let query = lowerCmd.replace(siteNameLower, "").trim();
        query = query.replace(/^(google|search|find|সার্চ|সার্চ করো|খুঁজো|জানতে চাই|খুঁজে দাও|on|in|থেকে|তে|এ)\s+/gi, "");
        query = query.replace(/\s+(on google|google|সার্চ করো|খুঁজে দাও|জানতে চাই|খোঁজো|থেকে|তে|এ)$/gi, "");
        query = query.trim();

        if (query) {
          const finalSearch = `site:${site.url} ${query}`;
          return {
            action: `Searching for "${query}" on ${site.name}`,
            url: `https://www.google.com/search?q=${encodeURIComponent(finalSearch)}`,
            urlType: "google",
            query: finalSearch,
            isBrowserAction: true,
            appName: site.name
          };
        }
      }
    }
  }

  // ==========================================
  // SYSTEM UPGRADE / FAKE HACKING
  // ==========================================
  if (
    lowerCmd.includes("update system") || 
    lowerCmd.includes("upgrade system") ||
    lowerCmd.includes("audio coding upgrade") ||
    lowerCmd.includes("upgrade all system")
  ) {
    return {
      action: "Initiating advanced system and audio coding upgrade...",
      urlType: "generic",
      isBrowserAction: false,
      appName: "System Upgrade"
    };
  }

  // ==========================================
  // GOOGLE SEARCH (CHROME / BROWSING)
  // ==========================================
  // English: "search [query] on google", "search [query]", "find [query]", "google [query]"
  // Bengali: "সার্চ করো [query]", "গুগলে [query] সার্চ করো", "জানতে চাই [query]"
  const googleSearchEn =
    lowerCmd.match(/^search\s+(?:for\s+)?(.+)$/) ||
    lowerCmd.match(/^google\s+(.+)$/) ||
    lowerCmd.match(/^find\s+(.+)$/);

  const googleSearchBn =
    lowerCmd.match(/^(?:গুগল|গুগলে|সার্চ|সার্চ করো|খুঁজো)\s+(.+)$/) ||
    lowerCmd.match(/^(.+?)\s+(?:সার্চ করো|খুঁজে দাও|জানতে চাই|গুগলে খোঁজো)$/);

  if (googleSearchEn || googleSearchBn) {
    let query = "";
    if (googleSearchEn) {
      query = googleSearchEn[1].trim();
    } else if (googleSearchBn) {
      query = googleSearchBn[1].trim();
    }

    // Strip words
    query = query.replace(/^(google|search|find|গুগল|গুগলে|সার্চ|সার্চ করো|খুঁজো|জানতে চাই|খুঁজে দাও)\s+/gi, "");
    query = query.replace(/\s+(on google|google|সার্চ করো|খুঁজে দাও|জানতে চাই|গুগলে খোঁজো)$/gi, "");

    return {
      action: `Searching "${query}" on Google`,
      url: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
      urlType: "google",
      query: query,
      isBrowserAction: true,
      appName: "Google Chrome"
    };
  }

  // ==========================================
  // OPEN SPECIFIC WEBSITES
  // ==========================================
  const openMatch = lowerCmd.match(/^open\s+(.+)$/) || lowerCmd.match(/^খোল\s+(.+)$/) || lowerCmd.match(/^খোলো\s+(.+)$/);
  if (openMatch) {
    let website = openMatch[1].trim().replace(/\s+/g, "");

    if (website === "whatsapp" || website === "হোয়াটসঅ্যাপ") {
      return {
        action: "Opening WhatsApp Web dashboard...",
        url: "https://web.whatsapp.com",
        urlType: "whatsapp",
        isBrowserAction: true,
        appName: "WhatsApp"
      };
    }

    if (website === "google" || website === "ক্রম" || website === "chrome") {
      return {
        action: "Opening Google search node...",
        url: "https://www.google.com",
        urlType: "google",
        query: "Google Search",
        isBrowserAction: true,
        appName: "Google Chrome"
      };
    }

    if (!website.includes(".")) {
      website += ".com";
    }

    return {
      action: `Opening ${openMatch[1]} in virtual Chrome`,
      url: `https://www.${website}`,
      urlType: "generic",
      isBrowserAction: true,
      appName: "Google Chrome"
    };
  }

  // Browser Info News
  if (
    lowerCmd.includes("news") || 
    lowerCmd.includes("খবর") || 
    lowerCmd.includes("সংবাদ")
  ) {
    return {
      action: "Opening Google News headlines",
      url: "https://news.google.com",
      urlType: "google",
      query: "Top news headlines",
      isBrowserAction: true,
      appName: "Google News"
    };
  }

  // Browser Info Weather
  if (
    lowerCmd.includes("weather") || 
    lowerCmd.includes("আবহাওয়া") || 
    lowerCmd.includes("আবহাওয়া")
  ) {
    return {
      action: "Opening current weather forecast",
      url: "https://weather.com",
      urlType: "google",
      query: "Current weather report",
      isBrowserAction: true,
      appName: "Weather"
    };
  }

  return {
    action: "",
    isBrowserAction: false
  };
}