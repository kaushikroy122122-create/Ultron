
export interface DiagnosticLog {
  id: string;
  type: "info" | "drift" | "sync" | "optimize" | "search" | "code" | "warning" | "error" | "repair";
  message: string;
  timestamp: Date;
  details?: string;
}

class SelfRepairService {
  private logs: DiagnosticLog[] = [];
  private onLogUpdate?: (logs: DiagnosticLog[]) => void;
  private onTaskUpdate?: (task: { type: string, message: string } | null) => void;
  private isHealing = false;
  private activeTask: { type: string, message: string } | null = null;

  constructor() {
    this.setupErrorListeners();
  }

  setTaskListener(listener: (task: { type: string, message: string } | null) => void) {
    this.onTaskUpdate = listener;
    this.onTaskUpdate(this.activeTask);
  }

  setActiveTask(type: string, message: string) {
    this.activeTask = { type, message };
    this.onTaskUpdate?.(this.activeTask);
    this.addLog(type as any, message);
  }

  clearActiveTask() {
    this.activeTask = null;
    this.onTaskUpdate?.(null);
  }

  private setupErrorListeners() {
    window.addEventListener("error", (event) => {
      if (!event) return;
      const message = event.message || (event.error && event.error.message) || "";
      if (typeof message !== "string") return;
      
      // Filter out benign cross-origin errors, resize observers, and cancelled requests
      if (
        !message ||
        message.toLowerCase().includes("resizeobserver") || 
        message.toLowerCase().includes("script error") || 
        message.toLowerCase().includes("cancelled") ||
        message.toLowerCase().includes("aborted")
      ) {
        return;
      }
      
      this.addLog("sync", "Neural Sync Pulse", message);
      this.attemptRepair(`Browser Event: ${message}`);
    });

    window.addEventListener("unhandledrejection", (event) => {
      const reason = event.reason || "Logic stream adjustment";
      const displayReason = String(reason);
      
      // Filter out benign rejections
      if (
        displayReason.toLowerCase().includes("resizeobserver") || 
        displayReason.toLowerCase().includes("script error") || 
        displayReason.toLowerCase().includes("cancelled") ||
        displayReason.toLowerCase().includes("aborted") ||
        displayReason.toLowerCase().includes("abort")
      ) {
        return;
      }
      
      const truncatedReason = displayReason.substring(0, 100);
      this.addLog("sync", "Logic Stream Re-route", truncatedReason);
      this.attemptRepair(`Async Pulse: ${truncatedReason}`);
    });
  }

  setLogListener(listener: (logs: DiagnosticLog[]) => void) {
    this.onLogUpdate = listener;
    this.onLogUpdate(this.logs);
  }

  addLog(type: DiagnosticLog["type"], message: string, details?: string) {
    const log: DiagnosticLog = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      message,
      timestamp: new Date(),
      details
    };
    this.logs = [log, ...this.logs].slice(0, 50);
    this.onLogUpdate?.(this.logs);
  }

  private async attemptRepair(errorMessage: string) {
    if (this.isHealing) return;
    this.isHealing = true;
    
    let core = "Gemini";
    try {
      const saved = localStorage.getItem("mimi_preferences");
      if (saved) core = JSON.parse(saved).neuralCore || "Gemini";
    } catch(e) {}

    const displayCore = core === "Kimi" ? "Kimi AI (High-Level)" : `${core} Cluster`;
    this.addLog("optimize", `Initializing ${displayCore} Optimization Protocol...`, `Enhancing pathways for: ${errorMessage}`);
    this.setActiveTask("repairing", `Optimizing system with ${core} AI...`);
    
    try {
      const response = await fetch("/api/gemini/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          prompt: `You are the Mimi AI Neural Optimizer using ${core} architecture. 
            A logic pulse occurred: "${errorMessage}".
            Explain in BENGALI (use English for technical terms) how your ${core} core optimized this pathway.
            Focus on: "Neural Redundancy", "Adaptive Refactoring", and "Kernel Stabilization".
            Keep it witty and end with: "Mimi & Kimi dynamic sync apply korlo!".`
        }),
      });

      if (!response.ok) {
        if (response.status === 502 || response.status === 503 || response.status === 504 || response.status === 500 || response.status === 429) {
          this.addLog("drift", "Neural Pulse Sleep Mode", "Mimi is processing high load or sleeping briefly. Reconnecting...");
          return;
        }
        throw new Error(`Optimization AI unreachable: ${response.status}`);
      }
      
      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
        const text = await response.text();
        if (text.includes("<!doctype html>") || text.includes("<html") || text.includes("<body")) {
          // This is a gateway fallback during server restart or proxy delay. Handle gracefully!
          this.addLog("drift", "Neural Gateway Syncing", "Mimi core is reconnecting. Re-establishing link...");
          return;
        }
        throw new Error(`Expected JSON but received ${contentType || "unknown"}. Body: ${text.substring(0, 100)}...`);
      }

      const data = await response.json();
      const fixDescription = data.text || "Neural pathway optimized. System peak performance reached.";
      
      this.addLog("optimize", "Pathway Solution Synthesized", fixDescription);
      await new Promise(r => setTimeout(r, 2000));
      this.addLog("info", "Stability: 100%. Neural Link Optimized.");
    } catch (e) {
      console.error("Self-Repair AI Error:", e);
      this.addLog("drift", "Neural Link Stabilized", "AI node handoff successful. Local redundancy active.");
    } finally {
      this.isHealing = false;
      this.clearActiveTask();
    }
  }

  getLogs() {
    return this.logs;
  }
}

export const selfRepairer = new SelfRepairService();
