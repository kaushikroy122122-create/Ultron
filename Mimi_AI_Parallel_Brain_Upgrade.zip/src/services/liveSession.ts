import { AudioStreamer } from "./audioStreamer";

export type LiveSessionState = "connecting" | "listening" | "thinking" | "speaking";

export interface LiveDebugTelemetry {
  wsStatus: "disconnected" | "connecting" | "open" | "reconnecting" | "error";
  micActive: boolean;
  chunksSent: number;
  chunksReceived: number;
  state: LiveSessionState | "idle";
  lastError: string | null;
  reconnectAttempt: number;
  maxReconnectAttempts: number;
}

const RECONNECT_DELAYS_MS = [1000, 2000, 4000, 8000, 16000];
const MAX_RECONNECT_ATTEMPTS = 5;
const FALLBACK_RECOGNITION_COOLDOWN_MS = 4000;

const PCM_WORKLET_CODE = `
class Pcm16CaptureProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this._buffer = [];
    this._phase = 0;
    this._lastSample = 0;
    this._targetRate = 16000;
    this._chunkSamples = 960; // 60ms at 16kHz
  }

  process(inputs) {
    const input = inputs[0];
    if (!input || !input[0] || input[0].length === 0) {
      return true;
    }

    const channel = input[0];
    const ratio = sampleRate / this._targetRate;

    if (ratio <= 1.001 && ratio >= 0.999) {
      for (let i = 0; i < channel.length; i++) {
        this._buffer.push(channel[i]);
      }
    } else {
      let pos = this._phase;
      while (pos < channel.length) {
        const idx = Math.floor(pos);
        const frac = pos - idx;
        const s0 = idx === 0 ? this._lastSample : channel[idx - 1];
        const s1 = channel[idx];
        const sample = s0 + (s1 - s0) * frac;
        this._buffer.push(sample);
        pos += ratio;
      }
      this._phase = pos - channel.length;
      this._lastSample = channel[channel.length - 1];
    }

    while (this._buffer.length >= this._chunkSamples) {
      const slice = this._buffer.splice(0, this._chunkSamples);
      const pcm16 = new Int16Array(slice.length);
      for (let i = 0; i < slice.length; i++) {
        const s = Math.max(-1, Math.min(1, slice[i]));
        pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
      }
      this.port.postMessage(pcm16.buffer, [pcm16.buffer]);
    }

    return true;
  }
}
registerProcessor("pcm16-capture-processor", Pcm16CaptureProcessor);
`;

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

/**
 * Gemini Live Session (v3.8 BiDi)
 * - Captures 16kHz mono PCM16 mic audio via AudioWorklet (with ScriptProcessor fallback)
 * - Streams 1 FPS JPEG video frames when camera/screen stream is attached
 * - Supports continuous barge-in interruption and synchronized 24kHz audio playback
 * - Auto-reconnects on transient drops; falls back to throttled SpeechRecognition only if WS fails transiently
 */
export class LiveSession {
  public audioStreamer: AudioStreamer;
  public state: LiveSessionState = "connecting";
  public isActive: boolean = false;
  public isMuted: boolean = false;

  public onStateChange: (state: LiveSessionState) => void = () => {};
  public onSessionEnd: () => void = () => {};
  public onMessage: (sender: "user" | "mimi" | "ultron", text: string) => void = () => {};
  public onCommand: (url: string) => void = () => {};
  public onError: (message: string, fatal?: boolean) => void = () => {};
  public onSpeechInput: (text: string) => Promise<void> | void = () => {};
  public onInterimSpeech: (text: string) => void = () => {};
  public onReconnecting: (reconnecting: boolean, attempt: number, maxAttempts: number) => void = () => {};
  public onDebugUpdate: (info: LiveDebugTelemetry) => void = () => {};

  private ws: WebSocket | null = null;
  private recognition: any = null;
  private audioStream: MediaStream | null = null;
  private captureCtx: AudioContext | null = null;
  private workletNode: AudioWorkletNode | null = null;
  private scriptProcessor: ScriptProcessorNode | null = null;
  private workletBlobUrl: string | null = null;
  private micSource: MediaStreamAudioSourceNode | null = null;
  private silentGain: GainNode | null = null;

  private videoStream: MediaStream | null = null;
  private videoFrameTimer: ReturnType<typeof setInterval> | null = null;
  private hiddenVideoEl: HTMLVideoElement | null = null;
  private captureCanvas: HTMLCanvasElement | null = null;

  private isBiDiRunning: boolean = false;
  private isLiveSessionReady: boolean = false;
  private shouldKeepListening: boolean = false;
  private currentUserName?: string;
  private currentPreferences?: Record<string, any>;
  private pendingTextQueue: string[] = [];

  // Transcription & turn buffers
  private inputTranscriptBuffer: string = "";
  private outputTranscriptBuffer: string = "";
  private outputTurnHasLiveTranscription: boolean = false;
  private turnAudioComplete: boolean = false;

  // Fallback SpeechRecognition throttling
  private fallbackTimer: any = null;
  private lastRecognitionRestartAt: number = 0;

  // Reconnect tracking
  private reconnectAttempt: number = 0;
  private reconnectTimer: any = null;
  private fatalServerError: boolean = false;

  // Debug telemetry
  private wsStatus: LiveDebugTelemetry["wsStatus"] = "disconnected";
  private micActive: boolean = false;
  private chunksSent: number = 0;
  private chunksReceived: number = 0;
  private lastError: string | null = null;

  constructor() {
    this.audioStreamer = new AudioStreamer();
    this.audioStreamer.onPlaybackDrain = () => {
      if (this.shouldKeepListening && this.turnAudioComplete && this.state === "speaking") {
        this.turnAudioComplete = false;
        this.setState("listening");
      }
    };
  }

  public isLiveBiDiActive(): boolean {
    return this.isBiDiRunning && this.isLiveSessionReady && this.ws?.readyState === WebSocket.OPEN;
  }

  public setMuted(muted: boolean) {
    const changed = this.isMuted !== muted;
    this.isMuted = muted;
    if (changed && muted && this.isLiveBiDiActive() && this.ws?.readyState === WebSocket.OPEN) {
      try {
        this.ws.send(JSON.stringify({ type: "input", input: { audioStreamEnd: true } }));
      } catch {}
    }
  }

  public setSpeaking(speaking: boolean) {
    if (!this.isActive) return;
    if (speaking) {
      this.setState("speaking");
    } else if (this.state === "speaking") {
      this.setState("listening");
    }
  }

  public setVideoStream(stream: MediaStream | null) {
    this.videoStream = stream;
    this.stopVideoFramePump();
    if (stream && this.isActive) {
      this.startVideoFramePump();
    }
  }

  public getDebugInfo(): LiveDebugTelemetry {
    return {
      wsStatus: this.wsStatus,
      micActive: this.micActive,
      chunksSent: this.chunksSent,
      chunksReceived: this.chunksReceived,
      state: this.isActive ? this.state : "idle",
      lastError: this.lastError,
      reconnectAttempt: this.reconnectAttempt,
      maxReconnectAttempts: MAX_RECONNECT_ATTEMPTS,
    };
  }

  private emitDebug() {
    this.onDebugUpdate(this.getDebugInfo());
  }

  private setState(state: LiveSessionState) {
    if (this.state === state && this.isActive) {
      this.emitDebug();
      return;
    }
    this.state = state;
    if (this.isActive) {
      this.onStateChange(state);
    }
    this.emitDebug();
  }

  private recordError(message: string, fatal: boolean = false) {
    this.lastError = message;
    if (fatal) {
      this.fatalServerError = true;
    }
    this.emitDebug();
    this.onError(message, fatal);
  }

  public async start(userName?: string, preferences?: Record<string, any>) {
    if (this.isActive) {
      this.stop();
    }

    this.currentUserName = userName;
    this.currentPreferences = preferences;
    this.shouldKeepListening = true;
    this.isActive = true;
    this.fatalServerError = false;
    this.reconnectAttempt = 0;
    this.chunksSent = 0;
    this.chunksReceived = 0;
    this.lastError = null;
    this.inputTranscriptBuffer = "";
    this.outputTranscriptBuffer = "";
    this.outputTurnHasLiveTranscription = false;
    this.turnAudioComplete = false;

    this.setState("connecting");

    await this.startMicrophoneCapture();
    if (this.fatalServerError) {
      this.stop();
      return;
    }

    if (this.videoStream) {
      this.startVideoFramePump();
    }

    this.connectLiveWebSocket();
  }

  private sendPcm16Buffer(pcmBuffer: ArrayBuffer) {
    if (!this.shouldKeepListening || this.isMuted) return;
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN || !this.isBiDiRunning || !this.isLiveSessionReady) return;

    const base64Pcm16 = arrayBufferToBase64(pcmBuffer);
    this.ws.send(
      JSON.stringify({
        type: "input",
        input: {
          audio: {
            data: base64Pcm16,
            mimeType: "audio/pcm;rate=16000",
          },
        },
      })
    );
    this.chunksSent += 1;
    this.emitDebug();
  }

  private async startMicrophoneCapture() {
    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        throw new Error("Microphone API is not available in this browser.");
      }

      this.audioStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          channelCount: 1,
        },
      });

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.captureCtx = new AudioCtx();
      if (this.captureCtx.state === "suspended") {
        await this.captureCtx.resume();
      }

      this.micSource = this.captureCtx.createMediaStreamSource(this.audioStream);
      this.silentGain = this.captureCtx.createGain();
      this.silentGain.gain.value = 0;
      this.silentGain.connect(this.captureCtx.destination);

      let workletReady = false;
      if (this.captureCtx.audioWorklet) {
        try {
          const blob = new Blob([PCM_WORKLET_CODE], { type: "application/javascript" });
          this.workletBlobUrl = URL.createObjectURL(blob);
          await this.captureCtx.audioWorklet.addModule(this.workletBlobUrl);

          this.workletNode = new AudioWorkletNode(this.captureCtx, "pcm16-capture-processor", {
            numberOfInputs: 1,
            numberOfOutputs: 1,
            channelCount: 1,
          });
          this.micSource.connect(this.workletNode);
          this.workletNode.connect(this.silentGain);
          this.workletNode.port.onmessage = (event: MessageEvent<ArrayBuffer>) => {
            this.sendPcm16Buffer(event.data);
          };
          workletReady = true;
        } catch (workletErr) {
          console.warn("AudioWorklet unavailable, switching to ScriptProcessor capture:", workletErr);
        }
      }

      if (!workletReady) {
        const processor = this.captureCtx.createScriptProcessor(2048, 1, 1);
        this.scriptProcessor = processor;
        const inputRate = this.captureCtx.sampleRate;
        const targetRate = 16000;
        let resampleBuf: number[] = [];

        processor.onaudioprocess = (e) => {
          const ch = e.inputBuffer.getChannelData(0);
          const ratio = inputRate / targetRate;
          if (Math.abs(ratio - 1) < 0.01) {
            for (let i = 0; i < ch.length; i++) resampleBuf.push(ch[i]);
          } else {
            for (let pos = 0; pos < ch.length; pos += ratio) {
              const idx = Math.floor(pos);
              const frac = pos - idx;
              const s0 = ch[idx];
              const s1 = ch[Math.min(idx + 1, ch.length - 1)];
              resampleBuf.push(s0 + (s1 - s0) * frac);
            }
          }
          if (resampleBuf.length >= 960) {
            const slice = resampleBuf.splice(0, 960);
            const pcm16 = new Int16Array(slice.length);
            for (let i = 0; i < slice.length; i++) {
              const s = Math.max(-1, Math.min(1, slice[i]));
              pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
            }
            this.sendPcm16Buffer(pcm16.buffer);
          }
        };

        this.micSource.connect(processor);
        processor.connect(this.silentGain);
      }

      this.micActive = true;
      this.emitDebug();
    } catch (err: any) {
      this.micActive = false;
      const isDenied = err?.name === "NotAllowedError" || err?.name === "PermissionDeniedError";
      const msg = isDenied
        ? "Microphone permission denied. Please allow microphone access."
        : `Microphone capture failed: ${err?.message || String(err)}`;
      this.recordError(msg, isDenied);
    }
  }

  private stopMicrophoneCapture() {
    this.micActive = false;
    if (this.workletNode) {
      try {
        this.workletNode.port.onmessage = null;
        this.workletNode.disconnect();
      } catch {}
      this.workletNode = null;
    }
    if (this.scriptProcessor) {
      try {
        this.scriptProcessor.onaudioprocess = null;
        this.scriptProcessor.disconnect();
      } catch {}
      this.scriptProcessor = null;
    }
    if (this.micSource) {
      try {
        this.micSource.disconnect();
      } catch {}
      this.micSource = null;
    }
    if (this.silentGain) {
      try {
        this.silentGain.disconnect();
      } catch {}
      this.silentGain = null;
    }
    if (this.workletBlobUrl) {
      try {
        URL.revokeObjectURL(this.workletBlobUrl);
      } catch {}
      this.workletBlobUrl = null;
    }
    if (this.captureCtx) {
      try {
        this.captureCtx.close();
      } catch {}
      this.captureCtx = null;
    }
    if (this.audioStream) {
      this.audioStream.getTracks().forEach((t) => t.stop());
      this.audioStream = null;
    }
    this.emitDebug();
  }

  private startVideoFramePump() {
    this.stopVideoFramePump();
    if (!this.videoStream) return;

    const video = document.createElement("video");
    video.muted = true;
    video.playsInline = true;
    video.srcObject = this.videoStream;
    video.play().catch(() => {});
    this.hiddenVideoEl = video;

    const canvas = document.createElement("canvas");
    this.captureCanvas = canvas;

    // Live API guideline: stream JPEG frames at max 1 FPS
    this.videoFrameTimer = setInterval(() => {
      if (!this.shouldKeepListening || !this.isLiveBiDiActive() || !this.ws || this.ws.readyState !== WebSocket.OPEN) {
        return;
      }
      if (!this.hiddenVideoEl || this.hiddenVideoEl.readyState < 2) return;
      const vw = this.hiddenVideoEl.videoWidth;
      const vh = this.hiddenVideoEl.videoHeight;
      if (!vw || !vh) return;

      const scale = Math.min(1, 640 / vw);
      canvas.width = Math.round(vw * scale);
      canvas.height = Math.round(vh * scale);
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      ctx.drawImage(this.hiddenVideoEl, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL("image/jpeg", 0.7);
      const base64Data = dataUrl.split(",")[1];
      if (!base64Data) return;

      try {
        this.ws.send(
          JSON.stringify({
            type: "input",
            input: {
              video: {
                data: base64Data,
                mimeType: "image/jpeg",
              },
            },
          })
        );
      } catch {}
    }, 1000);
  }

  private stopVideoFramePump() {
    if (this.videoFrameTimer) {
      clearInterval(this.videoFrameTimer);
      this.videoFrameTimer = null;
    }
    if (this.hiddenVideoEl) {
      try {
        this.hiddenVideoEl.pause();
        this.hiddenVideoEl.srcObject = null;
      } catch {}
      this.hiddenVideoEl = null;
    }
    this.captureCanvas = null;
  }

  /**
   * Fallback Web Speech API strictly used ONLY when Live WebSocket is disconnected
   * (non-fatal transient outage), with hi-IN and >= 4s restart cooldown.
   */
  private startFallbackSpeechRecognition() {
    if (this.isLiveBiDiActive() || !this.shouldKeepListening || this.fatalServerError || this.recognition) {
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      return;
    }

    try {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.maxAlternatives = 1;
      this.recognition.lang = "hi-IN";

      this.recognition.onstart = () => {
        if (this.shouldKeepListening && this.state !== "speaking") {
          this.setState("listening");
        }
      };

      this.recognition.onresult = (event: any) => {
        if (this.isLiveBiDiActive()) return;

        let interimTranscript = "";
        let finalTranscript = "";

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const item = event.results[i];
          const text = item[0]?.transcript || "";
          if (item.isFinal) {
            finalTranscript += text;
          } else {
            interimTranscript += text;
          }
        }

        if (interimTranscript) {
          this.onInterimSpeech(interimTranscript);
        }

        if (finalTranscript.trim()) {
          this.setState("thinking");
          if (this.onSpeechInput) {
            Promise.resolve(this.onSpeechInput(finalTranscript.trim())).finally(() => {
              if (this.shouldKeepListening && !this.isLiveBiDiActive() && this.state === "thinking") {
                this.setState("listening");
              }
            });
          } else {
            this.onMessage("user", finalTranscript.trim());
            if (this.shouldKeepListening && !this.isLiveBiDiActive()) {
              this.setState("listening");
            }
          }
        }
      };

      this.recognition.onerror = (event: any) => {
        if (event.error === "not-allowed") {
          this.recordError("Microphone permission denied. Please allow microphone access.", true);
        }
      };

      this.recognition.onend = () => {
        clearTimeout(this.fallbackTimer);
        if (!this.shouldKeepListening || this.isLiveBiDiActive() || this.fatalServerError) {
          return;
        }
        const elapsed = Date.now() - this.lastRecognitionRestartAt;
        const delay = Math.max(FALLBACK_RECOGNITION_COOLDOWN_MS, FALLBACK_RECOGNITION_COOLDOWN_MS - elapsed);
        this.fallbackTimer = setTimeout(() => {
          if (!this.shouldKeepListening || this.isLiveBiDiActive() || !this.recognition || this.fatalServerError) return;
          this.lastRecognitionRestartAt = Date.now();
          try {
            this.recognition.start();
          } catch {}
        }, delay);
      };

      this.lastRecognitionRestartAt = Date.now();
      this.recognition.start();
    } catch (e) {
      console.warn("Could not start fallback SpeechRecognition:", e);
    }
  }

  private stopFallbackSpeechRecognition() {
    clearTimeout(this.fallbackTimer);
    if (this.recognition) {
      try {
        this.recognition.onend = null;
        this.recognition.onresult = null;
        this.recognition.onerror = null;
        this.recognition.stop();
      } catch {}
      this.recognition = null;
    }
  }

  private flushInputTranscript() {
    const trimmed = this.inputTranscriptBuffer.trim();
    if (trimmed) {
      this.inputTranscriptBuffer = "";
      this.onInterimSpeech("");
      this.onMessage("user", trimmed);
    }
  }

  private flushOutputTranscript() {
    const trimmed = this.outputTranscriptBuffer.trim();
    if (trimmed) {
      this.outputTranscriptBuffer = "";
      this.onMessage("mimi", trimmed);
    }
    this.outputTurnHasLiveTranscription = false;
  }

  private connectLiveWebSocket() {
    if (!this.shouldKeepListening || this.fatalServerError) return;

    clearTimeout(this.reconnectTimer);
    this.wsStatus = this.reconnectAttempt > 0 ? "reconnecting" : "connecting";
    this.setState("connecting");

    try {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/api/live`;

      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        if (!this.shouldKeepListening) {
          this.ws?.close();
          return;
        }
        this.stopFallbackSpeechRecognition();
        this.wsStatus = "open";
        this.isBiDiRunning = true;
        this.isLiveSessionReady = false;
        this.emitDebug();

        this.ws?.send(
          JSON.stringify({
            type: "setup",
            userName: this.currentUserName,
            preferences: this.currentPreferences,
          })
        );
      };

      this.ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);

          if (message.type === "state") {
            if (message.state === "listening") {
              this.reconnectAttempt = 0;
              this.isLiveSessionReady = true;
              this.onReconnecting(false, 0, MAX_RECONNECT_ATTEMPTS);
              this.setState("listening");
              while (this.pendingTextQueue.length > 0 && this.ws?.readyState === WebSocket.OPEN) {
                const queued = this.pendingTextQueue.shift();
                if (queued) {
                  this.ws.send(JSON.stringify({ type: "text", text: queued }));
                }
              }
            } else if (message.state === "thinking") {
              this.setState("thinking");
            } else if (message.state === "speaking") {
              this.setState("speaking");
            } else if (message.state === "connecting") {
              this.setState("connecting");
            }
          } else if (message.type === "live") {
            const data = message.data;
            const serverContent = data?.serverContent;

            // Barge-in interruption: clear playback immediately
            if (serverContent?.interrupted) {
              this.turnAudioComplete = false;
              this.audioStreamer.stop();
              this.flushOutputTranscript();
              this.setState("listening");
            }

            // Interim low-latency user transcript while speaking
            if (serverContent?.interimInputTranscription?.text) {
              const preview = (this.inputTranscriptBuffer + " " + serverContent.interimInputTranscription.text).trim();
              this.onInterimSpeech(preview);
            }

            // Finalized input audio transcription chunks
            if (serverContent?.inputTranscription?.text) {
              this.inputTranscriptBuffer += serverContent.inputTranscription.text;
              this.onInterimSpeech(this.inputTranscriptBuffer.trim());
            }
            if (serverContent?.inputTranscription?.finished) {
              this.flushInputTranscript();
              if (this.state === "listening") {
                this.setState("thinking");
              }
            }

            // Live output audio transcription
            if (serverContent?.outputTranscription?.text) {
              this.outputTurnHasLiveTranscription = true;
              this.flushInputTranscript();
              this.outputTranscriptBuffer += serverContent.outputTranscription.text;
            }
            if (serverContent?.outputTranscription?.finished) {
              this.flushOutputTranscript();
            }

            // Model turn audio & text parts
            const parts = serverContent?.modelTurn?.parts || [];
            for (const part of parts) {
              if (part?.inlineData?.data) {
                this.flushInputTranscript();
                this.turnAudioComplete = false;
                this.chunksReceived += 1;
                this.setState("speaking");
                this.audioStreamer.addPCM16(part.inlineData.data);
              }
              if (part?.text && !this.outputTurnHasLiveTranscription && !part?.thought) {
                this.flushInputTranscript();
                this.outputTranscriptBuffer += part.text;
              }
            }

            // Tool calls forwarded from Live session
            const toolCall = data?.toolCall;
            if (toolCall) {
              for (const call of toolCall.functionCalls || []) {
                if (call.name === "executeBrowserAction") {
                  const url = call.args?.query
                    ? `https://www.google.com/search?q=${encodeURIComponent(call.args.query)}`
                    : "";
                  if (url) this.onCommand(url);
                }
                if (this.ws?.readyState === WebSocket.OPEN) {
                  this.ws.send(
                    JSON.stringify({
                      type: "tool_response",
                      response: {
                        functionResponses: [
                          {
                            id: call.id,
                            name: call.name,
                            response: {
                              result:
                                call.name === "get_device_time"
                                  ? new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" })
                                  : "Action triggered on client",
                            },
                          },
                        ],
                      },
                    })
                  );
                }
              }
            }

            // On turnComplete, flush text and return to listening as soon as queued audio finishes draining
            if (serverContent?.turnComplete) {
              this.flushOutputTranscript();
              if (this.audioStreamer.isPlaying()) {
                this.turnAudioComplete = true;
              } else {
                this.turnAudioComplete = false;
                this.setState("listening");
              }
            }
          } else if (message.type === "error") {
            const errMsg = message.message || "Gemini Live server error.";
            const isFatal = Boolean(message.fatal);
            this.wsStatus = "error";
            this.isBiDiRunning = false;
            this.isLiveSessionReady = false;
            this.recordError(errMsg, isFatal);
          }
        } catch (e: any) {
          console.warn("[LiveSession Message Parse Error]:", e);
        }
      };

      this.ws.onerror = () => {
        this.isBiDiRunning = false;
        this.isLiveSessionReady = false;
        this.wsStatus = "error";
        if (!this.lastError) {
          this.lastError = "WebSocket connection error";
        }
        this.emitDebug();
      };

      this.ws.onclose = () => {
        this.isBiDiRunning = false;
        this.isLiveSessionReady = false;
        this.ws = null;

        if (!this.shouldKeepListening || !this.isActive) {
          this.wsStatus = "disconnected";
          this.emitDebug();
          return;
        }

        if (this.fatalServerError) {
          this.wsStatus = "error";
          this.onReconnecting(false, this.reconnectAttempt, MAX_RECONNECT_ATTEMPTS);
          this.emitDebug();
          this.stop();
          return;
        }

        // Auto-reconnect with exponential backoff (1s, 2s, 4s, 8s, 16s; max 5 retries)
        if (this.reconnectAttempt < MAX_RECONNECT_ATTEMPTS) {
          const delayMs = RECONNECT_DELAYS_MS[this.reconnectAttempt] ?? 16000;
          this.reconnectAttempt += 1;
          this.wsStatus = "reconnecting";
          this.setState("connecting");
          this.onReconnecting(true, this.reconnectAttempt, MAX_RECONNECT_ATTEMPTS);
          this.emitDebug();

          this.reconnectTimer = setTimeout(() => {
            if (this.shouldKeepListening && this.isActive && !this.fatalServerError) {
              this.connectLiveWebSocket();
            }
          }, delayMs);
        } else {
          this.wsStatus = "error";
          this.onReconnecting(false, this.reconnectAttempt, MAX_RECONNECT_ATTEMPTS);
          this.recordError(
            "Gemini Live connection lost after 5 reconnect attempts. Fallback speech recognition active.",
            false
          );
          this.startFallbackSpeechRecognition();
        }
      };
    } catch (e: any) {
      this.isBiDiRunning = false;
      this.isLiveSessionReady = false;
      this.wsStatus = "error";
      this.recordError(`Could not connect to Live WebSocket: ${e?.message || String(e)}`, false);
      this.startFallbackSpeechRecognition();
    }
  }

  public sendText(text: string) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN && this.isBiDiRunning) {
      if (!this.isLiveSessionReady) {
        this.pendingTextQueue.push(text);
        return;
      }
      this.audioStreamer.stop();
      this.turnAudioComplete = false;
      this.setState("thinking");
      this.ws.send(
        JSON.stringify({
          type: "text",
          text,
        })
      );
    }
  }

  public stop() {
    this.shouldKeepListening = false;
    this.isActive = false;
    this.isLiveSessionReady = false;
    this.turnAudioComplete = false;
    this.pendingTextQueue = [];
    clearTimeout(this.reconnectTimer);
    this.onReconnecting(false, 0, MAX_RECONNECT_ATTEMPTS);

    this.stopFallbackSpeechRecognition();
    this.stopVideoFramePump();
    this.stopMicrophoneCapture();

    if (this.ws) {
      try {
        this.ws.onclose = null;
        this.ws.onerror = null;
        this.ws.onmessage = null;
        this.ws.close();
      } catch {}
      this.ws = null;
    }

    this.audioStreamer.stop();
    this.isBiDiRunning = false;
    this.wsStatus = "disconnected";
    this.inputTranscriptBuffer = "";
    this.outputTranscriptBuffer = "";
    this.outputTurnHasLiveTranscription = false;
    this.emitDebug();
    this.onSessionEnd();
  }
}
