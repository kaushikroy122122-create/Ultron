import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signInAnonymously, signOut, onAuthStateChanged, User } from 'firebase/auth';
import { getFirestore, doc, setDoc, getDoc, collection, query, orderBy, limit, onSnapshot, addDoc, serverTimestamp, getDocFromServer, disableNetwork } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
const databaseId = (firebaseConfig as any).firestoreDatabaseId;
export const db = databaseId ? getFirestore(app, databaseId) : getFirestore(app);

// Check if we are running on placeholder credentials (meaning Firebase setup hasn't been completed yet)
export const isPlaceholderConfig = 
  !firebaseConfig.apiKey || 
  firebaseConfig.apiKey.startsWith('remixed-') || 
  firebaseConfig.apiKey.includes('api-key');

if (isPlaceholderConfig) {
  console.warn("Mimi System: Placeholder Firebase credentials detected. Enabling silent local offline mode to prevent network errors.");
  disableNetwork(db).catch((err) => {
    console.warn("Failed to set Firestore to offline mode: ", err);
  });
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

// Test connection with retry and initial delay to allow Firestore networking to warm up
async function testConnection(retries = 3, delayMs = 2000) {
  if (isPlaceholderConfig) {
    console.log("Mimi System: Operating in secure local-first sandbox mode. Connection test bypassed.");
    return;
  }

  // Wait before first attempt to let socket connections negotiate
  await new Promise((resolve) => setTimeout(resolve, 1500));
  
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      // Try to fetch a document that we just allowed in the rules
      await getDocFromServer(doc(db, 'test', 'connection'));
      console.log("Firebase connection established successfully on attempt " + attempt);
      return;
    } catch (error) {
      if (error instanceof Error) {
        const isOffline = error.message.includes('the client is offline');
        const isPermDenied = error.message.includes('permission-denied');
        
        if (isOffline) {
          console.warn(`Firestore connection attempt ${attempt}/${retries} failed because client is offline. Retrying...`);
          if (attempt < retries) {
            await new Promise((resolve) => setTimeout(resolve, delayMs));
            continue;
          } else {
            console.warn("Firestore safe fallback activated: Mimi operating in offline-first mode.");
          }
        } else if (isPermDenied) {
          // This might still happen if the rules didn't propagate yet, but it's NOT an offline error
          console.warn("Firestore connection check returned permission-denied. This may be normal if rules are still propagating.");
          return;
        } else {
          console.error(`Firestore connection check failed on attempt ${attempt}:`, error.message);
          return;
        }
      }
    }
  }
}
testConnection().catch((err) => {
  console.warn("Silent fallback of Firebase background connection trial error:", err);
});

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errMsg = error instanceof Error ? error.message : String(error);
  const errInfo: FirestoreErrorInfo = {
    error: errMsg,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };

  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}



// In-memory cache for OAuth access token backed by localStorage
let cachedAccessToken: string | null = null;
try {
  cachedAccessToken = localStorage.getItem("mimi_access_token");
} catch (e) {
  console.warn("Could not read access token from localStorage", e);
}

export const getCachedAccessToken = () => {
  if (!cachedAccessToken) {
    try {
      cachedAccessToken = localStorage.getItem("mimi_access_token");
    } catch (e) {}
  }
  return cachedAccessToken;
};

export const loginWithGoogle = async () => {
  const provider = new GoogleAuthProvider();
  // Standard profile & email scopes - 100% warning-free, instantly approved by Google default auth routing
  provider.addScope('profile');
  provider.addScope('email');
  try {
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    cachedAccessToken = credential?.accessToken || null;
    if (cachedAccessToken) {
      try {
        localStorage.setItem("mimi_access_token", cachedAccessToken);
      } catch (e) {
        console.warn("Failed to write access token to localStorage", e);
      }
    }
    return result.user;
  } catch (error) {
    console.error("Login Error:", error);
    throw error;
  }
};

export const loginWithGoogleWorkspace = async () => {
  const provider = new GoogleAuthProvider();
  // Request Gmail, Drive, Chat, Tasks, Contacts and Spreadsheet scopes securely
  provider.addScope('https://www.googleapis.com/auth/gmail.readonly');
  provider.addScope('https://www.googleapis.com/auth/gmail.send');
  provider.addScope('https://www.googleapis.com/auth/drive');
  provider.addScope('https://www.googleapis.com/auth/chat');
  provider.addScope('https://www.googleapis.com/auth/tasks');
  provider.addScope('https://www.googleapis.com/auth/contacts');
  provider.addScope('https://www.googleapis.com/auth/spreadsheets');
  try {
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    cachedAccessToken = credential?.accessToken || null;
    if (cachedAccessToken) {
      try {
        localStorage.setItem("mimi_access_token", cachedAccessToken);
      } catch (e) {
        console.warn("Failed to write access token to localStorage", e);
      }
    }
    return result.user;
  } catch (error) {
    console.error("Workspace Login Error:", error);
    throw error;
  }
};

export const loginAnonymously = async () => {
  try {
    const result = await signInAnonymously(auth);
    return result.user;
  } catch (error) {
    console.error("Anonymous Sign-In Error:", error);
    throw error;
  }
};

export const logout = async () => {
  try {
    await signOut(auth);
    cachedAccessToken = null;
    try {
      localStorage.removeItem("mimi_access_token");
    } catch (e) {}
  } catch (error) {
    console.error("Logout Error:", error);
    throw error;
  }
};

export const initAuth = (callback: (user: User | null) => void) => {
  return onAuthStateChanged(auth, callback);
};

export { 
  doc, setDoc, getDoc, collection, query, orderBy, limit, onSnapshot, addDoc, serverTimestamp 
};
