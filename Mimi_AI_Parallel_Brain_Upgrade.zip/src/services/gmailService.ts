export interface GmailMessage {
  id: string;
  threadId: string;
  from: string;
  to: string;
  subject: string;
  date: string;
  snippet: string;
  body: string;
  isRead: boolean;
}

export interface GmailThread {
  id: string;
  snippet: string;
  messagesCount: number;
}

/**
 * Clean up header from message attributes
 */
function getHeader(headers: { name: string; value: string }[], name: string): string {
  const header = headers.find((h) => h.name.toLowerCase() === name.toLowerCase());
  return header ? header.value : "";
}

/**
 * Decode base64url standard to standard string
 */
function decodeBase64(base64: string): string {
  const normalized = base64.replace(/-/g, "+").replace(/_/g, "/");
  try {
    return decodeURIComponent(
      atob(normalized)
        .split("")
        .map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2))
        .join("")
    );
  } catch (error) {
    try {
      return atob(normalized); // fallback to standard ascii decode
    } catch {
      return "[Base64 Decoding Error - Binary or Format issue]";
    }
  }
}

/**
 * Parse a raw API message into a clean GmailMessage struct
 */
export function parseGmailMessage(rawMsg: any): GmailMessage {
  const headers = rawMsg.payload?.headers || [];
  const from = getHeader(headers, "From");
  const to = getHeader(headers, "To");
  const subject = getHeader(headers, "Subject") || "(No Subject)";
  const dateValue = getHeader(headers, "Date");
  const date = dateValue ? new Date(dateValue).toLocaleString() : "Unknown date";
  
  // Find body inside parts
  let body = "";
  if (rawMsg.payload?.body?.data) {
    body = decodeBase64(rawMsg.payload.body.data);
  } else if (rawMsg.payload?.parts) {
    // Traverse parts
    const parts = rawMsg.payload.parts;
    for (const part of parts) {
      if (part.mimeType === "text/plain" && part.body?.data) {
        body = decodeBase64(part.body.data);
        break;
      } else if (part.mimeType === "text/html" && part.body?.data && !body) {
        // Fallback to html body if plain isn't found
        body = decodeBase64(part.body.data);
      }
    }
  }

  if (!body) {
    body = rawMsg.snippet || "";
  }

  const isRead = !rawMsg.labelIds?.includes("UNREAD");

  return {
    id: rawMsg.id,
    threadId: rawMsg.threadId,
    from,
    to,
    subject,
    date,
    snippet: rawMsg.snippet || "",
    body,
    isRead,
  };
}

/**
 * Fetch a list of message summaries from inbox
 */
export async function getGmailInbox(accessToken: string, maxResults: number = 10, query: string = ""): Promise<GmailMessage[]> {
  try {
    let url = `https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=${maxResults}`;
    if (query) {
      url += `&q=${encodeURIComponent(query)}`;
    }
    const response = await fetch(url, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (!response.ok) {
      throw new Error(`Gmail API returned status ${response.status}`);
    }

    const data = await response.json();
    if (!data.messages || data.messages.length === 0) {
      return [];
    }

    // Now load individual details for each message
    const detailPromises = data.messages.map(async (msg: any) => {
      try {
        const detailRes = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${msg.id}?format=full`, {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        });
        if (detailRes.ok) {
          const rawDetail = await detailRes.json();
          return parseGmailMessage(rawDetail);
        }
      } catch (err) {
        console.error(`Error fetching detail for message ${msg.id}`, err);
      }
      return null;
    });

    const parsedMessages = await Promise.all(detailPromises);
    return parsedMessages.filter((msg): msg is GmailMessage => msg !== null);
  } catch (error) {
    console.error("Error in getGmailInbox:", error);
    throw error;
  }
}

/**
 * Mark a message as read (remove UNREAD label)
 */
export async function markAsRead(accessToken: string, messageId: string): Promise<boolean> {
  try {
    const response = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${messageId}/batchModify`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        ids: [messageId],
        removeLabelIds: ["UNREAD"],
      }),
    });
    return response.ok;
  } catch (error) {
    console.error("Error marking email as read:", error);
    return false;
  }
}

/**
 * Trash an email message
 */
export async function trashMessage(accessToken: string, messageId: string): Promise<boolean> {
  try {
    const response = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${messageId}/trash`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });
    return response.ok;
  } catch (error) {
    console.error("Error trashing email component:", error);
    return false;
  }
}

/**
 * Send an email using standard raw MIME format
 */
export async function sendEmail(
  accessToken: string,
  to: string,
  subject: string,
  body: string
): Promise<{ success: boolean; messageId?: string }> {
  try {
    // Generate clean MIME email body
    const emailHeaderLines = [
      `To: ${to}`,
      `Subject: ${subject}`,
      "Content-Type: text/html; charset=utf-8",
      "MIME-Version: 1.0",
      "",
      body.replace(/\n/g, "<br />")
    ];
    const mimeEmail = emailHeaderLines.join("\r\n");

    // Standard JavaScript Base64Url encoding
    const encodedEmail = btoa(unescape(encodeURIComponent(mimeEmail)))
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
      .replace(/=+$/, "");

    const response = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        raw: encodedEmail,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Sending failed: ${errorText}`);
    }

    const data = await response.json();
    return { success: true, messageId: data.id };
  } catch (error) {
    console.error("Error of Gmail sending raw:", error);
    throw error;
  }
}
