import { selfRepairer } from "./selfRepairService";

export interface StudioConfig {
  region: string;
  activeModel: string;
  latencyOptimization: boolean;
}

let currentConfig: StudioConfig = {
  region: "global",
  activeModel: "gemini-2.5-flash",
  latencyOptimization: true
};

export const googleStudioManager = {
  updateConfig(newConfig: Partial<StudioConfig>) {
    currentConfig = { ...currentConfig, ...newConfig };
    selfRepairer.addLog(
      "info", 
      "Google Studio Link Re-Routed", 
      `Region updated to ${currentConfig.region}, Model set to ${currentConfig.activeModel}`
    );
  },
  
  getConfig() {
    return currentConfig;
  },

  async checkLatency(): Promise<number> {
    // Simulated latency check across the Google global network
    selfRepairer.setActiveTask("system", `Pinging ${currentConfig.region} edge node...`);
    return new Promise((resolve) => {
      setTimeout(() => {
        selfRepairer.clearActiveTask();
        const basePing = currentConfig.region === "global" ? 20 : currentConfig.region === "asia-southeast1" ? 15 : 60;
        resolve(basePing + Math.floor(Math.random() * 15));
      }, 500);
    });
  }
};
