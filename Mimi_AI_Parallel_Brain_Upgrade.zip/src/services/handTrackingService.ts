import { HandLandmarker, FilesetResolver } from "@mediapipe/tasks-vision";

export interface HandData {
  landmarks: any[][];
  handedness: any[][];
}

export class HandTrackingService {
  private handLandmarker: HandLandmarker | null = null;
  private isInitialized = false;

  async initialize() {
    if (this.isInitialized) return;
    
    const vision = await FilesetResolver.forVisionTasks(
      "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.0/wasm"
    );
    
    this.handLandmarker = await HandLandmarker.createFromOptions(vision, {
      baseOptions: {
        modelAssetPath: `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`,
        delegate: "GPU"
      },
      runningMode: "VIDEO",
      numHands: 2
    });
    
    this.isInitialized = true;
  }

  detectContent(video: HTMLVideoElement, timestamp: number): HandData | null {
    if (!this.handLandmarker) return null;
    
    const result = this.handLandmarker.detectForVideo(video, timestamp);
    if (result.landmarks && result.landmarks.length > 0) {
      return {
        landmarks: result.landmarks,
        handedness: result.worldLandmarks // Optional, could use for depth
      };
    }
    return null;
  }
}

export const handTracker = new HandTrackingService();
