import { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import { getMergedFrequencyData } from "../utils/audioUtils";

type VisualizerState = "idle" | "connecting" | "listening" | "thinking" | "processing" | "speaking";

interface VisualizerProps {
  state: VisualizerState;
  mood?: "cheerful" | "sassy" | "serious" | null;
}

export default function Visualizer({ state, mood }: VisualizerProps) {
  const [frequencies, setFrequencies] = useState<number[]>(new Array(16).fill(0));
  const [averageVolume, setAverageVolume] = useState<number>(0);
  const [phase, setPhase] = useState(0);
  const animationRef = useRef<number | null>(null);

  useEffect(() => {
    if (state !== "speaking") {
      setFrequencies(new Array(16).fill(0));
      setAverageVolume(0);
      return;
    }

    const updateAudioData = () => {
      const data = getMergedFrequencyData(16);
      let arr = Array.from(data);
      let sum = arr.reduce((a, b) => a + b, 0);
      let avg = sum / (arr.length || 1);
      
      // If we are speaking but there is no registered physical audio frequency stream,
      // let's simulate an organic, lifelike procedural speech frequency wave
      if (avg < 5 && state === "speaking") {
        const time = Date.now() * 0.001;
        // Low-frequency word rhythm envelope (word pacing with silences)
        const wordEnvelope = Math.max(0, Math.sin(time * 2.8) * 0.6 + Math.cos(time * 5.4) * 0.3 + 0.15);
        
        arr = arr.map((_, idx) => {
          const formant1 = Math.sin(time * 14 + idx * 0.4) * 45;
          const formant2 = Math.cos(time * 22 - idx * 0.7) * 35;
          const hiss = (Math.random() - 0.5) * 12;
          const val = (formant1 + formant2 + hiss + 120) * wordEnvelope;
          return Math.max(0, Math.min(255, val));
        });
        
        sum = arr.reduce((a, b) => a + b, 0);
        avg = sum / (arr.length || 1);
      }

      setFrequencies(arr);
      setAverageVolume(avg);

      // Smoothly advance phase for floating effect
      setPhase(p => (p + 0.15) % (Math.PI * 2));

      animationRef.current = requestAnimationFrame(updateAudioData);
    };

    updateAudioData();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [state]);

  const getWavePathDouble = (freqs: number[], heightMultiplier: number, currentPhase: number, sign: number) => {
    const width = 160;
    const height = 60;
    const centerY = height / 2;
    const points: string[] = [];

    points.push(`M 0 ${centerY}`);
    const step = width / (freqs.length - 1 || 1);
    for (let i = 0; i < freqs.length; i++) {
      const x = i * step;
      const normalizedVal = freqs[i] / 255;
      const taper = Math.sin((i / (freqs.length - 1)) * Math.PI); // taper edges to 0
      const amp = normalizedVal * heightMultiplier * taper * 25;
      const wave = Math.sin(currentPhase + i * 0.6) * amp * sign;
      const y = centerY + wave;
      points.push(`L ${x} ${y}`);
    }
    return points.join(" ");
  };

  const getRingAnimation = (index: number, reverse: boolean = false) => {
    const baseSpeed = state === "listening" ? 3 : (state === "thinking" || state === "processing" || state === "connecting") ? 1.5 : state === "speaking" ? 2 : 15;
    return {
      rotate: reverse ? [-360, 0] : [0, 360],
      transition: { duration: baseSpeed + index * 2, repeat: Infinity, ease: "linear" }
    };
  };

  const getPulseAnimation = () => {
    if (state === "speaking") {
      return {
        scale: [1, 1.05, 0.98, 1.02, 1],
        opacity: [0.8, 1, 0.8, 1, 0.8],
        transition: { duration: 0.5, repeat: Infinity, ease: "easeInOut" }
      };
    }
    if (state === "listening") {
      return {
        scale: [1, 1.02, 1],
        opacity: [0.7, 1, 0.7],
        transition: { duration: 1, repeat: Infinity, ease: "easeInOut" }
      };
    }
    if (state === "thinking" || state === "processing" || state === "connecting") {
      return {
        scale: [0.98, 1.02, 0.98],
        opacity: [0.6, 0.9, 0.6],
        transition: { duration: 0.8, repeat: Infinity, ease: "linear" }
      };
    }
    return {
      scale: [1, 1.01, 1],
      opacity: [0.4, 0.6, 0.4],
      transition: { duration: 4, repeat: Infinity, ease: "easeInOut" }
    };
  };

  // Dynamic mood-based or default theme color palettes
  const getTheme = () => {
    if (mood === "cheerful") {
      switch (state) {
        case "listening": return { color: "rgba(245, 158, 11, 0.8)", glow: "shadow-amber-500/80", border: "border-amber-400", ringColor: "#f59e0b" };
        case "connecting":
        case "thinking":
        case "processing": return { color: "rgba(251, 146, 60, 0.9)", glow: "shadow-orange-400/100", border: "border-orange-400", ringColor: "#fb923c" };
        case "speaking": return { color: "rgba(234, 179, 8, 1)", glow: "shadow-yellow-500/100", border: "border-yellow-400", ringColor: "#eab308" };
        default: return { color: "rgba(217, 119, 6, 0.8)", glow: "shadow-amber-600/60", border: "border-amber-600/50", ringColor: "#d97706" };
      }
    }
    if (mood === "sassy") {
      switch (state) {
        case "listening": return { color: "rgba(236, 72, 153, 0.8)", glow: "shadow-pink-500/80", border: "border-pink-400", ringColor: "#ec4899" };
        case "connecting":
        case "thinking":
        case "processing": return { color: "rgba(219, 39, 119, 0.9)", glow: "shadow-pink-600/100", border: "border-pink-500", ringColor: "#db2777" };
        case "speaking": return { color: "rgba(244, 63, 94, 1)", glow: "shadow-rose-500/100", border: "border-rose-400", ringColor: "#f43f5e" };
        default: return { color: "rgba(190, 24, 74, 0.8)", glow: "shadow-rose-700/60", border: "border-rose-500/50", ringColor: "#be184a" };
      }
    }
    if (mood === "serious") {
      switch (state) {
        case "listening": return { color: "rgba(6, 182, 212, 0.8)", glow: "shadow-cyan-500/80", border: "border-cyan-400", ringColor: "#06b6d4" };
        case "connecting":
        case "thinking":
        case "processing": return { color: "rgba(14, 165, 233, 0.9)", glow: "shadow-sky-400/100", border: "border-sky-400", ringColor: "#0ea5e9" };
        case "speaking": return { color: "rgba(59, 130, 246, 1)", glow: "shadow-blue-500/100", border: "border-blue-400", ringColor: "#3b82f6" };
        default: return { color: "rgba(13, 148, 136, 0.8)", glow: "shadow-teal-500/60", border: "border-teal-500/50", ringColor: "#0d9488" };
      }
    }

    // Default theme colors
    switch (state) {
      case "listening": return { color: "rgba(139, 92, 246, 1)", glow: "shadow-violet-500/80", border: "border-violet-400", ringColor: "#8b5cf6" };
      case "connecting":
      case "thinking":
      case "processing": return { color: "rgba(56, 189, 248, 1)", glow: "shadow-sky-400/100", border: "border-sky-400", ringColor: "#38bdf8" };
      case "speaking": return { color: "rgba(236, 72, 153, 1)", glow: "shadow-pink-500/100", border: "border-pink-400", ringColor: "#ec4899" };
      default: return { color: "rgba(6, 182, 212, 0.8)", glow: "shadow-cyan-500/60", border: "border-cyan-500/50", ringColor: "#06b6d4" }; // Cyan for idle
    }
  };

  const theme = getTheme();

  return (
    <div className="absolute inset-0 flex items-center justify-center overflow-hidden pointer-events-none">
      {/* Ambient Glow */}
      <motion.div
        animate={getPulseAnimation()}
        className={`absolute w-[70%] h-[70%] rounded-full blur-[120px] ${theme.glow}`}
        style={{ 
          backgroundColor: theme.color, 
          opacity: state === "speaking" ? 0.1 + (averageVolume / 255) * 0.35 : 0.2,
          scale: state === "speaking" ? 1 + (averageVolume / 255) * 0.45 : undefined
        }}
      />

      {/* Ring 1: Massive Outer Dashed */}
      <motion.div
        animate={getRingAnimation(4, false)}
        className={`absolute w-[100%] h-[100%] rounded-full border-[1.5px] border-dashed ${theme.border} opacity-20`}
        style={{ 
          borderColor: theme.ringColor,
          scale: state === "speaking" ? 1 + (averageVolume / 255) * 0.05 : undefined
        }}
      />

      {/* Ring 2: Segmented Thick Ring */}
      <motion.div
        animate={getRingAnimation(3, true)}
        className={`absolute w-[85%] h-[85%] rounded-full border-[3px] border-dotted ${theme.border} opacity-40`}
        style={{ 
          borderColor: theme.ringColor,
          scale: state === "speaking" ? 1 + (averageVolume / 255) * 0.08 : undefined
        }}
      />

      {/* Ring 3: Scanner Ring (Solid with gaps) */}
      <motion.div
        animate={getRingAnimation(2, false)}
        className={`absolute w-[75%] h-[75%] rounded-full border-[2px] ${theme.border} border-t-transparent border-b-transparent opacity-50`}
        style={{ 
          borderColor: theme.ringColor,
          scale: state === "speaking" ? 1 + (averageVolume / 255) * 0.11 : undefined
        }}
      />

      {/* Ring 4: Inner Dashed */}
      <motion.div
        animate={getRingAnimation(1, true)}
        className={`absolute w-[60%] h-[60%] rounded-full border-[2.5px] border-dashed ${theme.border} opacity-60`}
        style={{ 
          borderColor: theme.ringColor,
          scale: state === "speaking" ? 1 + (averageVolume / 255) * 0.14 : undefined
        }}
      />
      
      {/* Ring 5: Core HUD Ring */}
      <motion.div
        animate={getRingAnimation(0, false)}
        className={`absolute w-[45%] h-[45%] rounded-full border-[5px] border-dotted ${theme.border} opacity-80`}
        style={{ 
          borderColor: theme.ringColor,
          scale: state === "speaking" ? 1 + (averageVolume / 255) * 0.18 : undefined
        }}
      />

      {/* Core Circle */}
      <motion.div
        animate={getPulseAnimation()}
        className={`absolute w-[28%] h-[28%] rounded-full border-[2px] ${theme.border} bg-black/60 backdrop-blur-xl flex items-center justify-center z-10`}
        style={{ 
          boxShadow: `0 0 60px ${theme.color}, inset 0 0 40px ${theme.color}, 0 0 20px #fff`,
          borderColor: theme.ringColor,
          scale: state === "speaking" ? 1 + (averageVolume / 255) * 0.15 : undefined
        }}
      >
        {/* Real-time Oscilloscope Voice Wave */}
        {state === "speaking" && (
          <div className="absolute inset-0 flex items-center justify-center opacity-70 pointer-events-none overflow-hidden rounded-full">
            <svg viewBox="0 0 160 60" className="w-full h-full scale-[1.1]">
              <defs>
                <linearGradient id="cyanGlow" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#22d3ee" stopOpacity="0"/>
                  <stop offset="50%" stopColor="#22d3ee" stopOpacity="1"/>
                  <stop offset="100%" stopColor="#22d3ee" stopOpacity="0"/>
                </linearGradient>
                <linearGradient id="pinkGlow" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#ec4899" stopOpacity="0"/>
                  <stop offset="50%" stopColor="#ec4899" stopOpacity="1"/>
                  <stop offset="100%" stopColor="#ec4899" stopOpacity="0"/>
                </linearGradient>
                <linearGradient id="violetGlow" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#a78bfa" stopOpacity="0"/>
                  <stop offset="50%" stopColor="#a78bfa" stopOpacity="1"/>
                  <stop offset="100%" stopColor="#a78bfa" stopOpacity="0"/>
                </linearGradient>
              </defs>
              <path
                d={getWavePathDouble(frequencies, 1.2, phase, 1)}
                fill="none"
                stroke="url(#cyanGlow)"
                strokeWidth="2.5"
                strokeLinecap="round"
                className="drop-shadow-[0_0_6px_rgba(34,211,238,0.8)]"
              />
              <path
                d={getWavePathDouble(frequencies, 0.9, phase + 2, -1)}
                fill="none"
                stroke="url(#pinkGlow)"
                strokeWidth="2"
                strokeLinecap="round"
                className="drop-shadow-[0_0_6px_rgba(236,72,153,0.8)]"
              />
              <path
                d={getWavePathDouble(frequencies, 0.7, phase + 4, 1)}
                fill="none"
                stroke="url(#violetGlow)"
                strokeWidth="1.5"
                strokeLinecap="round"
                className="drop-shadow-[0_0_6px_rgba(167,139,250,0.8)]"
              />
            </svg>
          </div>
        )}

        {/* Inner core decorative ring */}
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          className="absolute inset-1 border border-cyan-400/30 rounded-full border-t-pink-400 border-r-amber-400"
        />

        {/* 3D Gemini Holographic Smart Star Brand Core */}
        <div className="absolute inset-3 rounded-full overflow-hidden opacity-60 mix-blend-screen pointer-events-none">
          <img 
            src="/src/assets/images/gemini_smart_step_3d_1793560483598.jpg" 
            alt="3D Gemini Smart Star" 
            className="w-full h-full object-cover rounded-full"
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Center Text with 3D Holographic Gradient */}
        <div 
          className="font-black tracking-[0.3em] text-xl md:text-2xl lg:text-3xl text-transparent bg-clip-text bg-gradient-to-r from-cyan-200 via-pink-300 to-amber-200 z-20 drop-shadow-[0_0_15px_rgba(255,255,255,0.7)]"
        >
          GEMINI
        </div>
      </motion.div>

      {/* Solar System Planets/Nodes */}
      <div className="absolute inset-0 flex items-center justify-center">
        {/* Orbit 1 - Violet Planet */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
          className="absolute w-[45%] h-[45%]"
        >
          <div className="absolute top-0 left-1/2 -translate-x-1/2 flex flex-col items-center">
            <motion.div 
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-4 h-4 rounded-full bg-violet-400 shadow-[0_0_20px_#8b5cf6]" 
            />
            <div className="mt-1 w-[1px] h-4 bg-gradient-to-b from-violet-400/50 to-transparent" />
          </div>
        </motion.div>

        {/* Orbit 2 - Cyan Planet */}
        <motion.div
          animate={{ rotate: -360 }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute w-[65%] h-[65%]"
        >
          <div className="absolute bottom-0 right-1/2 translate-x-1/2 flex flex-col items-center">
            <div className="mb-1 w-[1px] h-6 bg-gradient-to-t from-cyan-400/50 to-transparent" />
            <motion.div 
              animate={{ scale: [1, 1.3, 1] }}
              transition={{ duration: 3, repeat: Infinity, delay: 0.5 }}
              className="w-6 h-6 rounded-full bg-cyan-400 shadow-[0_0_25px_#22d3ee]" 
            />
          </div>
        </motion.div>

        {/* Orbit 3 - Pink Planet */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 35, repeat: Infinity, ease: "linear" }}
          className="absolute w-[82%] h-[82%]"
        >
          <div className="absolute top-1/2 right-0 -translate-y-1/2 flex items-center">
            <div className="mr-1 w-6 h-[1px] bg-gradient-to-l from-pink-400/50 to-transparent" />
            <motion.div 
              animate={{ scale: [1, 1.15, 1] }}
              transition={{ duration: 4, repeat: Infinity }}
              className="w-5 h-5 rounded-full bg-pink-400 shadow-[0_0_20px_#f472b6]" 
            />
          </div>
        </motion.div>

        {/* Orbit 4 - Amber Planet */}
        <motion.div
          animate={{ rotate: -360 }}
          transition={{ duration: 45, repeat: Infinity, ease: "linear" }}
          className="absolute w-[95%] h-[95%]"
        >
          <div className="absolute top-1/2 left-0 -translate-y-1/2 flex items-center">
            <motion.div 
              animate={{ opacity: [0.5, 1, 0.5], scale: [1, 1.2, 1] }}
              transition={{ duration: 2.5, repeat: Infinity }}
              className="w-3.5 h-3.5 rounded-full bg-orange-400 shadow-[0_0_15px_#fb923c]" 
            />
            <div className="ml-1 w-8 h-[1px] bg-gradient-to-r from-orange-400/50 to-transparent" />
          </div>
        </motion.div>

        {/* Orbit 5 - Far Moons (Static but fading) */}
        <div className="absolute inset-0 opacity-20 pointer-events-none">
           {[...Array(6)].map((_, i) => (
             <div 
               key={i}
               className="absolute w-2 h-2 rounded-full bg-white blur-[1px]"
               style={{
                 top: `${10 + Math.random() * 80}%`,
                 left: `${10 + Math.random() * 80}%`,
               }}
             />
           ))}
        </div>
      </div>
    </div>
  );
}
