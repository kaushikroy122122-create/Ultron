import React, { useState, useEffect, useRef } from "react";
import { Image, Plus, Upload, Trash2, Heart, Search, Sparkles, X, CloudOff, FolderHeart, ArrowRight, CornerDownRight } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface MimiPhoto {
  id: string;
  url: string;
  title: string;
  category: "cat" | "preset" | "nature" | "people" | "uploaded";
  timestamp: string;
  isFavorite?: boolean;
}

interface MimiPhotoHubProps {
  isOpen: boolean;
  onClose: () => void;
  activeCommandPhotoCategory: string | null;
  onPhotoSelectedByMimi?: (photoTitle: string) => void;
  userName?: string;
}

// Solid pre-curated beautiful assets with robust fallback tags
const PRESET_MIMI_PHOTOS: MimiPhoto[] = [
  {
    id: "cat-1",
    url: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=600&auto=format&fit=crop&q=80",
    title: "Lovely Ginger Cat (আমার সোনার বিড়াল)",
    category: "cat",
    timestamp: "May 19, 2026",
    isFavorite: true
  },
  {
    id: "cat-2",
    url: "https://images.unsplash.com/photo-1573865526739-10659fec78a5?w=600&auto=format&fit=crop&q=80",
    title: "Fluffy Playful Cat (খেলাধুলা বিড়াল)",
    category: "cat",
    timestamp: "May 18, 2026",
    isFavorite: false
  },
  {
    id: "beach-1",
    url: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80",
    title: "Sunrise Beach Escape (কক্সবাজার স্মৃতি)",
    category: "nature",
    timestamp: "April 12, 2026",
    isFavorite: true
  },
  {
    id: "mountain-1",
    url: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=600&auto=format&fit=crop&q=80",
    title: "Serene Mountain Peak (হিমালয় পর্বত)",
    category: "nature",
    timestamp: "March 20, 2026",
    isFavorite: false
  },
  {
    id: "workspace-1",
    url: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=600&auto=format&fit=crop&q=80",
    title: "Cozy Study Desk (পড়ার টেবিল)",
    category: "nature",
    timestamp: "May 10, 2026",
    isFavorite: false
  },
  {
    id: "family-1",
    url: "https://images.unsplash.com/photo-1471967183320-ee018f6e11ca?w=600&auto=format&fit=crop&q=80",
    title: "Family Evening Gathering (পরিবারের আড্ডা)",
    category: "people",
    timestamp: "May 15, 2026",
    isFavorite: true
  }
];

export default function MimiPhotoHub({ 
  isOpen, 
  onClose, 
  activeCommandPhotoCategory, 
  onPhotoSelectedByMimi,
  userName 
}: MimiPhotoHubProps) {
  const [photos, setPhotos] = useState<MimiPhoto[]>(() => {
    const local = localStorage.getItem("mimi_local_photos");
    if (local) {
      try {
        const parsed = JSON.parse(local);
        return [...PRESET_MIMI_PHOTOS, ...parsed];
      } catch (e) {
        console.error("Failed loading local photos", e);
      }
    }
    return PRESET_MIMI_PHOTOS;
  });

  const [activePhoto, setActivePhoto] = useState<MimiPhoto | null>(PRESET_MIMI_PHOTOS[0]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filter, setFilter] = useState<"all" | "cat" | "nature" | "people" | "uploaded" | "favs">("all");
  const [fullscreenPhoto, setFullscreenPhoto] = useState<MimiPhoto | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState(false);
  const [statusNotice, setStatusNotice] = useState<{ text: string; type: "error" | "success" | "info" } | null>(null);
  const [deletedPhotoCache, setDeletedPhotoCache] = useState<MimiPhoto | null>(null);

  useEffect(() => {
    if (statusNotice) {
      const t = setTimeout(() => setStatusNotice(null), 4000);
      return () => clearTimeout(t);
    }
  }, [statusNotice]);

  const undoDelete = () => {
    if (deletedPhotoCache) {
      const updated = [deletedPhotoCache, ...photos.filter(p => p.id !== deletedPhotoCache.id)];
      setPhotos(updated);
      saveUploadedPhotos(updated);
      setActivePhoto(deletedPhotoCache);
      setDeletedPhotoCache(null);
      setStatusNotice({ text: "Restored successfully!", type: "success" });
    }
  };

  // Save dynamically uploaded photos to localstorage (only the custom uploaded ones)
  const saveUploadedPhotos = (allPhotos: MimiPhoto[]) => {
    const uploadedOnly = allPhotos.filter(p => p.category === "uploaded");
    localStorage.setItem("mimi_local_photos", JSON.stringify(uploadedOnly));
  };

  // Listen to incoming assistant photo-request category hooks
  useEffect(() => {
    if (activeCommandPhotoCategory && isOpen) {
      const searchTerms: Record<string, string[]> = {
        cat: ["cat", "বিড়াল", "biral"],
        nature: ["nature", "beach", "mountain", "workspace", "পাহাড়", "সমুদ্র"],
        people: ["people", "family", "পরিবার", "বন্ধন"]
      };

      let matched = photos.find(p => p.category === activeCommandPhotoCategory);
      if (!matched) {
        // Fallback search inside title or tags
        matched = photos.find(p => 
          p.title.toLowerCase().includes(activeCommandPhotoCategory.toLowerCase())
        );
      }

      if (matched) {
        setActivePhoto(matched);
        if (onPhotoSelectedByMimi) {
          onPhotoSelectedByMimi(matched.title);
        }
      }
    }
  }, [activeCommandPhotoCategory, isOpen]);

  // File Upload Handlers (Local Base64 storage)
  const handleFileUpload = (file: File) => {
    if (!file.type.startsWith("image/")) {
      setStatusNotice({ text: "Please upload a valid image file, Dada/Didi!", type: "error" });
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const base64Url = e.target?.result as string;
      if (base64Url) {
        const newPhoto: MimiPhoto = {
          id: `uploaded-${Date.now()}`,
          url: base64Url,
          title: file.name.substring(0, file.name.lastIndexOf('.')) || "Local Snap",
          category: "uploaded",
          timestamp: new Date().toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric"
          }),
          isFavorite: false
        };

        const updated = [newPhoto, ...photos];
        setPhotos(updated);
        saveUploadedPhotos(updated);
        setActivePhoto(newPhoto);
      }
    };
    reader.readAsDataURL(file);
  };

  const onFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileUpload(e.target.files[0]);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  const toggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = photos.map(p => p.id === id ? { ...p, isFavorite: !p.isFavorite } : p);
    setPhotos(updated);
    saveUploadedPhotos(updated);
    if (activePhoto?.id === id) {
      setActivePhoto(updated.find(p => p.id === id) || null);
    }
  };

  const deletePhoto = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const isPreset = !id.startsWith("uploaded-");
    if (isPreset) {
      setStatusNotice({ text: "Dada/Didi, preset system photos elements cannot be deleted.", type: "error" });
      return;
    }

    const photoToDelete = photos.find(p => p.id === id);
    if (photoToDelete) {
      const updated = photos.filter(p => p.id !== id);
      setPhotos(updated);
      saveUploadedPhotos(updated);
      setDeletedPhotoCache(photoToDelete);
      
      setStatusNotice({ text: `Deleted "${photoToDelete.title}".`, type: "info" });
      
      if (activePhoto?.id === id) {
        setActivePhoto(updated[0] || null);
      }
    }
  };

  // Filter implementation
  const filteredPhotos = photos.filter(p => {
    const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase());
    if (!matchesSearch) return false;

    if (filter === "all") return true;
    if (filter === "favs") return !!p.isFavorite;
    return p.category === filter;
  });

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl pointer-events-auto"
          >
            <motion.div 
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              className="relative w-full max-w-5xl h-[90vh] md:h-[80vh] bg-[#0c0c0d] border border-white/10 rounded-[2.5rem] overflow-hidden shadow-2xl flex flex-col"
            >
              {/* Top Bar Navigation */}
              <div className="flex items-center justify-between px-8 py-5 border-b border-white/5 bg-white/[0.02]">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-pink-500 to-rose-500 flex items-center justify-center text-white">
                    <FolderHeart size={18} />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
                      Mimi Photo Vault
                      <span className="text-[9px] px-2 py-0.5 rounded-full bg-yellow-500/20 text-yellow-500 font-mono tracking-normal capitalize flex items-center gap-1">
                        <CloudOff size={10} /> Local Encrypted Sync
                      </span>
                    </h2>
                    <p className="text-[10px] text-white/40">Private home gallery. Strictly local and offline compatible.</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2 px-4 py-2 border border-white/10 hover:border-white/20 bg-white/5 rounded-full text-xs font-semibold cursor-pointer transition-all"
                  >
                    <Upload size={13} className="text-pink-400" />
                    <span>Upload Image</span>
                  </button>
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={onFileInputChange} 
                    accept="image/*" 
                    className="hidden" 
                  />
                  <button 
                    onClick={onClose}
                    className="p-2.5 rounded-full bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-all border border-white/10"
                  >
                    <X size={16} />
                  </button>
                </div>
              </div>

              {/* Notice Banner */}
              <div className="bg-yellow-500/10 border-b border-yellow-500/20 px-8 py-2 text-[11px] text-yellow-300 font-medium flex items-center gap-2">
                <Sparkles size={12} className="shrink-0 animate-pulse" />
                <span>
                  <strong>Privacy Settings:</strong> You declined Google Drive sync. Mimi has automatically stabilized your connection and created a zero-sharing Cloud-Free Private Gallery inside your browser. No data leaves your machine!
                </span>
              </div>

              {/* Main Content Splitted View */}
              <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
                
                {/* Left side: Grid Browser */}
                <div className="w-full md:w-[45%] border-r border-white/5 flex flex-col bg-black/40">
                  {/* Search and Filters */}
                  <div className="p-5 space-y-3 shrink-0">
                    <div className="relative">
                      <Search size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" />
                      <input
                        type="text"
                        placeholder="Search photos in Mimi's album..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-full text-xs text-white placeholder:text-white/30 focus:border-pink-500/40 outline-none transition-all"
                      />
                    </div>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {[
                        { id: "all", label: "All Hub" },
                        { id: "favs", label: "Favorites" },
                        { id: "cat", label: "Cats (বিড়াল)" },
                        { id: "nature", label: "Scenic Spots" },
                        { id: "people", label: "Life Moments" },
                        { id: "uploaded", label: "Uploaded" }
                      ].map(tab => (
                        <button
                          key={tab.id}
                          onClick={() => setFilter(tab.id as any)}
                          className={`px-3 py-1.5 rounded-full text-[10px] font-bold tracking-tight uppercase transition-all ${
                            filter === tab.id 
                              ? "bg-pink-500 text-white shadow-lg shadow-pink-500/20" 
                              : "bg-white/5 hover:bg-white/10 text-white/50"
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Drag-n-Drop & List Container */}
                  <div 
                    onDragEnter={handleDrag}
                    onDragOver={handleDrag}
                    onDragLeave={handleDrag}
                    onDrop={handleDrop}
                    className={`flex-1 overflow-y-auto px-5 pb-5 relative transition-colors ${
                      dragActive ? "bg-pink-500/10 border-2 border-dashed border-pink-500/40" : ""
                    }`}
                  >
                    {filteredPhotos.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-center p-6 border border-white/5 bg-white/[0.01] rounded-2rem">
                        <Image size={36} className="text-white/15 mb-3" />
                        <span className="text-xs font-bold text-white/60">No matching photos found</span>
                        <p className="text-[10px] text-white/30 max-w-[200px] mt-1 pr-1 pl-1">
                          You can easily drag and drop your favorites inside this box to add them to Mimi Photos!
                        </p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-2 gap-3">
                        {filteredPhotos.map(photo => (
                          <div
                            key={photo.id}
                            onClick={() => setActivePhoto(photo)}
                            className={`group relative aspect-square rounded-2xl overflow-hidden cursor-pointer border transition-all ${
                              activePhoto?.id === photo.id 
                                ? "border-pink-500 ring-2 ring-pink-500/30 scale-[0.98]" 
                                : "border-white/5 hover:border-white/20 hover:scale-[1.02]"
                            }`}
                          >
                            <img
                              src={photo.url}
                              alt={photo.title}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity" />
                            <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between text-white md:opacity-0 md:group-hover:opacity-100 transition-opacity">
                              <span className="text-[10px] font-medium truncate drop-shadow-md pr-1">{photo.title}</span>
                              <div className="flex gap-1">
                                <button
                                  onClick={(e) => toggleFavorite(photo.id, e)}
                                  className="p-1 rounded-full bg-black/60 hover:text-red-400 transition-colors"
                                >
                                  <Heart size={10} className={photo.isFavorite ? "fill-red-500 text-red-500" : ""} />
                                </button>
                                {photo.category === "uploaded" && (
                                  <button
                                    onClick={(e) => deletePhoto(photo.id, e)}
                                    className="p-1 rounded-full bg-black/60 hover:text-red-500 transition-colors"
                                  >
                                    <Trash2 size={10} />
                                  </button>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Right side: Selected Active View Frame */}
                <div className="flex-1 flex flex-col bg-black/60 p-6 md:p-8 overflow-y-auto">
                  {activePhoto ? (
                    <div className="flex-1 flex flex-col justify-between gap-6">
                      <div className="flex-1 flex items-center justify-center max-h-[45vh] md:max-h-[50vh] rounded-3xl overflow-hidden border border-white/5 relative bg-black/40 shadow-2xl group/display">
                        <img
                          src={activePhoto.url}
                          alt={activePhoto.title}
                          referrerPolicy="no-referrer"
                          className="max-w-full max-h-full object-contain cursor-zoom-in"
                          onClick={() => setFullscreenPhoto(activePhoto)}
                        />
                        <button
                          onClick={() => setFullscreenPhoto(activePhoto)}
                          className="absolute right-4 bottom-4 px-3 py-1.5 bg-black/75 hover:bg-black border border-white/10 rounded-full text-[10px] font-mono uppercase tracking-widest text-white/80 opacity-0 group-hover/display:opacity-100 transition-all shadow-xl"
                        >
                          Launch Full Screen
                        </button>
                      </div>

                      <div className="space-y-4">
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="flex items-center gap-2 mb-1.5">
                              <span className="text-[9px] font-mono uppercase tracking-widest text-pink-400 px-2 py-0.5 rounded-full bg-pink-500/10">
                                {activePhoto.category === "uploaded" ? "User Album" : `${activePhoto.category} Vault`}
                              </span>
                              <span className="text-[10px] font-mono text-white/30">{activePhoto.timestamp}</span>
                            </div>
                            <h3 className="text-lg font-bold text-white tracking-wide">{activePhoto.title}</h3>
                          </div>

                          <div className="flex items-center gap-2">
                            <button
                              onClick={(e) => toggleFavorite(activePhoto.id, e)}
                              className="p-3 bg-white/5 hover:bg-white/10 rounded-full border border-white/10 transition-colors text-white/70"
                              title="Favorite"
                            >
                              <Heart size={16} className={activePhoto.isFavorite ? "fill-pink-500 text-pink-500" : ""} />
                            </button>
                            {activePhoto.category === "uploaded" && (
                              <button
                                onClick={(e) => deletePhoto(activePhoto.id, e)}
                                className="p-3 bg-white/5 hover:bg-red-500/20 rounded-full border border-white/10 hover:border-red-500/30 transition-all text-red-400"
                                title="Delete Sync Picture"
                              >
                                <Trash2 size={16} />
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Speech trigger examples helper */}
                        <div className="p-5 border border-white/5 bg-white/[0.01] rounded-2xl space-y-2">
                          <span className="text-[9px] font-mono uppercase tracking-[0.2em] text-cyan-400 flex items-center gap-1.5 font-bold">
                            <Sparkles size={11} /> Voice Activation Integration
                          </span>
                          <p className="text-xs text-white/60">
                            Ask Mimi something like:
                          </p>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] text-white/40 font-mono">
                            <div className="flex items-start gap-1">
                              <CornerDownRight size={10} className="shrink-0 text-pink-500 mt-0.5" />
                              <span className="text-white/50">"Mimi, আমার বিড়ালের ছবি দেখাও"</span>
                            </div>
                            <div className="flex items-start gap-1">
                              <CornerDownRight size={10} className="shrink-0 text-pink-500 mt-0.5" />
                              <span className="text-white/50">"Show me gorgeous scenic mountain peaks"</span>
                            </div>
                            <div className="flex items-start gap-1">
                              <CornerDownRight size={10} className="shrink-0 text-pink-500 mt-0.5" />
                              <span className="text-white/50">"Open my photo gallery album"</span>
                            </div>
                            <div className="flex items-start gap-1">
                              <CornerDownRight size={10} className="shrink-0 text-pink-500 mt-0.5" />
                              <span className="text-white/50">"গুগল ফটো এড কর বা ছবি দেখাও"</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex-1 flex flex-col items-center justify-center text-center">
                      <Image size={48} className="text-white/10 mb-4" />
                      <span className="text-sm font-semibold text-white/50">No Active Image Frame Loaded</span>
                      <p className="text-xs text-white/30 max-w-xs mt-1">Select any image from Mimi's side directory or upload high-definition captures to begin.</p>
                    </div>
                  )}
                </div>

              </div>

              {/* Toast notification popup */}
              <AnimatePresence>
                {statusNotice && (
                  <motion.div
                    initial={{ opacity: 0, y: 15, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className={`absolute bottom-6 left-1/2 -translate-x-1/2 z-[80] px-5 py-3 rounded-2xl border text-xs font-semibold shadow-xl flex items-center gap-3 backdrop-blur-xl ${
                      statusNotice.type === "error" 
                        ? "bg-red-950/85 border-red-500/30 text-red-200 shadow-red-950/20" 
                        : statusNotice.type === "success"
                        ? "bg-emerald-950/85 border-emerald-500/30 text-emerald-200 shadow-emerald-950/20"
                        : "bg-zinc-900/90 border-zinc-700/55 text-zinc-100 shadow-black/40"
                    }`}
                  >
                    <span>{statusNotice.text}</span>
                    {statusNotice.text.includes("Deleted") && deletedPhotoCache && (
                      <button 
                        onClick={(ev) => {
                          ev.stopPropagation();
                          undoDelete();
                        }} 
                        className="text-pink-400 hover:text-pink-300 underline font-bold transition-colors cursor-pointer"
                      >
                        Undo
                      </button>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Full screen lightbox */}
      <AnimatePresence>
        {fullscreenPhoto && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setFullscreenPhoto(null)}
            className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-2xl flex flex-col items-center justify-center p-4 cursor-zoom-out"
          >
            <button 
              onClick={() => setFullscreenPhoto(null)}
              className="absolute top-6 right-6 p-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-white/80 transition-all"
            >
              <X size={18} />
            </button>
            <div className="relative max-w-full max-h-[85vh] flex items-center justify-center">
              <img
                src={fullscreenPhoto.url}
                alt={fullscreenPhoto.title}
                referrerPolicy="no-referrer"
                className="max-w-full max-h-[85vh] rounded-2xl object-contain shadow-2xl"
              />
            </div>
            <div className="absolute bottom-10 left-1/2 -translate-x-1/2 text-center bg-black/40 px-6 py-2 border border-white/5 rounded-full text-xs font-medium text-white shadow-xl">
              {fullscreenPhoto.title}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
