import React from "react";
import { 
  X, 
  HelpCircle, 
  AlertTriangle, 
  Globe, 
  UserPlus, 
  Key, 
  ExternalLink, 
  CheckCircle,
  Shield,
  CornerDownRight,
  RefreshCw
} from "lucide-react";
import { motion } from "motion/react";

interface DiagnosticsProps {
  isOpen: boolean;
  onClose: () => void;
  error: {
    code: string;
    message: string;
    rawError?: any;
    flowType?: "standard" | "workspace";
  } | null;
  onRetryBasic: () => Promise<void>;
  onRetryWorkspace: () => Promise<void>;
}

export default function GoogleAuthDiagnostics({
  isOpen,
  onClose,
  error,
  onRetryBasic,
  onRetryWorkspace
}: DiagnosticsProps) {
  if (!isOpen || !error) return null;

  const currentHost = window.location.host;
  const currentOrigin = window.location.origin;

  // Auto-detect root causes
  let rootCause = "OAuth handshake interrupted";
  let description = "The authentication popup was closed or lost connection during the security handshake, or the credentials require active verification.";
  let steps: { title: string; desc: string; link?: string }[] = [];
  let errorIndicator = "⚠️ handshake_failure";

  const isPopupClosed = error.code === "auth/popup-closed-by-user";
  const isDomainError = error.code === "auth/unauthorized-domain";
  const isConfigError = error.code === "auth/operation-not-allowed" || error.code === "auth/configuration-not-found";
  const isNetworkError = error.code && (error.code.includes("network") || error.message.toLowerCase().includes("network"));

  if (isDomainError) {
    errorIndicator = "🔒 auth/unauthorized-domain";
    rootCause = "Unauthorized Preview Domain Block";
    description = `Firebase has blocked login requests because your dynamic preview domain is not on your Firebase app's domain trustlist.`;
    steps = [
      {
        title: "Go to Firebase Console",
        desc: "Open your project in the Firebase Console dashboard.",
        link: "https://console.firebase.google.com/"
      },
      {
        title: "Trust are Authorized Domains",
        desc: `Navigate to Authentication -> Settings -> Authorized Domains, and add "${currentHost}" to the trustlist.`
      },
      {
        title: "Add standard Authorized Redirect URIs",
        desc: `In API Credentials under Google Cloud Console, ensure "${currentOrigin}" is safelisted under Authorized JavaScript Origins.`
      }
    ];
  } else if (isConfigError) {
    errorIndicator = "⚙️ auth/operation-not-allowed";
    rootCause = "Google Sign-In Disabled";
    description = "The Google Authentication Provider is not enabled under your Firebase Project's authentication console, or credentials are out of sync.";
    steps = [
      {
        title: "Enable Google Authentication Provider",
        desc: "Open Firebase Console -> Authentication -> Sign-in Method section.",
        link: "https://console.firebase.google.com/"
      },
      {
        title: "Toggle Google Active",
        desc: "Enable Google in the provider list, fill out public project name and contact emails."
      },
      {
        title: "Set OAuth Credentials",
        desc: "Verify that the Web Client ID and Web Client Secret matched from Google Cloud Platform settings are populated correctly."
      }
    ];
  } else if (isPopupClosed && error.flowType === "workspace") {
    // If popup was closed during workspace flow, it's highly likely because of "Google hasn't verified this app"
    // and the user or missing test user closed the page, or because they need to be a Test User.
    errorIndicator = "🛠️ sensitive_scopes_restricted";
    rootCause = "Google App Verification Bypass Required";
    description = "Mimi has requested advanced Google Workspace permissions (Gmail, Drive, Tasks). Since this workspace application is currently in development sandbox mode, you must explicitly opt-in as a test user or bypass the warning screen.";
    steps = [
      {
        title: "Bypass Google Verification Screen",
        desc: "When the Google popup opens, click 'Advanced' at the bottom-left, followed by 'Go to Mimi (unsafe)' to securely log in.",
      },
      {
        title: "Register your accounts as Test Users",
        desc: "Open your Google Cloud Console Console, go to APIs & Services -> OAuth Consent Screen, scroll to 'Test Users' and add your email.",
        link: "https://console.cloud.google.com/apis/credentials/consent"
      },
      {
        title: "Use Standard Safe Login Flow instead",
        desc: "If you don't need advanced integrations right now, click 'Use Standard Basic Login' below, which is pre-approved and has zero warnings!"
      }
    ];
  } else {
    // General / Miscellaneous Handshake error
    errorIndicator = `🔴 ${error.code || "auth/handshake-failed"}`;
    rootCause = "Authentication Interaction Interrupted";
    description = error.message.includes("Popup closed") 
      ? "The Google login drawer was closed by the user or security block before the handshake completed."
      : `An unexpected auth event occurred during interaction: ${error.message}`;
    steps = [
      {
        title: "Verify your email is in Google Test list",
        desc: "If this Google Cloud project is in testing state, only registered Test Users can authorize successfully.",
        link: "https://console.cloud.google.com/apis/credentials/consent"
      },
      {
        title: "Allow popups and search redirects",
        desc: "Verify that your browser or ad-blocker is not preventing authenticators or popup windows from loading."
      },
      {
        title: "Bypass verification blocks",
        desc: "If warning pages show, use 'Advanced' -> 'Go to Mimi (unsafe)' or authenticate via the Basic Login option."
      }
    ];
  }

  return (
    <div 
      className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md"
      id="auth-diagnostics-modal"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-3xl bg-[#0b0c10] border border-white/10 shadow-2xl p-6 md:p-8 text-white font-sans scrollbar-thin scrollbar-thumb-white/10"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition-all cursor-pointer"
          id="close-diagnostics-btn"
          title="Dismiss diagnostics panel"
        >
          <X size={18} />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3.5 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-violet-600/10 border border-violet-500/20 flex items-center justify-center text-violet-400">
            <Shield size={24} />
          </div>
          <div>
            <span className="text-[10px] bg-red-500/10 border border-red-500/20 text-red-400 font-mono px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
              Diagnostics Assistant
            </span>
            <h3 className="text-lg font-black tracking-tight text-white mt-0.5">
              Google Auth Troubleshooting Hub
            </h3>
          </div>
        </div>

        {/* Root Cause Banner */}
        <div className="bg-gradient-to-r from-red-950/20 to-violet-950/20 border border-white/5 rounded-2xl p-5 mb-5">
          <div className="flex items-center gap-2 text-red-400 font-bold text-sm">
            <AlertTriangle size={16} />
            <span>{rootCause}</span>
          </div>
          <p className="text-xs text-white/70 leading-relaxed mt-2 pl-6">
            {description}
          </p>
          <div className="mt-3.5 pl-6 flex items-center gap-2">
            <span className="text-[9px] font-mono font-black text-white/40 uppercase">Detected state:</span>
            <span className="text-[10px] font-mono text-cyan-300 bg-cyan-950/30 px-2 py-0.5 rounded border border-cyan-500/20">
              {errorIndicator}
            </span>
          </div>
        </div>

        {/* Runtime Diagnostics Variables Card */}
        <div className="p-4 bg-white/[0.02] border border-white/5 rounded-2xl space-y-2 mb-5">
          <h4 className="text-[10px] font-bold text-white/40 uppercase tracking-widest flex items-center gap-1.5 pl-1">
            <Globe size={11} />
            <span>Detected Deployment Manifest</span>
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[10px] font-mono text-white/60">
            <div className="bg-black/40 p-2.5 rounded-xl border border-white/5">
              <span className="text-white/30 block mb-0.5">CURRENT HOST:</span>
              <span className="select-all text-white font-bold">{currentHost}</span>
            </div>
            <div className="bg-black/40 p-2.5 rounded-xl border border-white/5">
              <span className="text-white/30 block mb-0.5">REDIRECT / ORIGIN:</span>
              <span className="select-all text-violet-300 font-bold">{currentOrigin}</span>
            </div>
            <div className="bg-black/40 p-2.5 rounded-xl border border-white/5 md:col-span-2">
              <span className="text-white/30 block mb-0.5">REQUESTED PERMISSIONS:</span>
              <span className="text-fuchsia-300 font-semibold font-mono">
                {error.flowType === "workspace" 
                  ? "Gmail, Drive, Tasks, Sheets, Chat (Sensitive API Nodes)" 
                  : "Profile, Email (Verified Basic User Node)"}
              </span>
            </div>
          </div>
        </div>

        {/* Step by Step Manual configuration */}
        <div className="space-y-3 mb-6">
          <h4 className="text-[10px] font-bold text-white/40 uppercase tracking-widest pl-1">
            System Resolution Checklist
          </h4>
          
          <div className="space-y-2.5">
            {steps.map((step, idx) => (
              <div 
                key={idx} 
                className="flex items-start gap-3 p-3.5 rounded-2xl bg-black/25 border border-white/5 hover:border-white/10 transition-colors"
              >
                <div className="w-5 h-5 rounded-full bg-violet-600/10 border border-violet-500/20 text-violet-400 flex items-center justify-center font-mono text-[9px] font-black shrink-0 mt-0.5">
                  {idx + 1}
                </div>
                <div className="flex-1 space-y-1">
                  <p className="text-xs font-bold text-sky-200">{step.title}</p>
                  <p className="text-[10px] text-white/50 leading-relaxed">{step.desc}</p>
                  {step.link && (
                    <a 
                      href={step.link} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="inline-flex items-center gap-1 text-[10px] text-violet-400 hover:text-violet-300 font-bold transition-colors mt-1.5"
                    >
                      <span>Open Configuration Dashboard</span>
                      <ExternalLink size={10} />
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Tray */}
        <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-white/5">
          <button
            onClick={async () => {
              onClose();
              await onRetryBasic();
            }}
            id="auth-retry-basic-disabled-warning"
            className="flex-1 py-3 px-2 rounded-2xl bg-white/5 hover:bg-white/10 text-white hover:text-white border border-white/10 text-xs font-bold transition-all uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 cursor-pointer"
            title="Authenticate instantly without authorization blocks"
          >
            <CheckCircle size={14} className="text-emerald-400 animate-pulse" />
            <span className="truncate">Use Standard Basic Login</span>
          </button>

          <button
            onClick={async () => {
              onClose();
              await onRetryWorkspace();
            }}
            id="auth-retry-workspace-btn"
            className="flex-1 py-3 px-2 rounded-2xl bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white text-xs font-black transition-all uppercase tracking-widest shadow-xl shadow-violet-950/50 flex items-center justify-center gap-2 cursor-pointer"
            title="Retry workspace login flow"
          >
            <RefreshCw size={13} className="text-white" />
            <span className="truncate">Retry Safe Authorization</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
}
