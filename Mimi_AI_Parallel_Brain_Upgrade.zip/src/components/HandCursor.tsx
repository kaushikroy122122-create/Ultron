import React, { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { handTracker } from "../services/handTrackingService";

interface HandCursorProps {
  stream: MediaStream | null;
  onGesture?: (type: "click" | "scroll" | "move", data: any) => void;
  active: boolean;
}

export const HandCursor: React.FC<HandCursorProps> = ({ stream, onGesture, active }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [cursorPos, setCursorPos] = useState({ x: 0, y: 0 });
  const [isPinching, setIsPinching] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  
  // Ref to track state for the animation loop
  const stateRef = useRef({
    pinching: false,
    lastClickTime: 0,
    lastTimestamp: -1,
    isLooping: false
  });

  useEffect(() => {
    if (active && stream && videoRef.current) {
      videoRef.current.srcObject = stream;
      
      let animationId: number;
      const state = stateRef.current;
      state.isLooping = true;

      const process = async () => {
        try {
          await handTracker.initialize();

          const loop = (time: number) => {
            if (!state.isLooping) return;

            if (!videoRef.current || videoRef.current.readyState < 2) {
              animationId = requestAnimationFrame(loop);
              return;
            }

            if (time <= state.lastTimestamp) {
              animationId = requestAnimationFrame(loop);
              return;
            }
            state.lastTimestamp = time;

            const result = handTracker.detectContent(videoRef.current, time);
            if (result && result.landmarks && result.landmarks.length > 0) {
              setIsVisible(true);
              const hand = result.landmarks[0];
              
              // Index finger tip is landmark 8
              // Thumb tip is landmark 4
              const indexTip = hand[8];
              const thumbTip = hand[4];

              // Normalize coordinates to screen (flipping X if needed for mirroring)
              const x = (1 - indexTip.x) * window.innerWidth;
              const y = indexTip.y * window.innerHeight;
              
              setCursorPos({ x, y });

              // Detect pinch (click)
              const distance = Math.sqrt(
                Math.pow(indexTip.x - thumbTip.x, 2) + 
                Math.pow(indexTip.y - thumbTip.y, 2) + 
                Math.pow(indexTip.z - thumbTip.z, 2)
              );

              // Threshold for pinch depends on camera distance, but ~0.05 is usually good for normalized units
              const pinching = distance < 0.05;
              
              if (pinching && !state.pinching) {
                // Click started
                onGesture?.("click", { x, y });
                state.lastClickTime = Date.now();
                
                // Trigger a real mouse click at those coordinates
                const element = document.elementFromPoint(x, y);
                if (element) {
                  (element as HTMLElement).click();
                }
              }
              
              state.pinching = pinching;
              setIsPinching(pinching);
            } else {
              setIsVisible(false);
            }

            animationId = requestAnimationFrame(loop);
          };

          animationId = requestAnimationFrame(loop);
        } catch (err) {
          console.error("Hand tracking error", err);
        }
      };

      process();
      return () => {
        state.isLooping = false;
        cancelAnimationFrame(animationId);
      };
    } else {
      setIsVisible(false);
    }
  }, [active, stream, onGesture]);

  if (!active) return null;

  return (
    <>
      <video ref={videoRef} className="hidden" aria-hidden="true" muted />
      <AnimatePresence>
        {isVisible && (
          <motion.div
            className="fixed pointer-events-none z-[9999]"
            initial={{ scale: 0, opacity: 0 }}
            animate={{ 
              x: cursorPos.x - 12, 
              y: cursorPos.y - 12,
              scale: isPinching ? 0.8 : 1,
              opacity: 1
            }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ type: "spring", damping: 20, stiffness: 300, mass: 0.5 }}
          >
            {/* The Outer Ring */}
            <div className={`w-6 h-6 border-2 rounded-full flex items-center justify-center transition-colors duration-200 ${isPinching ? 'border-cyan-400 bg-cyan-400/20' : 'border-white/50'}`}>
               {/* Inner Dot */}
               <div className={`w-1.5 h-1.5 rounded-full ${isPinching ? 'bg-white' : 'bg-cyan-400 opacity-50'}`} />
            </div>
            
            {/* Click ripple effect */}
            {isPinching && (
              <motion.div 
                className="absolute inset-0 bg-cyan-400 rounded-full"
                initial={{ scale: 1, opacity: 0.5 }}
                animate={{ scale: 2.5, opacity: 0 }}
                transition={{ duration: 0.3 }}
              />
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
