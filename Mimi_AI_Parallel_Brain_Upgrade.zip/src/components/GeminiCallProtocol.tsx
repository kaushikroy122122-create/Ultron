import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Phone, PhoneCall, PhoneOff, Mic, MicOff, Volume2, 
  Cpu, Sparkles, Activity, ShieldCheck, Zap, Radio, 
  Settings, CheckCircle2, RefreshCw, X
} from "lucide-react";

interface GeminiCallProtocolProps {
  isOpen: boolean;
  onClose: () => void;
  isSessionActive: boolean;
  onToggleCall: () => void;
  appState: "idle" | "connecting" | "listening" | "thinking" | "processing" | "speaking";
  isMuted: boolean;
  onToggleMute: () => void;
  activeModel?: string;
  onSelectModel?: (model: string) => void;
  userName?: string;
}

export default function GeminiCallProtocol({
  isOpen,
  onClose,
  isSessionActive,
  onToggleCall,
  appState,
  isMuted,
  onToggleMute,
  activeModel = "gemini-2.5-flash-native-audio-preview-12-2025",
  onSelectModel,
  userName = "Dada/Didi"
}: GeminiCallProtocolProps) {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [isDiagnosticRunning, setIsDiagnosticRunning] = useState<boolean>(false);
  const [callDuration, setCallDuration] = useState<number>(0);

  // Auto increment call timer when session is active
  useEffect(() => {
    let timer: any = null;
    if (isSessionActive) {
      timer = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      setCallDuration(0);
    }
    return () => clearInterval(timer);
  }, [isSessionActive]);


  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const steps = [
    {
      step: 1,
      title: "Real-time Live Audio BiDi",
      desc: "Live audio stream via the server WebSocket bridge; latency depends on network and provider.",
      model: "gemini-2.5-flash-native-audio-preview-12-2025",
      status: isSessionActive ? "Streaming" : "Standby",
      color: "from-cyan-400 to-blue-500",
      accent: "text-cyan-400"
    },
    {
      step: 2,
      title: "Cognitive Neural Engine",
      desc: "Deep reasoning, contextual memory recall, and smart intent recognition.",
      model: "gemini-2.5-flash",
      status: (appState === "processing" || appState === "thinking") ? "Synthesizing" : "Synchronized",
      color: "from-violet-500 to-purple-600",
      accent: "text-violet-400"
    },
    {
      step: 3,
      title: "Studio Vocalization System",
      desc: "Gemini text-to-speech output; available voices depend on the connected API.",
      model: "gemini-2.5-flash-preview-tts",
      status: appState === "speaking" ? "Speaking" : "Ready",
      color: "from-pink-500 to-rose-600",
      accent: "text-pink-400"
    },
    {
      step: 4,
      title: "Autopilot Grounding Link",
      desc: "Real-time Google search grounding, GPS maps, and local system integration.",
      model: "google-search-grounding",
      status: "Active",
      color: "from-amber-400 to-emerald-500",
      accent: "text-amber-400"
    }
  ];

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="relative w-full max-w-4xl max-h-[90vh] flex flex-col bg-[#090a10] border border-cyan-500/30 rounded-3xl shadow-[0_0_60px_rgba(6,182,212,0.25)] overflow-hidden"
        >
          {/* Ambient colorful top glow */}
          <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-48 bg-gradient-to-r from-cyan-500 via-pink-500 to-violet-500 opacity-25 blur-3xl pointer-events-none" />

          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 z-10 bg-white/2 backdrop-blur-md">
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10 rounded-xl overflow-hidden p-0.5 bg-gradient-to-tr from-cyan-400 via-pink-500 to-violet-500 shadow-[0_0_15px_rgba(34,211,238,0.5)]">
                <img 
                  src="/src/assets/images/gemini_smart_step_3d_1793560483598.jpg" 
                  alt="3D Gemini Core" 
                  className="w-full h-full object-cover rounded-[10px]"
                />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-black tracking-wider uppercase bg-clip-text text-transparent bg-gradient-to-r from-cyan-300 via-pink-400 to-violet-300">
                    Gemini Call Protocol v4.0
                  </h2>
                  <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 uppercase tracking-widest animate-pulse">
                    Online
                  </span>
                </div>
                <p className="text-[11px] text-white/50 font-sans">
                  Artificially Intelligent 3D Smart Step Voice Communication System
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setIsDiagnosticRunning(true);
                  setTimeout(() => setIsDiagnosticRunning(false), 1200);
                }}
                className="p-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-white/70 hover:text-white transition-all text-xs flex items-center gap-1.5 cursor-pointer"
                title="Refresh Gemini Protocol Telemetry"
              >
                <RefreshCw size={13} className={isDiagnosticRunning ? "animate-spin text-cyan-400" : ""} />
                <span className="hidden sm:inline text-[10px] font-mono">Calibrate</span>
              </button>
              <button
                onClick={onClose}
                className="p-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-white/70 hover:text-white transition-colors cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>
          </div>

          {/* Body Content */}
          <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-6 z-10">
            {/* Top 3D Interactive Call Stage */}
            <div className="relative p-6 rounded-3xl bg-gradient-to-b from-[#10121d] to-[#0a0b12] border border-white/10 overflow-hidden shadow-2xl">
              <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                
                {/* 3D Holographic Gemini Brand Star Avatar */}
                <div className="relative flex items-center justify-center">
                  <div className="relative w-36 h-36 flex items-center justify-center">
                    {/* Multi-layered spinning colorful aura rings */}
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 16, repeat: Infinity, ease: "linear" }}
                      className="absolute inset-0 rounded-full border-2 border-dashed border-cyan-400/30"
                    />
                    <motion.div
                      animate={{ rotate: -360 }}
                      transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                      className="absolute inset-2 rounded-full border border-pink-500/40 border-dotted"
                    />
                    <motion.div
                      animate={{ scale: isSessionActive ? [1, 1.08, 1] : [1, 1.02, 1] }}
                      transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                      className="w-28 h-28 rounded-full overflow-hidden p-1 bg-gradient-to-tr from-cyan-400 via-pink-500 via-violet-500 to-amber-300 shadow-[0_0_35px_rgba(236,72,153,0.5)] relative"
                    >
                      <img 
                        src="/src/assets/images/gemini_smart_step_3d_1793560483598.jpg" 
                        alt="3D Gemini Smart Star" 
                        className="w-full h-full object-cover rounded-full"
                      />
                      {/* Active Live Pulse Core */}
                      {isSessionActive && (
                        <div className="absolute inset-0 rounded-full bg-cyan-400/20 animate-ping pointer-events-none" />
                      )}
                    </motion.div>
                  </div>
                </div>

                {/* Status & Realtime Call Telemetry */}
                <div className="flex-1 text-center md:text-left space-y-2">
                  <div className="flex items-center justify-center md:justify-start gap-2">
                    <span className="text-[10px] uppercase font-mono tracking-widest text-cyan-400 font-bold">
                      Protocol Status:
                    </span>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold uppercase ${
                      isSessionActive 
                        ? "bg-rose-500/20 text-rose-300 border border-rose-500/30" 
                        : "bg-white/10 text-white/70"
                    }`}>
                      {isSessionActive ? `In Call (${formatTimer(callDuration)})` : "Standby"}
                    </span>
                  </div>

                  <h3 className="text-xl md:text-2xl font-black text-white">
                    {isSessionActive ? "Mimi Voice Call Active" : "Ready for Gemini Voice Call"}
                  </h3>
                  
                  <p className="text-xs text-white/60 max-w-md leading-relaxed">
                    {isSessionActive 
                      ? "Live Gemini audio conversation; actual latency depends on device, network and provider." 
                      : `Press 'Start Call' to talk directly with Mimi in natural spoken voice. Hello ${userName}!`}
                  </p>

                  {/* Realtime Telemetry Pills */}
                  <div className="flex items-center justify-center md:justify-start gap-3 pt-2 text-[10px] font-mono text-white/50">
                    <div className="flex items-center gap-1.5 bg-black/40 px-2.5 py-1 rounded-lg border border-white/5">
                      <Zap size={11} className="text-amber-400" />
                      <span>Latency: <strong className="text-white">Network-dependent</strong></span>
                    </div>
                    <div className="flex items-center gap-1.5 bg-black/40 px-2.5 py-1 rounded-lg border border-white/5">
                      <Radio size={11} className="text-cyan-400" />
                      <span>Rate: <strong className="text-white">24kHz PCM</strong></span>
                    </div>
                    <div className="flex items-center gap-1.5 bg-black/40 px-2.5 py-1 rounded-lg border border-white/5">
                      <Cpu size={11} className="text-violet-400" />
                      <span>Core: <strong className="text-white">Gemini 4 / 3.8 Live</strong></span>
                    </div>
                  </div>
                </div>

                {/* Primary Voice Action Button */}
                <div className="flex flex-col items-center gap-2">
                  <button
                    onClick={onToggleCall}
                    className={`px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-wider flex items-center gap-3 transition-all duration-300 shadow-xl cursor-pointer active:scale-95 ${
                      isSessionActive
                        ? "bg-gradient-to-r from-red-600 to-rose-600 text-white shadow-[0_0_30px_rgba(239,68,68,0.6)] hover:brightness-110"
                        : "bg-gradient-to-r from-cyan-400 via-pink-500 to-violet-600 text-white shadow-[0_0_30px_rgba(236,72,153,0.6)] hover:brightness-115 hover:scale-105"
                    }`}
                  >
                    {isSessionActive ? (
                      <>
                        <PhoneOff size={18} className="animate-bounce" />
                        <span>End Gemini Call</span>
                      </>
                    ) : (
                      <>
                        <PhoneCall size={18} className="animate-pulse" />
                        <span>Start Gemini Call</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={onToggleMute}
                    className={`px-4 py-1.5 rounded-xl text-[10px] font-mono font-bold flex items-center gap-2 border transition-all ${
                      isMuted 
                        ? "bg-amber-500/20 text-amber-300 border-amber-500/30" 
                        : "bg-white/5 text-white/70 border-white/10 hover:bg-white/10 hover:text-white"
                    }`}
                  >
                    {isMuted ? <MicOff size={11} /> : <Mic size={11} />}
                    <span>{isMuted ? "Unmute Mic" : "Mute Mic"}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Smart 4-Step Brand Progression Architecture */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] uppercase tracking-wider font-mono font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-pink-400 to-amber-300">
                  Smart Step Gemini Architecture Flow
                </span>
                <span className="text-[10px] text-white/40 font-mono">
                  4-Phase Synchronized Processing
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {steps.map((st) => (
                  <div
                    key={st.step}
                    onClick={() => setActiveStep(st.step)}
                    className={`relative p-4 rounded-2xl border transition-all duration-300 cursor-pointer overflow-hidden ${
                      activeStep === st.step
                        ? "bg-[#141624] border-cyan-400/50 shadow-[0_0_20px_rgba(6,182,212,0.25)]"
                        : "bg-[#0c0d16] border-white/5 hover:border-white/20 hover:bg-[#10121d]"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-mono font-black text-xs text-white bg-gradient-to-tr ${st.color} shadow-md`}>
                        0{st.step}
                      </div>
                      <span className={`text-[9px] font-mono font-bold uppercase ${st.accent}`}>
                        {st.status}
                      </span>
                    </div>

                    <h4 className="text-xs font-bold text-white mb-1">
                      {st.title}
                    </h4>

                    <p className="text-[10px] text-white/50 leading-relaxed mb-3">
                      {st.desc}
                    </p>

                    <div className="pt-2 border-t border-white/5 flex items-center justify-between font-mono text-[9px] text-white/40">
                      <span>MODEL</span>
                      <span className="text-white/80 font-bold">{st.model}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Gemini Model Selector & Voice Profile Dock */}
            <div className="p-4 rounded-2xl bg-black/40 border border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-violet-500/10 border border-violet-500/20 text-violet-400">
                  <Cpu size={18} />
                </div>
                <div>
                  <h5 className="text-xs font-bold text-white">Active Gemini Model Engine</h5>
                  <p className="text-[10px] text-white/50">Select the configured Gemini Live model. Availability depends on your Google API project.</p>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {["gemini-2.5-flash-native-audio-preview-12-2025"].map((m) => (
                  <button
                    key={m}
                    onClick={() => onSelectModel && onSelectModel(m)}
                    className={`px-3 py-1.5 rounded-xl text-[10px] font-mono font-bold transition-all border ${
                      activeModel === m
                        ? "bg-gradient-to-r from-cyan-500 to-violet-600 text-white border-white/30 shadow-[0_0_12px_rgba(34,211,238,0.4)]"
                        : "bg-white/5 text-white/60 border-white/10 hover:text-white hover:bg-white/10"
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Footer note */}
          <div className="px-6 py-3 border-t border-white/5 bg-black/60 flex items-center justify-between text-[10px] font-mono text-white/40">
            <span>GEMINI LIVE PROTOCOL: STABLE (v4.0 / 3.8 LIVE)</span>
            <span className="text-cyan-400">ENCRYPTION: SECURE TLS / WSS</span>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
