import React, { useState } from "react";
import { X, MessageCircle, Youtube, Globe, Search, Activity } from "lucide-react";
import { MimiWhatsAppWeb } from "./MimiWhatsAppWeb";
import { MimiYouTubePlayer } from "./MimiYouTubePlayer";
import { MimiChromeBrowser } from "./MimiChromeBrowser";
import { DiagnosticLog } from "../services/selfRepairService";

interface WhatsAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  recipient?: string;
  phone?: string;
  message?: string;
  url?: string;
  darkMode?: boolean;
}

export const WhatsAppModal: React.FC<WhatsAppModalProps> = ({
  isOpen,
  onClose,
  recipient = "Kaushik Roy",
  phone = "9876543210",
  message = "",
  url = "https://web.whatsapp.com",
  darkMode = false,
}) => {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="WhatsApp Hub"
      className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-center justify-center p-3 md:p-6"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className={`w-full max-w-4xl max-h-[88vh] rounded-3xl border shadow-2xl flex flex-col overflow-hidden ${
          darkMode
            ? "bg-[#22211E] border-[#383630] text-[#F2EFE9]"
            : "bg-[#FAF9F5] border-[#E5E2D9] text-[#1F1E1B]"
        }`}
      >
        <div
          className={`px-5 py-3.5 border-b flex items-center justify-between ${
            darkMode ? "border-[#383630]" : "border-[#E5E2D9]"
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-600/15 text-emerald-700 dark:text-emerald-400 flex items-center justify-center">
              <MessageCircle size={18} />
            </div>
            <div>
              <h2 className="text-base font-semibold">WhatsApp Hub</h2>
              <p className={`text-xs ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>
                Direct messaging & assistant drafts
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close WhatsApp Modal"
            className={`min-h-[38px] min-w-[38px] rounded-xl border flex items-center justify-center cursor-pointer ${
              darkMode
                ? "bg-[#2A2925] border-[#383630] text-[#F2EFE9]"
                : "bg-[#F3F1EA] border-[#E5E2D9] text-[#1F1E1B]"
            }`}
          >
            <X size={16} />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-3 md:p-4 bg-[#0B111E]">
          <MimiWhatsAppWeb recipient={recipient} phone={phone} message={message} url={url} />
        </div>
      </div>
    </div>
  );
};

interface YouTubeModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuery?: string;
  darkMode?: boolean;
}

export const YouTubeModal: React.FC<YouTubeModalProps> = ({
  isOpen,
  onClose,
  initialQuery = "relaxing lofi instrumental music",
  darkMode = false,
}) => {
  const [draft, setDraft] = useState(initialQuery);
  const [activeQuery, setActiveQuery] = useState(initialQuery);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="YouTube Media Player"
      className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-center justify-center p-3 md:p-6"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className={`w-full max-w-2xl rounded-3xl border shadow-2xl flex flex-col overflow-hidden ${
          darkMode
            ? "bg-[#22211E] border-[#383630] text-[#F2EFE9]"
            : "bg-[#FAF9F5] border-[#E5E2D9] text-[#1F1E1B]"
        }`}
      >
        <div
          className={`px-5 py-3.5 border-b flex items-center justify-between ${
            darkMode ? "border-[#383630]" : "border-[#E5E2D9]"
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-600/15 text-rose-600 dark:text-rose-400 flex items-center justify-center">
              <Youtube size={18} />
            </div>
            <div>
              <h2 className="text-base font-semibold">YouTube Player</h2>
              <p className={`text-xs ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>
                Search & play songs or videos cleanly
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close YouTube Modal"
            className={`min-h-[38px] min-w-[38px] rounded-xl border flex items-center justify-center cursor-pointer ${
              darkMode
                ? "bg-[#2A2925] border-[#383630] text-[#F2EFE9]"
                : "bg-[#F3F1EA] border-[#E5E2D9] text-[#1F1E1B]"
            }`}
          >
            <X size={16} />
          </button>
        </div>

        <div className="p-4 space-y-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (draft.trim()) setActiveQuery(draft.trim());
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder="Search song, artist, or video..."
              className={`flex-1 min-h-[42px] rounded-xl border px-3.5 text-sm focus:outline-none ${
                darkMode
                  ? "bg-[#191816] border-[#383630] text-[#F2EFE9]"
                  : "bg-white border-[#DDD8CC] text-[#1F1E1B]"
              }`}
            />
            <button
              type="submit"
              className="min-h-[42px] px-4 rounded-xl bg-[#C96442] hover:bg-[#B55534] text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <Search size={14} />
              <span>Play</span>
            </button>
          </form>

          <MimiYouTubePlayer
            query={activeQuery}
            url={`https://www.youtube.com/results?search_query=${encodeURIComponent(activeQuery)}`}
          />
        </div>
      </div>
    </div>
  );
};

interface BrowserModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode?: boolean;
}

export const BrowserModal: React.FC<BrowserModalProps> = ({
  isOpen,
  onClose,
  darkMode = false,
}) => {
  const [inputUrl, setInputUrl] = useState("https://en.wikipedia.org/wiki/Artificial_intelligence");
  const [activeTarget, setActiveTarget] = useState({
    url: "https://en.wikipedia.org/wiki/Artificial_intelligence",
    query: "Artificial intelligence",
  });

  if (!isOpen) return null;

  const handleGo = (e: React.FormEvent) => {
    e.preventDefault();
    const val = inputUrl.trim();
    if (!val) return;
    const isUrl = /^https?:\/\//i.test(val) || /^[a-z0-9-]+\.[a-z]{2,}/i.test(val);
    if (isUrl) {
      const normalized = val.startsWith("http") ? val : `https://${val}`;
      setActiveTarget({ url: normalized, query: val });
    } else {
      setActiveTarget({
        url: `https://www.google.com/search?q=${encodeURIComponent(val)}`,
        query: val,
      });
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Mimi Web Browser"
      className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-center justify-center p-3 md:p-6"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className={`w-full max-w-3xl max-h-[88vh] rounded-3xl border shadow-2xl flex flex-col overflow-hidden ${
          darkMode
            ? "bg-[#22211E] border-[#383630] text-[#F2EFE9]"
            : "bg-[#FAF9F5] border-[#E5E2D9] text-[#1F1E1B]"
        }`}
      >
        <div
          className={`px-5 py-3.5 border-b flex items-center justify-between ${
            darkMode ? "border-[#383630]" : "border-[#E5E2D9]"
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#C96442]/15 text-[#C96442] flex items-center justify-center">
              <Globe size={18} />
            </div>
            <div>
              <h2 className="text-base font-semibold">Web Browser & Reader</h2>
              <p className={`text-xs ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>
                Browse URLs or search websites directly
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Browser Modal"
            className={`min-h-[38px] min-w-[38px] rounded-xl border flex items-center justify-center cursor-pointer ${
              darkMode
                ? "bg-[#2A2925] border-[#383630] text-[#F2EFE9]"
                : "bg-[#F3F1EA] border-[#E5E2D9] text-[#1F1E1B]"
            }`}
          >
            <X size={16} />
          </button>
        </div>

        <div className="p-4 space-y-3 overflow-y-auto">
          <form onSubmit={handleGo} className="flex items-center gap-2">
            <input
              type="text"
              value={inputUrl}
              onChange={(e) => setInputUrl(e.target.value)}
              placeholder="Enter URL or search query..."
              className={`flex-1 min-h-[42px] rounded-xl border px-3.5 text-sm focus:outline-none ${
                darkMode
                  ? "bg-[#191816] border-[#383630] text-[#F2EFE9]"
                  : "bg-white border-[#DDD8CC] text-[#1F1E1B]"
              }`}
            />
            <button
              type="submit"
              className="min-h-[42px] px-4 rounded-xl bg-[#C96442] hover:bg-[#B55534] text-white text-xs font-semibold cursor-pointer"
            >
              Open
            </button>
          </form>

          <MimiChromeBrowser query={activeTarget.query} url={activeTarget.url} />
        </div>
      </div>
    </div>
  );
};

interface SystemMonitorModalProps {
  isOpen: boolean;
  onClose: () => void;
  neuralCore: string;
  batteryLevel: number;
  batteryCharging: boolean;
  isOnline: boolean;
  diagnosticLogs: DiagnosticLog[];
  darkMode?: boolean;
}

export const SystemMonitorModal: React.FC<SystemMonitorModalProps> = ({
  isOpen,
  onClose,
  neuralCore,
  batteryLevel,
  batteryCharging,
  isOnline,
  diagnosticLogs,
  darkMode = false,
}) => {
  if (!isOpen) return null;

  const memInfo = (performance as unknown as {
    memory?: { usedJSHeapSize: number; jsHeapSizeLimit: number };
  }).memory;

  const usedMb = memInfo ? Math.round(memInfo.usedJSHeapSize / (1024 * 1024)) : null;
  const totalMb = memInfo ? Math.round(memInfo.jsHeapSizeLimit / (1024 * 1024)) : null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="System Monitor"
      className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className={`w-full max-w-xl rounded-3xl border shadow-2xl overflow-hidden ${
          darkMode
            ? "bg-[#22211E] border-[#383630] text-[#F2EFE9]"
            : "bg-[#FAF9F5] border-[#E5E2D9] text-[#1F1E1B]"
        }`}
      >
        <div
          className={`px-5 py-4 border-b flex items-center justify-between ${
            darkMode ? "border-[#383630]" : "border-[#E5E2D9]"
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#C96442]/15 text-[#C96442] flex items-center justify-center">
              <Activity size={18} />
            </div>
            <div>
              <h2 className="text-base font-semibold">System Monitor</h2>
              <p className={`text-xs ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>
                Active model, runtime health & diagnostic events
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close System Monitor"
            className={`min-h-[38px] min-w-[38px] rounded-xl border flex items-center justify-center cursor-pointer ${
              darkMode
                ? "bg-[#2A2925] border-[#383630] text-[#F2EFE9]"
                : "bg-[#F3F1EA] border-[#E5E2D9] text-[#1F1E1B]"
            }`}
          >
            <X size={16} />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className={`p-3 rounded-2xl border ${darkMode ? "bg-[#191816] border-[#383630]" : "bg-white border-[#E5E2D9]"}`}>
              <div className={`text-[11px] ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>Active AI</div>
              <div className="text-sm font-semibold mt-0.5 truncate">{neuralCore}</div>
            </div>
            <div className={`p-3 rounded-2xl border ${darkMode ? "bg-[#191816] border-[#383630]" : "bg-white border-[#E5E2D9]"}`}>
              <div className={`text-[11px] ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>Battery</div>
              <div className="text-sm font-semibold mt-0.5">
                {batteryLevel}% {batteryCharging ? "⚡" : ""}
              </div>
            </div>
            <div className={`p-3 rounded-2xl border ${darkMode ? "bg-[#191816] border-[#383630]" : "bg-white border-[#E5E2D9]"}`}>
              <div className={`text-[11px] ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>Network</div>
              <div className="text-sm font-semibold mt-0.5">{isOnline ? "Online" : "Offline"}</div>
            </div>
            <div className={`p-3 rounded-2xl border ${darkMode ? "bg-[#191816] border-[#383630]" : "bg-white border-[#E5E2D9]"}`}>
              <div className={`text-[11px] ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>JS Heap</div>
              <div className="text-sm font-semibold mt-0.5">
                {usedMb !== null ? `${usedMb} / ${totalMb} MB` : `${navigator.hardwareConcurrency || 4} cores`}
              </div>
            </div>
          </div>

          <div className={`rounded-2xl border p-3.5 ${darkMode ? "bg-[#191816] border-[#383630]" : "bg-white border-[#E5E2D9]"}`}>
            <div className={`text-xs font-medium mb-2 ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>
              Recent System Events ({diagnosticLogs.length})
            </div>
            <div className="space-y-1.5 max-h-56 overflow-y-auto claude-scroll">
              {diagnosticLogs.length === 0 ? (
                <p className={`text-xs ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>
                  No system events recorded yet.
                </p>
              ) : (
                diagnosticLogs.slice(0, 16).map((log) => (
                  <div
                    key={log.id}
                    className={`text-xs px-2.5 py-2 rounded-xl flex items-start justify-between gap-3 ${
                      darkMode ? "bg-[#22211E]" : "bg-[#FAF9F5]"
                    }`}
                  >
                    <div className="min-w-0">
                      <span
                        className={`font-semibold uppercase text-[10px] mr-1.5 ${
                          log.type === "error"
                            ? "text-red-500"
                            : log.type === "warning"
                              ? "text-amber-500"
                              : "text-emerald-600 dark:text-emerald-400"
                        }`}
                      >
                        [{log.type}]
                      </span>
                      <span className="font-medium">{log.message}</span>
                      {log.details && (
                        <p className={`text-[11px] mt-0.5 truncate ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>
                          {log.details}
                        </p>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
