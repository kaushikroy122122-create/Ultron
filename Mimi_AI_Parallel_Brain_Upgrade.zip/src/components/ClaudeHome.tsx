import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import {
  PanelLeft,
  PanelLeftClose,
  Plus,
  Search,
  Star,
  Trash2,
  Settings,
  Paperclip,
  Mic,
  MicOff,
  Send,
  AudioWaveform,
  Volume2,
  VolumeX,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  Mail,
  MessageCircle,
  Image as ImageIcon,
  MapPin,
  Youtube,
  Globe,
  Activity,
  Wifi,
  Smartphone,
  RefreshCw,
  Zap,
  LayoutGrid,
  ChevronDown,
  Moon,
  Sun,
  Keyboard,
  X,
  FileText,
  Square,
  LogIn,
  LogOut,
  Bug,
} from "lucide-react";
import { User } from "firebase/auth";
import { ThemeSwitcherButton, HomeThemeMode } from "./ThemeSwitcherButton";
import { LiveConnectionStatus } from "../services/liveService";
import { audioStreamer } from "../services/audioStreamer";
import { ChatAttachment } from "../services/geminiService";
import { MimiYouTubePlayer } from "./MimiYouTubePlayer";
import { MimiChromeBrowser } from "./MimiChromeBrowser";
import { MimiWhatsAppWeb } from "./MimiWhatsAppWeb";

export interface ClaudeMessage {
  id: string;
  sender: "user" | "mimi";
  text: string;
  url?: string;
  urlType?: "youtube" | "google" | "whatsapp" | "generic";
  query?: string;
  appName?: string;
  whatsappRecipient?: string;
  whatsappPhone?: string;
  whatsappMessage?: string;
  attachments?: { name: string; mimeType: string; previewUrl?: string }[];
}

export interface ClaudeConversationSummary {
  id: string;
  title: string;
  preview: string;
  updatedAtMs: number;
  starred?: boolean;
}

export type ToolLaunchId =
  | "gmail"
  | "whatsapp"
  | "photos"
  | "maps"
  | "youtube"
  | "browser"
  | "monitor"
  | "wifi"
  | "realme"
  | "livesync"
  | "upgrade"
  | "settings";

interface ClaudeHomeProps {
  appState: "idle" | "listening" | "processing" | "speaking" | "upgrading";
  isSessionActive: boolean;
  connectionStatus: LiveConnectionStatus;
  isReconnecting?: boolean;
  interimSpeech?: string;
  isMuted: boolean;
  messages: ClaudeMessage[];
  conversations: ClaudeConversationSummary[];
  currentConversationId: string | null;
  user: User | null;
  preferences: Record<string, any>;
  onSelectTheme: (theme: HomeThemeMode) => void;
  onToggleDarkMode: () => void;
  onToggleListening: () => void;
  onToggleMute: () => void;
  onSendMessage: (text: string, attachments?: ChatAttachment[]) => Promise<void> | void;
  onRegenerateMessage: (assistantMessageId: string) => void;
  onSpeakText: (text: string) => Promise<void>;
  onStopSpeaking: () => void;
  onNewChat: () => void;
  onSelectConversation: (id: string) => void;
  onToggleStarConversation: (id: string) => void;
  onDeleteConversation: (id: string) => void;
  onUpdateModel: (coreId: string) => void;
  onOpenTool: (tool: ToolLaunchId) => void;
  onToggleDebugPanel?: () => void;
  onLogin: () => void;
  onLogout: () => void;
}

const AI_MODELS = [
  { id: "Parallel Brain", label: "Mimi Parallel Brain", desc: "Runs configured AI providers concurrently and synthesizes results" },
  { id: "Gemini", label: "Gemini (configured server model)", desc: "Gemini text, multimodal & live voice" },
  { id: "Claude", label: "Claude API", desc: "Requires ANTHROPIC_API_KEY for direct provider routing" },
  { id: "ChatGPT", label: "OpenAI API", desc: "Requires OPENAI_API_KEY for direct provider routing" },
  { id: "DeepSeek", label: "DeepSeek API", desc: "Requires DEEPSEEK_API_KEY for direct provider routing" },
  { id: "Grok", label: "Grok API", desc: "Requires GROK_API_KEY for direct provider routing" },
  { id: "Antigravity", label: "Antigravity Agent", desc: "Autonomous workspace agent" },
  { id: "DeepResearch", label: "Deep Research", desc: "Multi-step investigation" },
];

const QUICK_CHIPS: { label: string; tool?: ToolLaunchId; focusPrompt?: string }[] = [
  { label: "Write an email", tool: "gmail" },
  { label: "Open WhatsApp", tool: "whatsapp" },
  { label: "Search photos", tool: "photos" },
  { label: "Play music", tool: "youtube" },
  { label: "Open maps", tool: "maps" },
  { label: "Ask anything", focusPrompt: "" },
];

const TOOL_GRID_ITEMS: {
  id: ToolLaunchId;
  label: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
}[] = [
  { id: "gmail", label: "Gmail Hub", icon: Mail },
  { id: "whatsapp", label: "WhatsApp", icon: MessageCircle },
  { id: "photos", label: "Photo Hub", icon: ImageIcon },
  { id: "maps", label: "Maps", icon: MapPin },
  { id: "youtube", label: "YouTube", icon: Youtube },
  { id: "browser", label: "Browser", icon: Globe },
  { id: "monitor", label: "Sys Monitor", icon: Activity },
  { id: "wifi", label: "Wi-Fi Scan", icon: Wifi },
  { id: "realme", label: "Realme Hub", icon: Smartphone },
  { id: "livesync", label: "Live Sync", icon: RefreshCw },
  { id: "upgrade", label: "Upgrade", icon: Zap },
  { id: "settings", label: "Settings", icon: Settings },
];

function getTimeOfDayGreeting(name: string): string {
  const hour = new Date().getHours();
  if (hour >= 5 && hour < 12) return `Good morning, ${name}`;
  if (hour >= 12 && hour < 17) return `Good afternoon, ${name}`;
  if (hour >= 17 && hour < 22) return `Good evening, ${name}`;
  return `Good night, ${name}`;
}

function getDateBucket(timestampMs: number): "Today" | "Yesterday" | "Earlier" {
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const startOfYesterday = startOfToday - 24 * 60 * 60 * 1000;
  if (timestampMs >= startOfToday) return "Today";
  if (timestampMs >= startOfYesterday) return "Yesterday";
  return "Earlier";
}

function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState<boolean>(() => {
    if (typeof window === "undefined" || !window.matchMedia) return false;
    return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  });

  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const listener = () => setReduced(mq.matches);
    mq.addEventListener("change", listener);
    return () => mq.removeEventListener("change", listener);
  }, []);

  return reduced;
}

/**
 * Calm animated audio waveform driven by live AudioStreamer frequency data.
 */
const CalmVoiceWaveform: React.FC<{
  appState: ClaudeHomeProps["appState"];
  reducedMotion: boolean;
}> = ({ appState, reducedMotion }) => {
  const [bars, setBars] = useState<number[]>(() => Array(18).fill(0.18));

  useEffect(() => {
    if (reducedMotion) return;
    let rafId = 0;
    let frame = 0;

    const tick = (t: number) => {
      frame++;
      if (frame % 2 === 0) {
        const freq = audioStreamer.getFrequencyData(24);
        let hasSignal = false;
        for (let i = 0; i < freq.length; i++) {
          if (freq[i] > 6) {
            hasSignal = true;
            break;
          }
        }
        const next: number[] = [];
        for (let i = 0; i < 18; i++) {
          if (hasSignal) {
            const val = freq[i % freq.length] / 255;
            next.push(Math.max(0.16, Math.min(1, 0.16 + val * 0.9)));
          } else if (appState === "listening") {
            const wave = Math.sin(t * 0.005 + i * 0.55) * 0.5 + 0.5;
            next.push(0.2 + wave * 0.36);
          } else if (appState === "processing") {
            const wave = Math.sin(t * 0.004 + i * 0.35) * 0.5 + 0.5;
            next.push(0.18 + wave * 0.25);
          } else {
            const wave = Math.sin(t * 0.007 + i * 0.6) * 0.5 + 0.5;
            next.push(0.22 + wave * 0.48);
          }
        }
        setBars(next);
      }
      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [appState, reducedMotion]);

  return (
    <div className="flex items-center gap-[3px] h-7 px-1" aria-hidden="true">
      {bars.map((height, idx) => (
        <span
          key={idx}
          style={{ height: `${Math.round(height * 26)}px` }}
          className="w-[3px] rounded-full bg-[#C96442] dark:bg-[#D97757] transition-[height] duration-75"
        />
      ))}
    </div>
  );
};

/**
 * Formats assistant messages cleanly: fenced code blocks, inline code, bold text, headings, and lists.
 * Never uses dangerouslySetInnerHTML.
 */
const FormattedReplyContent: React.FC<{ text: string }> = ({ text }) => {
  const [copiedBlockIdx, setCopiedBlockIdx] = useState<number | null>(null);

  const renderInline = (line: string, keyPrefix: string) => {
    const parts = line.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
    return parts.map((part, idx) => {
      if (part.startsWith("**") && part.endsWith("**") && part.length > 4) {
        return (
          <strong key={`${keyPrefix}-b-${idx}`} className="font-semibold">
            {part.slice(2, -2)}
          </strong>
        );
      }
      if (part.startsWith("`") && part.endsWith("`") && part.length > 2) {
        return (
          <code
            key={`${keyPrefix}-c-${idx}`}
            className="font-claude-mono text-[0.875em] px-1.5 py-0.5 rounded-md bg-[#EFECE4] dark:bg-[#2F2D28] text-[#1F1E1B] dark:text-[#F2EFE9]"
          >
            {part.slice(1, -1)}
          </code>
        );
      }
      return <React.Fragment key={`${keyPrefix}-t-${idx}`}>{part}</React.Fragment>;
    });
  };

  // Split by fenced code blocks ```lang ... ```
  const segments = text.split(/(```[\s\S]*?```)/g);

  return (
    <div className="space-y-3 text-[15px] leading-[1.7] text-[#1F1E1B] dark:text-[#F2EFE9]">
      {segments.map((segment, segIdx) => {
        if (segment.startsWith("```") && segment.endsWith("```")) {
          const inner = segment.slice(3, -3);
          const firstNewline = inner.indexOf("\n");
          const lang = firstNewline !== -1 ? inner.slice(0, firstNewline).trim() || "code" : "code";
          const code = firstNewline !== -1 ? inner.slice(firstNewline + 1) : inner;

          return (
            <div
              key={`code-${segIdx}`}
              className="rounded-xl overflow-hidden border border-[#E2DFD5] dark:border-[#383630] bg-[#F5F3EC] dark:bg-[#141311] my-2"
            >
              <div className="flex items-center justify-between px-3.5 py-2 border-b border-[#E2DFD5] dark:border-[#383630] bg-[#ECE9DF] dark:bg-[#1D1C19] text-xs">
                <span className="font-claude-mono font-medium text-[#6B675E] dark:text-[#A6A196]">
                  {lang}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard?.writeText(code);
                    setCopiedBlockIdx(segIdx);
                    setTimeout(() => setCopiedBlockIdx(null), 1600);
                  }}
                  className="flex items-center gap-1 text-xs font-medium text-[#524E46] dark:text-[#CFCAC0] hover:text-[#1F1E1B] dark:hover:text-white cursor-pointer"
                >
                  {copiedBlockIdx === segIdx ? <Check size={13} /> : <Copy size={13} />}
                  <span>{copiedBlockIdx === segIdx ? "Copied" : "Copy code"}</span>
                </button>
              </div>
              <pre className="p-3.5 overflow-x-auto text-[13px] leading-relaxed font-claude-mono text-[#1F1E1B] dark:text-[#F2EFE9]">
                <code>{code}</code>
              </pre>
            </div>
          );
        }

        const trimmed = segment.trim();
        if (!trimmed) return null;

        const paragraphs = segment.split(/\n{2,}/);
        return (
          <div key={`prose-${segIdx}`} className="space-y-3">
            {paragraphs.map((para, pIdx) => {
              const lines = para.split("\n").filter((l) => l.length > 0);
              if (lines.length === 0) return null;

              const isBulletList = lines.every((l) => /^\s*[-*•]\s+/.test(l));
              if (isBulletList) {
                return (
                  <ul key={`ul-${segIdx}-${pIdx}`} className="list-disc pl-5 space-y-1.5">
                    {lines.map((item, iIdx) => (
                      <li key={`li-${iIdx}`}>
                        {renderInline(item.replace(/^\s*[-*•]\s+/, ""), `li-${segIdx}-${pIdx}-${iIdx}`)}
                      </li>
                    ))}
                  </ul>
                );
              }

              const isNumberedList = lines.every((l) => /^\s*\d+\.\s+/.test(l));
              if (isNumberedList) {
                return (
                  <ol key={`ol-${segIdx}-${pIdx}`} className="list-decimal pl-5 space-y-1.5">
                    {lines.map((item, iIdx) => (
                      <li key={`oli-${iIdx}`}>
                        {renderInline(item.replace(/^\s*\d+\.\s+/, ""), `oli-${segIdx}-${pIdx}-${iIdx}`)}
                      </li>
                    ))}
                  </ol>
                );
              }

              return (
                <div key={`p-${segIdx}-${pIdx}`} className="space-y-1.5">
                  {lines.map((line, lIdx) => {
                    if (line.startsWith("### ")) {
                      return (
                        <h4 key={lIdx} className="text-base font-semibold pt-1">
                          {renderInline(line.slice(4), `h4-${segIdx}-${pIdx}-${lIdx}`)}
                        </h4>
                      );
                    }
                    if (line.startsWith("## ")) {
                      return (
                        <h3 key={lIdx} className="text-lg font-semibold pt-1">
                          {renderInline(line.slice(3), `h3-${segIdx}-${pIdx}-${lIdx}`)}
                        </h3>
                      );
                    }
                    return (
                      <p key={lIdx} className="whitespace-pre-wrap">
                        {renderInline(line, `p-${segIdx}-${pIdx}-${lIdx}`)}
                      </p>
                    );
                  })}
                </div>
              );
            })}
          </div>
        );
      })}
    </div>
  );
};

/**
 * Word-by-word gentle reveal wrapper for newly received assistant responses.
 */
const StreamingAssistantBubble: React.FC<{
  message: ClaudeMessage;
  animateStream: boolean;
  reducedMotion: boolean;
  isSpeakingThis: boolean;
  onCopy: (text: string, id: string) => void;
  copiedId: string | null;
  onRegenerate: (id: string) => void;
  onReadAloud: (text: string, id: string) => void;
}> = ({
  message,
  animateStream,
  reducedMotion,
  isSpeakingThis,
  onCopy,
  copiedId,
  onRegenerate,
  onReadAloud,
}) => {
  const [visibleWordCount, setVisibleWordCount] = useState<number>(() =>
    animateStream && !reducedMotion ? 1 : Number.MAX_SAFE_INTEGER
  );

  const tokens = useMemo(() => message.text.split(/(\s+)/), [message.text]);

  useEffect(() => {
    if (!animateStream || reducedMotion) {
      setVisibleWordCount(tokens.length);
      return;
    }
    setVisibleWordCount(2);
    const interval = setInterval(() => {
      setVisibleWordCount((prev) => {
        if (prev >= tokens.length) {
          clearInterval(interval);
          return tokens.length;
        }
        return prev + Math.max(2, Math.ceil(tokens.length / 45));
      });
    }, 24);
    return () => clearInterval(interval);
  }, [message.id, tokens.length, animateStream, reducedMotion]);

  const displayedText =
    visibleWordCount >= tokens.length ? message.text : tokens.slice(0, visibleWordCount).join("");

  return (
    <article className="claude-fade-up group space-y-2.5" aria-label="Assistant response">
      <div className="flex items-center gap-2">
        <div className="w-6 h-6 rounded-lg bg-[#C96442]/15 text-[#C96442] dark:text-[#D97757] flex items-center justify-center shrink-0">
          <Sparkles size={13} />
        </div>
        <span className="text-xs font-semibold text-[#524E46] dark:text-[#CFCAC0]">Mimi</span>
      </div>

      <div className="pl-0 sm:pl-8 space-y-3">
        <FormattedReplyContent text={displayedText} />

        {message.url && message.urlType === "youtube" && message.query && (
          <div className="rounded-2xl overflow-hidden border border-[#E5E2D9] dark:border-[#383630] bg-[#141311] p-2">
            <MimiYouTubePlayer query={message.query} url={message.url} />
          </div>
        )}
        {message.url && message.urlType === "google" && message.query && (
          <div className="rounded-2xl overflow-hidden border border-[#E5E2D9] dark:border-[#383630] bg-[#141311] p-2">
            <MimiChromeBrowser query={message.query} url={message.url} />
          </div>
        )}
        {message.url && message.urlType === "whatsapp" && (
          <div className="rounded-2xl overflow-hidden border border-[#E5E2D9] dark:border-[#383630] bg-[#141311] p-2">
            <MimiWhatsAppWeb
              recipient={message.whatsappRecipient || "Contact"}
              phone={message.whatsappPhone}
              message={message.whatsappMessage || ""}
              url={message.url}
            />
          </div>
        )}

        <div className="flex items-center gap-1 pt-0.5 text-[#6B675E] dark:text-[#A6A196]">
          <button
            type="button"
            onClick={() => onCopy(message.text, message.id)}
            aria-label="Copy response"
            title="Copy response"
            className="min-h-[32px] px-2.5 py-1 rounded-lg hover:bg-[#EFECE4] dark:hover:bg-[#2A2925] text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            {copiedId === message.id ? (
              <>
                <Check size={13} className="text-emerald-600 dark:text-emerald-400" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy size={13} />
                <span>Copy</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => onRegenerate(message.id)}
            aria-label="Regenerate response"
            title="Regenerate response"
            className="min-h-[32px] px-2.5 py-1 rounded-lg hover:bg-[#EFECE4] dark:hover:bg-[#2A2925] text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw size={13} />
            <span>Regenerate</span>
          </button>

          <button
            type="button"
            onClick={() => onReadAloud(message.text, message.id)}
            aria-label={isSpeakingThis ? "Stop reading aloud" : "Read response aloud"}
            title={isSpeakingThis ? "Stop reading" : "Read aloud"}
            className={`min-h-[32px] px-2.5 py-1 rounded-lg hover:bg-[#EFECE4] dark:hover:bg-[#2A2925] text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer ${
              isSpeakingThis ? "text-[#C96442] dark:text-[#D97757]" : ""
            }`}
          >
            {isSpeakingThis ? <Square size={12} /> : <Volume2 size={13} />}
            <span>{isSpeakingThis ? "Stop" : "Read aloud"}</span>
          </button>
        </div>
      </div>
    </article>
  );
};

export const ClaudeHome: React.FC<ClaudeHomeProps> = ({
  appState,
  isSessionActive,
  connectionStatus,
  isReconnecting = false,
  interimSpeech = "",
  isMuted,
  messages,
  conversations,
  currentConversationId,
  user,
  preferences,
  onSelectTheme,
  onToggleDarkMode,
  onToggleListening,
  onToggleMute,
  onSendMessage,
  onRegenerateMessage,
  onSpeakText,
  onStopSpeaking,
  onNewChat,
  onSelectConversation,
  onToggleStarConversation,
  onDeleteConversation,
  onUpdateModel,
  onOpenTool,
  onToggleDebugPanel,
  onLogin,
  onLogout,
}) => {
  const reducedMotion = usePrefersReducedMotion();
  const darkMode = Boolean(preferences.claudeDarkMode);

  // Desktop defaults open; mobile defaults closed drawer
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(() =>
    typeof window !== "undefined" ? window.innerWidth >= 1024 : true
  );
  const [sidebarSearch, setSidebarSearch] = useState("");
  const [draft, setDraft] = useState("");
  const [attachments, setAttachments] = useState<
    (ChatAttachment & { id: string; previewUrl?: string })[]
  >([]);
  const [isModelMenuOpen, setIsModelMenuOpen] = useState(false);
  const [isToolsMenuOpen, setIsToolsMenuOpen] = useState(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState(false);
  const [isDictating, setIsDictating] = useState(false);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const [streamedIds, setStreamedIds] = useState<Set<string>>(() => new Set());
  const prevMsgCountRef = useRef<number>(messages.length);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const modelMenuRef = useRef<HTMLDivElement>(null);
  const toolsMenuRef = useRef<HTMLDivElement>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);
  const dictationRef = useRef<any>(null);

  const displayName =
    (preferences.name && String(preferences.name).trim()) ||
    user?.displayName ||
    "Kaushik";

  const greetingText = getTimeOfDayGreeting(displayName);

  // Track newly appended assistant messages so ONLY new incoming replies animate word-by-word
  useEffect(() => {
    if (messages.length > prevMsgCountRef.current) {
      const latest = messages[messages.length - 1];
      if (latest && latest.sender === "mimi") {
        setStreamedIds((prev) => {
          const next = new Set(prev);
          next.add(latest.id);
          return next;
        });
      }
    }
    prevMsgCountRef.current = messages.length;
  }, [messages]);

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messages.length > 0) {
      chatBottomRef.current?.scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth" });
    }
  }, [messages.length, appState, reducedMotion]);

  // Auto-grow textarea height up to 200px
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
  }, [draft]);

  // Close menus on outside click
  useEffect(() => {
    const onDocClick = (e: MouseEvent) => {
      if (modelMenuRef.current && !modelMenuRef.current.contains(e.target as Node)) {
        setIsModelMenuOpen(false);
      }
      if (toolsMenuRef.current && !toolsMenuRef.current.contains(e.target as Node)) {
        setIsToolsMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, []);

  // Keyboard shortcuts: Ctrl+K (search), Ctrl+Shift+O (new chat), Ctrl+/ (help)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSidebarOpen(true);
        setTimeout(() => searchInputRef.current?.focus(), 60);
      } else if (mod && e.shiftKey && e.key.toLowerCase() === "o") {
        e.preventDefault();
        onNewChat();
        setTimeout(() => textareaRef.current?.focus(), 60);
      } else if (mod && e.key === "/") {
        e.preventDefault();
        setIsShortcutsOpen((prev) => !prev);
      } else if (e.key === "Escape") {
        setIsModelMenuOpen(false);
        setIsToolsMenuOpen(false);
        setIsShortcutsOpen(false);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [onNewChat]);

  // Cleanup dictation if unmounted
  useEffect(() => {
    return () => {
      if (dictationRef.current) {
        try {
          dictationRef.current.stop();
        } catch {
          // ignore
        }
      }
    };
  }, []);

  const toggleDictation = useCallback(() => {
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRec) return;

    if (isDictating && dictationRef.current) {
      try {
        dictationRef.current.stop();
      } catch {
        // ignore
      }
      setIsDictating(false);
      return;
    }

    const recognition = new SpeechRec();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = "en-US";
    let committed = draft ? `${draft.trimEnd()} ` : "";

    recognition.onresult = (event: any) => {
      let interim = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          committed += `${transcript} `;
        } else {
          interim += transcript;
        }
      }
      setDraft((committed + interim).trimStart());
    };
    recognition.onerror = () => setIsDictating(false);
    recognition.onend = () => setIsDictating(false);

    dictationRef.current = recognition;
    try {
      recognition.start();
      setIsDictating(true);
    } catch {
      setIsDictating(false);
    }
  }, [isDictating, draft]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files: File[] = e.target.files ? Array.from(e.target.files) : [];
    if (files.length === 0) return;

    const parsed = await Promise.all(
      files.slice(0, 4).map(
        (file) =>
          new Promise<ChatAttachment & { id: string; previewUrl?: string }>((resolve) => {
            const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
            if (file.type.startsWith("image/")) {
              const reader = new FileReader();
              reader.onload = () => {
                const dataUrl = String(reader.result || "");
                const base64 = dataUrl.includes(",") ? dataUrl.split(",")[1] : dataUrl;
                resolve({
                  id,
                  name: file.name,
                  mimeType: file.type,
                  data: base64,
                  previewUrl: dataUrl,
                });
              };
              reader.readAsDataURL(file);
            } else if (
              file.type.startsWith("text/") ||
              /\.(txt|md|json|csv|js|jsx|ts|tsx|py|html|css|xml|yaml|yml)$/i.test(file.name)
            ) {
              const reader = new FileReader();
              reader.onload = () => {
                resolve({
                  id,
                  name: file.name,
                  mimeType: file.type || "text/plain",
                  textContent: String(reader.result || "").slice(0, 14000),
                });
              };
              reader.readAsText(file);
            } else {
              resolve({
                id,
                name: file.name,
                mimeType: file.type || "application/octet-stream",
              });
            }
          })
      )
    );

    setAttachments((prev) => [...prev, ...parsed]);
    e.target.value = "";
  };

  const handleSubmit = async () => {
    const trimmed = draft.trim();
    if (!trimmed && attachments.length === 0) return;
    if (isDictating && dictationRef.current) {
      try {
        dictationRef.current.stop();
      } catch {
        // ignore
      }
      setIsDictating(false);
    }
    const payloadText = trimmed || `Please examine the attached file: ${attachments.map((a) => a.name).join(", ")}`;
    const payloadAttachments = attachments.map(({ id: _id, previewUrl: _p, ...rest }) => rest);
    setDraft("");
    setAttachments([]);
    await onSendMessage(payloadText, payloadAttachments.length > 0 ? payloadAttachments : undefined);
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedMsgId(id);
    setTimeout(() => setCopiedMsgId(null), 1600);
  };

  const handleReadAloud = async (text: string, id: string) => {
    if (speakingMsgId === id) {
      onStopSpeaking();
      setSpeakingMsgId(null);
      return;
    }
    setSpeakingMsgId(id);
    try {
      await onSpeakText(text);
    } finally {
      setSpeakingMsgId((prev) => (prev === id ? null : prev));
    }
  };

  const handleQuickChip = (chip: (typeof QUICK_CHIPS)[number]) => {
    if (chip.tool) {
      onOpenTool(chip.tool);
    } else {
      textareaRef.current?.focus();
    }
  };

  // Filtered and grouped conversations for sidebar
  const filteredConversations = useMemo(() => {
    const q = sidebarSearch.trim().toLowerCase();
    if (!q) return conversations;
    return conversations.filter(
      (c) => c.title.toLowerCase().includes(q) || c.preview.toLowerCase().includes(q)
    );
  }, [conversations, sidebarSearch]);

  const starredConversations = useMemo(
    () => filteredConversations.filter((c) => c.starred),
    [filteredConversations]
  );

  const groupedConversations = useMemo(() => {
    const groups: Record<"Today" | "Yesterday" | "Earlier", ClaudeConversationSummary[]> = {
      Today: [],
      Yesterday: [],
      Earlier: [],
    };
    for (const conv of filteredConversations) {
      if (conv.starred) continue;
      groups[getDateBucket(conv.updatedAtMs)].push(conv);
    }
    return groups;
  }, [filteredConversations]);

  const activeModel =
    AI_MODELS.find((m) => m.id === (preferences.neuralCore || "Gemini")) || AI_MODELS[0];

  const isEmptyState = messages.length === 0;

  const renderComposer = (isCentered: boolean) => (
    <div
      className={`w-full ${
        isCentered ? "max-w-[700px] mx-auto" : "max-w-[760px] mx-auto"
      } rounded-[24px] border border-[#DED9CD] dark:border-[#3A3831] bg-white dark:bg-[#252420] shadow-[0_6px_30px_rgba(31,30,27,0.06)] dark:shadow-[0_10px_36px_rgba(0,0,0,0.45)] transition-colors focus-within:border-[#C96442]/70 dark:focus-within:border-[#D97757]/70`}
    >
      {/* Active Live Voice Bar inside Composer if a voice conversation is ongoing */}
      {isSessionActive && (
        <div className="px-4 py-2.5 border-b border-[#ECE8DF] dark:border-[#34322C] bg-[#FAF8F3] dark:bg-[#1E1D1A] rounded-t-[24px] flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            <span
              className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                isReconnecting || connectionStatus === "connecting"
                  ? "bg-amber-500 animate-pulse"
                  : appState === "speaking"
                    ? "bg-[#C96442]"
                    : "bg-emerald-500"
              }`}
            />
            <CalmVoiceWaveform appState={appState} reducedMotion={reducedMotion} />
            <div className="min-w-0">
              <p className="text-xs font-semibold text-[#1F1E1B] dark:text-[#F2EFE9] truncate">
                {isReconnecting
                  ? "Reconnecting voice link..."
                  : appState === "speaking"
                    ? "Mimi is speaking — interrupt anytime"
                    : appState === "processing"
                      ? "Thinking..."
                      : "Voice conversation live"}
              </p>
              {interimSpeech && (
                <p className="text-[11px] text-[#6B675E] dark:text-[#A6A196] truncate italic">
                  “{interimSpeech}”
                </p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={onToggleMute}
              aria-label={isMuted ? "Unmute voice output" : "Mute voice output"}
              className="min-h-[34px] px-2.5 rounded-xl border border-[#DFDBD0] dark:border-[#3B3932] bg-white dark:bg-[#2A2925] text-xs font-medium text-[#1F1E1B] dark:text-[#F2EFE9] flex items-center gap-1.5 cursor-pointer hover:bg-[#F3F1EA] dark:hover:bg-[#33312C]"
            >
              {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
              <span className="hidden sm:inline">{isMuted ? "Unmute" : "Mute"}</span>
            </button>
            <button
              type="button"
              onClick={onToggleListening}
              aria-label="End voice conversation"
              className="min-h-[34px] px-3 rounded-xl bg-[#C96442] hover:bg-[#B55534] text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <MicOff size={14} />
              <span>End</span>
            </button>
          </div>
        </div>
      )}

      {/* Attachments strip */}
      {attachments.length > 0 && (
        <div className="px-4 pt-3 flex flex-wrap gap-2">
          {attachments.map((att) => (
            <div
              key={att.id}
              className="flex items-center gap-2 pl-2 pr-1.5 py-1 rounded-xl border border-[#E2DFD5] dark:border-[#383630] bg-[#FAF9F5] dark:bg-[#1B1A17] text-xs"
            >
              {att.previewUrl ? (
                <img
                  src={att.previewUrl}
                  alt={att.name}
                  className="w-6 h-6 rounded object-cover"
                />
              ) : (
                <FileText size={14} className="text-[#C96442]" />
              )}
              <span className="max-w-[140px] truncate font-medium">{att.name}</span>
              <button
                type="button"
                onClick={() => setAttachments((prev) => prev.filter((item) => item.id !== att.id))}
                aria-label={`Remove ${att.name}`}
                className="p-0.5 rounded hover:bg-[#E5E2D9] dark:hover:bg-[#34322C] cursor-pointer"
              >
                <X size={13} />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Auto-expanding Textarea */}
      <div className="px-4 pt-3.5 pb-2">
        <textarea
          ref={textareaRef}
          rows={isCentered ? 2 : 1}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              handleSubmit();
            }
          }}
          placeholder="How can I help you today?"
          aria-label="Message Mimi"
          className="w-full resize-none bg-transparent text-[15px] leading-relaxed text-[#1F1E1B] dark:text-[#F2EFE9] placeholder:text-[#8A857B] dark:placeholder:text-[#7E7A70] focus:outline-none max-h-[200px]"
        />
      </div>

      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="image/*,.txt,.md,.json,.csv,.js,.jsx,.ts,.tsx,.py,.html,.css,.pdf"
        onChange={handleFileChange}
        className="hidden"
        aria-hidden="true"
      />

      {/* Bottom Composer Toolbar */}
      <div className="px-3 pb-3 pt-1 flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-1 sm:gap-1.5 flex-wrap">
          {/* Attach images & files */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            aria-label="Attach images or files"
            title="Attach images or files"
            className="min-h-[36px] min-w-[36px] px-2 rounded-xl text-[#6B675E] dark:text-[#A6A196] hover:bg-[#F3F1EA] dark:hover:bg-[#302E29] hover:text-[#1F1E1B] dark:hover:text-white flex items-center justify-center transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#C96442]"
          >
            <Paperclip size={17} />
          </button>

          {/* AI Model Selector */}
          <div ref={modelMenuRef} className="relative">
            <button
              type="button"
              onClick={() => {
                setIsToolsMenuOpen(false);
                setIsModelMenuOpen((prev) => !prev);
              }}
              aria-haspopup="listbox"
              aria-expanded={isModelMenuOpen}
              aria-label={`Choose AI model, current ${activeModel.label}`}
              className="min-h-[36px] px-2.5 rounded-xl text-xs font-medium text-[#524E46] dark:text-[#CFCAC0] hover:bg-[#F3F1EA] dark:hover:bg-[#302E29] flex items-center gap-1.5 transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#C96442]"
            >
              <span>{activeModel.label}</span>
              <ChevronDown size={13} className="opacity-65" />
            </button>

            {isModelMenuOpen && (
              <div
                role="listbox"
                aria-label="AI Models"
                className="absolute bottom-full left-0 mb-2 w-64 rounded-2xl border border-[#E5E2D9] dark:border-[#383630] bg-white dark:bg-[#22211E] shadow-xl p-1.5 z-50 max-h-72 overflow-y-auto claude-scroll"
              >
                {AI_MODELS.map((model) => {
                  const selected = model.id === activeModel.id;
                  return (
                    <button
                      key={model.id}
                      type="button"
                      role="option"
                      aria-selected={selected}
                      onClick={() => {
                        onUpdateModel(model.id);
                        setIsModelMenuOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 rounded-xl flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                        selected
                          ? "bg-[#F3F1EA] dark:bg-[#302E29] text-[#1F1E1B] dark:text-[#F2EFE9]"
                          : "hover:bg-[#FAF9F5] dark:hover:bg-[#2A2925] text-[#1F1E1B] dark:text-[#F2EFE9]"
                      }`}
                    >
                      <div>
                        <div className="text-xs font-semibold">{model.label}</div>
                        <div className="text-[11px] text-[#6B675E] dark:text-[#A6A196]">
                          {model.desc}
                        </div>
                      </div>
                      {selected && <Check size={14} className="text-[#C96442] shrink-0" />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* All App Tools Menu */}
          <div ref={toolsMenuRef} className="relative">
            <button
              type="button"
              onClick={() => {
                setIsModelMenuOpen(false);
                setIsToolsMenuOpen((prev) => !prev);
              }}
              aria-haspopup="menu"
              aria-expanded={isToolsMenuOpen}
              aria-label="Open Workspace Tools menu"
              title="All App Tools"
              className={`min-h-[36px] px-2.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#C96442] ${
                isToolsMenuOpen
                  ? "bg-[#F3F1EA] dark:bg-[#302E29] text-[#1F1E1B] dark:text-white"
                  : "text-[#524E46] dark:text-[#CFCAC0] hover:bg-[#F3F1EA] dark:hover:bg-[#302E29]"
              }`}
            >
              <LayoutGrid size={15} />
              <span>Tools</span>
            </button>

            {isToolsMenuOpen && (
              <div
                role="menu"
                aria-label="Workspace Tools"
                className="absolute bottom-full left-0 mb-2 w-72 sm:w-80 rounded-2xl border border-[#E5E2D9] dark:border-[#383630] bg-white dark:bg-[#22211E] shadow-xl p-2.5 z-50"
              >
                <div className="px-2 pb-2 text-[11px] font-medium text-[#6B675E] dark:text-[#A6A196]">
                  Connected Apps & System Tools
                </div>
                <div className="grid grid-cols-3 gap-1.5">
                  {TOOL_GRID_ITEMS.map((item) => {
                    const Icon = item.icon;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        role="menuitem"
                        onClick={() => {
                          setIsToolsMenuOpen(false);
                          onOpenTool(item.id);
                        }}
                        className="p-2.5 rounded-xl hover:bg-[#F3F1EA] dark:hover:bg-[#302E29] flex flex-col items-center gap-1.5 text-center transition-colors cursor-pointer"
                      >
                        <div className="w-8 h-8 rounded-lg bg-[#FAF9F5] dark:bg-[#191816] border border-[#E5E2D9] dark:border-[#383630] flex items-center justify-center text-[#C96442] dark:text-[#D97757]">
                          <Icon size={16} />
                        </div>
                        <span className="text-[11px] font-medium text-[#1F1E1B] dark:text-[#F2EFE9] leading-tight">
                          {item.label}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Controls: Dictation Mic + Prominent Voice Conversation + Send */}
        <div className="flex items-center gap-1.5 ml-auto">
          {/* Dictate into input box */}
          <button
            type="button"
            onClick={toggleDictation}
            aria-label={isDictating ? "Stop voice dictation" : "Dictate message"}
            title={isDictating ? "Stop dictating" : "Dictate text into input"}
            className={`min-h-[38px] min-w-[38px] rounded-xl flex items-center justify-center transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#C96442] ${
              isDictating
                ? "bg-[#C96442]/15 text-[#C96442] dark:text-[#D97757]"
                : "text-[#6B675E] dark:text-[#A6A196] hover:bg-[#F3F1EA] dark:hover:bg-[#302E29] hover:text-[#1F1E1B] dark:hover:text-white"
            }`}
          >
            <Mic size={17} />
          </button>

          {/* Prominent Live Voice Conversation Button */}
          <button
            type="button"
            onClick={onToggleListening}
            aria-label={
              isSessionActive ? "Stop voice conversation" : "Start live voice conversation"
            }
            title={isSessionActive ? "End live voice conversation" : "Start Voice Conversation"}
            className={`min-h-[38px] px-3 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#C96442] ${
              isSessionActive
                ? "bg-emerald-600 hover:bg-emerald-700 border-emerald-600 text-white"
                : "bg-[#F3F1EA] hover:bg-[#E7E3D7] dark:bg-[#302E29] dark:hover:bg-[#3A3832] border-[#DFDBD0] dark:border-[#423F38] text-[#1F1E1B] dark:text-[#F2EFE9]"
            }`}
          >
            <AudioWaveform size={15} className={isSessionActive ? "text-white" : "text-[#C96442] dark:text-[#D97757]"} />
            <span className="hidden sm:inline">
              {isSessionActive ? "Voice live" : "Voice conversation"}
            </span>
          </button>

          {/* Send Button */}
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!draft.trim() && attachments.length === 0}
            aria-label="Send message"
            title="Send message (Enter)"
            className="min-h-[38px] min-w-[38px] rounded-xl bg-[#C96442] hover:bg-[#B55534] disabled:opacity-35 disabled:hover:bg-[#C96442] text-white flex items-center justify-center transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C96442]"
          >
            <Send size={16} />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className={`${darkMode ? "dark" : ""} h-[100dvh] w-screen overflow-hidden font-claude-sans`}>
      <div className="h-full w-full flex bg-[#FAF9F5] dark:bg-[#191816] text-[#1F1E1B] dark:text-[#F2EFE9] transition-colors duration-200 relative">
        {/* Mobile Sidebar Backdrop */}
        {sidebarOpen && (
          <div
            onClick={() => setSidebarOpen(false)}
            aria-hidden="true"
            className="fixed inset-0 z-30 bg-black/35 lg:hidden"
          />
        )}

        {/* Collapsible Left Sidebar */}
        <aside
          aria-label="Conversation history and tools"
          className={`${
            sidebarOpen ? "translate-x-0 w-[272px]" : "-translate-x-full w-[272px] lg:w-0 lg:overflow-hidden"
          } fixed lg:relative inset-y-0 left-0 z-40 shrink-0 flex flex-col border-r border-[#E7E4DA] dark:border-[#2E2D29] bg-[#F3F1EA] dark:bg-[#1F1E1B] transition-all duration-200 ease-out`}
        >
          {/* Sidebar Header + New Chat */}
          <div className="p-3 space-y-2.5 shrink-0">
            <div className="flex items-center justify-between px-1">
              <span className="font-claude-serif text-lg font-semibold tracking-tight text-[#1F1E1B] dark:text-[#F2EFE9]">
                Mimi
              </span>
              <button
                type="button"
                onClick={() => setSidebarOpen(false)}
                aria-label="Collapse sidebar"
                className="min-h-[36px] min-w-[36px] rounded-lg hover:bg-[#E7E4DA] dark:hover:bg-[#2C2B27] text-[#6B675E] dark:text-[#A6A196] flex items-center justify-center cursor-pointer"
              >
                <PanelLeftClose size={17} />
              </button>
            </div>

            <button
              type="button"
              onClick={() => {
                onNewChat();
                if (typeof window !== "undefined" && window.innerWidth < 1024) {
                  setSidebarOpen(false);
                }
                setTimeout(() => textareaRef.current?.focus(), 60);
              }}
              className="w-full min-h-[40px] px-3 rounded-xl bg-white dark:bg-[#282723] hover:bg-[#FAF9F5] dark:hover:bg-[#31302B] border border-[#DFDBD0] dark:border-[#383630] text-sm font-medium flex items-center justify-between gap-2 transition-colors cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <Plus size={16} className="text-[#C96442] dark:text-[#D97757]" />
                <span>New chat</span>
              </span>
              <kbd className="font-claude-mono text-[10px] text-[#6B675E] dark:text-[#A6A196]">
                Ctrl⇧O
              </kbd>
            </button>

            {/* Search past chats */}
            <div className="relative">
              <Search
                size={14}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6B675E] dark:text-[#A6A196]"
              />
              <input
                ref={searchInputRef}
                type="search"
                value={sidebarSearch}
                onChange={(e) => setSidebarSearch(e.target.value)}
                placeholder="Search chats..."
                aria-label="Search past conversations"
                className="w-full min-h-[36px] pl-8 pr-3 rounded-xl bg-[#EAE6DC]/75 dark:bg-[#282723] border border-transparent focus:border-[#C96442]/60 text-xs text-[#1F1E1B] dark:text-[#F2EFE9] placeholder:text-[#78746B] focus:outline-none"
              />
            </div>
          </div>

          {/* Scrollable Past Chats List */}
          <div className="flex-1 overflow-y-auto px-2.5 pb-3 space-y-4 claude-scroll">
            {starredConversations.length > 0 && (
              <div>
                <div className="px-2 py-1 text-[11px] font-semibold text-[#6B675E] dark:text-[#A6A196]">
                  Starred
                </div>
                <div className="space-y-0.5">
                  {starredConversations.map((conv) => (
                    <SidebarChatRow
                      key={conv.id}
                      conv={conv}
                      active={conv.id === currentConversationId}
                      onSelect={() => {
                        onSelectConversation(conv.id);
                        if (typeof window !== "undefined" && window.innerWidth < 1024) {
                          setSidebarOpen(false);
                        }
                      }}
                      onToggleStar={() => onToggleStarConversation(conv.id)}
                      onDelete={() => onDeleteConversation(conv.id)}
                    />
                  ))}
                </div>
              </div>
            )}

            {(["Today", "Yesterday", "Earlier"] as const).map((bucket) => {
              const items = groupedConversations[bucket];
              if (items.length === 0) return null;
              return (
                <div key={bucket}>
                  <div className="px-2 py-1 text-[11px] font-semibold text-[#6B675E] dark:text-[#A6A196]">
                    {bucket}
                  </div>
                  <div className="space-y-0.5">
                    {items.map((conv) => (
                      <SidebarChatRow
                        key={conv.id}
                        conv={conv}
                        active={conv.id === currentConversationId}
                        onSelect={() => {
                          onSelectConversation(conv.id);
                          if (typeof window !== "undefined" && window.innerWidth < 1024) {
                            setSidebarOpen(false);
                          }
                        }}
                        onToggleStar={() => onToggleStarConversation(conv.id)}
                        onDelete={() => onDeleteConversation(conv.id)}
                      />
                    ))}
                  </div>
                </div>
              );
            })}

            {filteredConversations.length === 0 && (
              <p className="px-2.5 py-4 text-xs text-[#6B675E] dark:text-[#A6A196]">
                {sidebarSearch ? "No matching chats." : "Your conversations will appear here."}
              </p>
            )}

            {/* Quick Tools Section in Sidebar */}
            <div className="pt-2 border-t border-[#E4E0D4] dark:border-[#2E2D29]">
              <div className="px-2 py-1 text-[11px] font-semibold text-[#6B675E] dark:text-[#A6A196]">
                Tools
              </div>
              <div className="grid grid-cols-2 gap-1 mt-1">
                {TOOL_GRID_ITEMS.filter((t) => t.id !== "settings").map((tool) => {
                  const Icon = tool.icon;
                  return (
                    <button
                      key={tool.id}
                      type="button"
                      onClick={() => {
                        onOpenTool(tool.id);
                        if (typeof window !== "undefined" && window.innerWidth < 1024) {
                          setSidebarOpen(false);
                        }
                      }}
                      className="min-h-[34px] px-2 py-1.5 rounded-lg hover:bg-[#EAE6DC] dark:hover:bg-[#2A2925] text-xs font-medium text-[#3D3A34] dark:text-[#DCD7CC] flex items-center gap-2 transition-colors cursor-pointer text-left"
                    >
                      <Icon size={14} className="text-[#C96442] dark:text-[#D97757] shrink-0" />
                      <span className="truncate">{tool.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Sidebar Bottom Profile & Settings */}
          <div className="p-3 border-t border-[#E4E0D4] dark:border-[#2E2D29] space-y-2 shrink-0">
            <div className="flex items-center justify-between gap-2 px-1">
              <div className="flex items-center gap-2.5 min-w-0">
                {user?.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={displayName}
                    className="w-8 h-8 rounded-full object-cover border border-[#DFDBD0] dark:border-[#383630] shrink-0"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-[#C96442] text-white text-xs font-semibold flex items-center justify-center shrink-0">
                    {displayName.charAt(0).toUpperCase()}
                  </div>
                )}
                <div className="min-w-0">
                  <div className="text-xs font-semibold truncate">{displayName}</div>
                  <div className="text-[11px] text-[#6B675E] dark:text-[#A6A196] truncate">
                    {user ? user.email || "Signed in" : "Local workspace"}
                  </div>
                </div>
              </div>

              {user ? (
                <button
                  type="button"
                  onClick={onLogout}
                  aria-label="Log out"
                  title="Log out"
                  className="min-h-[34px] min-w-[34px] rounded-lg hover:bg-[#EAE6DC] dark:hover:bg-[#2C2B27] text-[#6B675E] dark:text-[#A6A196] flex items-center justify-center cursor-pointer"
                >
                  <LogOut size={15} />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onLogin}
                  aria-label="Sign in with Google"
                  title="Sign in"
                  className="min-h-[34px] px-2.5 rounded-lg hover:bg-[#EAE6DC] dark:hover:bg-[#2C2B27] text-xs font-medium text-[#C96442] dark:text-[#D97757] flex items-center gap-1 cursor-pointer"
                >
                  <LogIn size={14} />
                  <span>Sign in</span>
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={() => onOpenTool("settings")}
              className="w-full min-h-[38px] px-3 rounded-xl hover:bg-[#EAE6DC] dark:hover:bg-[#2A2925] text-xs font-medium flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Settings size={15} className="text-[#6B675E] dark:text-[#A6A196]" />
              <span>Settings</span>
            </button>
          </div>
        </aside>

        {/* Main Editorial Workspace Column */}
        <div className="flex-1 flex flex-col min-w-0 h-full">
          {/* Calm Top Bar */}
          <header className="h-14 px-3 sm:px-5 flex items-center justify-between gap-2 shrink-0 border-b border-transparent">
            <div className="flex items-center gap-2 min-w-0">
              {!sidebarOpen && (
                <button
                  type="button"
                  onClick={() => setSidebarOpen(true)}
                  aria-label="Open sidebar"
                  title="Open sidebar"
                  className="min-h-[38px] min-w-[38px] rounded-xl hover:bg-[#EFECE4] dark:hover:bg-[#282723] text-[#524E46] dark:text-[#CFCAC0] flex items-center justify-center transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#C96442]"
                >
                  <PanelLeft size={18} />
                </button>
              )}
              {!sidebarOpen && (
                <span className="font-claude-serif text-lg font-semibold tracking-tight px-1">
                  Mimi
                </span>
              )}
              {isSessionActive && (
                <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400 px-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="hidden sm:inline">Live voice active</span>
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              {/* Small Theme Switcher Button */}
              <ThemeSwitcherButton
                currentTheme="claude"
                onSelectTheme={onSelectTheme}
                variant={darkMode ? "claude-dark" : "claude-light"}
              />

              {/* Matching Dark / Light Mode Toggle */}
              <button
                type="button"
                onClick={onToggleDarkMode}
                aria-label={darkMode ? "Switch to warm light mode" : "Switch to dark mode"}
                title={darkMode ? "Warm Light Mode" : "Dark Mode"}
                className="min-h-[38px] min-w-[38px] rounded-xl border border-[#E0DCD1] dark:border-[#383630] bg-[#F3F1EA] dark:bg-[#262420] hover:bg-[#EAE6DC] dark:hover:bg-[#302E29] text-[#524E46] dark:text-[#CFCAC0] flex items-center justify-center transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#C96442]"
              >
                {darkMode ? <Sun size={15} /> : <Moon size={15} />}
              </button>

              {onToggleDebugPanel && (
                <button
                  type="button"
                  onClick={onToggleDebugPanel}
                  aria-label="Toggle live audio debug panel"
                  title="Live Audio Debug Panel"
                  className="hidden sm:flex min-h-[38px] min-w-[38px] rounded-xl border border-[#E0DCD1] dark:border-[#383630] bg-[#F3F1EA] dark:bg-[#262420] hover:bg-[#EAE6DC] dark:hover:bg-[#302E29] text-[#6B675E] dark:text-[#A6A196] items-center justify-center transition-colors cursor-pointer"
                >
                  <Bug size={15} />
                </button>
              )}

              <button
                type="button"
                onClick={() => setIsShortcutsOpen(true)}
                aria-label="Keyboard shortcuts"
                title="Keyboard shortcuts (Ctrl+/)"
                className="hidden sm:flex min-h-[38px] min-w-[38px] rounded-xl border border-[#E0DCD1] dark:border-[#383630] bg-[#F3F1EA] dark:bg-[#262420] hover:bg-[#EAE6DC] dark:hover:bg-[#302E29] text-[#6B675E] dark:text-[#A6A196] items-center justify-center transition-colors cursor-pointer"
              >
                <Keyboard size={15} />
              </button>
            </div>
          </header>

          {/* Main Area: Either Centered Empty Home OR Single-Column Chat View */}
          {isEmptyState ? (
            <main className="flex-1 flex flex-col items-center justify-center px-4 sm:px-6 pb-10 overflow-y-auto claude-scroll">
              <div className="w-full max-w-[700px] flex flex-col items-center space-y-7 claude-fade-up">
                {/* Warm Editorial Serif Greeting */}
                <div className="text-center space-y-2">
                  <div className="w-10 h-10 mx-auto rounded-2xl bg-[#C96442]/12 text-[#C96442] dark:text-[#D97757] flex items-center justify-center mb-3">
                    <Sparkles size={20} />
                  </div>
                  <h1 className="font-claude-serif text-3xl sm:text-[40px] leading-tight font-medium tracking-tight text-[#1F1E1B] dark:text-[#F2EFE9]">
                    {greetingText}
                  </h1>
                </div>

                {/* Centered Large Rounded Input Box */}
                {renderComposer(true)}

                {/* Quick-Action Chips */}
                <div
                  className="flex flex-wrap items-center justify-center gap-2 max-w-[660px]"
                  role="group"
                  aria-label="Quick actions"
                >
                  {QUICK_CHIPS.map((chip) => (
                    <button
                      key={chip.label}
                      type="button"
                      onClick={() => handleQuickChip(chip)}
                      className="min-h-[38px] px-3.5 py-1.5 rounded-xl border border-[#E2DFD5] dark:border-[#383630] bg-[#F5F3EC] dark:bg-[#23221E] hover:bg-[#ECE8DD] dark:hover:bg-[#2D2B26] text-xs sm:text-[13px] font-medium text-[#3B3832] dark:text-[#DED9CE] transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#C96442]"
                    >
                      {chip.label}
                    </button>
                  ))}
                </div>
              </div>
            </main>
          ) : (
            <>
              {/* Single-Column Conversation Stream */}
              <main className="flex-1 overflow-y-auto px-4 sm:px-6 pt-4 pb-6 claude-scroll">
                <div className="max-w-[760px] mx-auto space-y-7">
                  {messages.map((msg) =>
                    msg.sender === "user" ? (
                      <div key={msg.id} className="claude-fade-up flex justify-end">
                        <div className="max-w-[85%] sm:max-w-[78%] rounded-2xl px-4 py-3 bg-[#EFECE4] dark:bg-[#2A2925] text-[15px] leading-relaxed text-[#1F1E1B] dark:text-[#F2EFE9] border border-[#E4E0D4] dark:border-[#383630]">
                          {msg.attachments && msg.attachments.length > 0 && (
                            <div className="flex flex-wrap gap-2 mb-2">
                              {msg.attachments.map((att, idx) =>
                                att.previewUrl ? (
                                  <img
                                    key={idx}
                                    src={att.previewUrl}
                                    alt={att.name}
                                    className="max-h-36 rounded-xl object-cover border border-[#DED9CD] dark:border-[#3C3A33]"
                                  />
                                ) : (
                                  <span
                                    key={idx}
                                    className="text-xs px-2.5 py-1 rounded-lg bg-white/70 dark:bg-[#1E1D1A] border border-[#DED9CD] dark:border-[#3C3A33]"
                                  >
                                    {att.name}
                                  </span>
                                )
                              )}
                            </div>
                          )}
                          <p className="whitespace-pre-wrap">{msg.text}</p>
                        </div>
                      </div>
                    ) : (
                      <StreamingAssistantBubble
                        key={msg.id}
                        message={msg}
                        animateStream={streamedIds.has(msg.id)}
                        reducedMotion={reducedMotion}
                        isSpeakingThis={speakingMsgId === msg.id}
                        onCopy={handleCopy}
                        copiedId={copiedMsgId}
                        onRegenerate={onRegenerateMessage}
                        onReadAloud={handleReadAloud}
                      />
                    )
                  )}

                  {appState === "processing" && (
                    <div className="flex items-center gap-2.5 text-xs text-[#6B675E] dark:text-[#A6A196]">
                      <div className="w-6 h-6 rounded-lg bg-[#C96442]/15 text-[#C96442] flex items-center justify-center">
                        <Sparkles size={13} className="animate-pulse" />
                      </div>
                      <span>Mimi is thinking...</span>
                    </div>
                  )}

                  <div ref={chatBottomRef} className="h-2" />
                </div>
              </main>

              {/* Docked Bottom Composer */}
              <footer className="px-4 sm:px-6 pb-4 pt-2 shrink-0 bg-gradient-to-t from-[#FAF9F5] via-[#FAF9F5] to-transparent dark:from-[#191816] dark:via-[#191816]">
                {renderComposer(false)}
                <p className="text-center text-[11px] text-[#78746B] dark:text-[#8E897E] mt-2">
                  Enter to send · Shift+Enter for new line · {activeModel.label} active
                </p>
              </footer>
            </>
          )}
        </div>

        {/* Keyboard Shortcuts Help Modal */}
        {isShortcutsOpen && (
          <div
            role="dialog"
            aria-modal="true"
            aria-label="Keyboard shortcuts"
            onClick={() => setIsShortcutsOpen(false)}
            className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <div
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-sm rounded-2xl border border-[#E5E2D9] dark:border-[#383630] bg-[#FAF9F5] dark:bg-[#22211E] p-5 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-base font-semibold">Keyboard Shortcuts</h2>
                <button
                  type="button"
                  onClick={() => setIsShortcutsOpen(false)}
                  aria-label="Close shortcuts dialog"
                  className="p-1.5 rounded-lg hover:bg-[#ECE8DD] dark:hover:bg-[#302E29] cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>
              <div className="space-y-2.5 text-sm">
                {[
                  { action: "Search chats", keys: "Ctrl + K" },
                  { action: "Start new chat", keys: "Ctrl + Shift + O" },
                  { action: "Toggle shortcuts help", keys: "Ctrl + /" },
                  { action: "Send message", keys: "Enter" },
                  { action: "Insert new line", keys: "Shift + Enter" },
                ].map((row) => (
                  <div key={row.action} className="flex items-center justify-between">
                    <span className="text-[#524E46] dark:text-[#CFCAC0]">{row.action}</span>
                    <kbd className="font-claude-mono text-xs px-2 py-1 rounded-md bg-[#EFECE4] dark:bg-[#2E2C27] border border-[#DFDBD0] dark:border-[#3D3B34]">
                      {row.keys}
                    </kbd>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

interface SidebarChatRowProps {
  conv: ClaudeConversationSummary;
  active: boolean;
  onSelect: () => void;
  onToggleStar: () => void;
  onDelete: () => void;
}

const SidebarChatRow: React.FC<SidebarChatRowProps> = ({
  conv,
  active,
  onSelect,
  onToggleStar,
  onDelete,
}) => (
  <div
    className={`group flex items-center justify-between gap-1 rounded-xl px-2 py-1.5 text-xs transition-colors ${
      active
        ? "bg-[#E6E2D6] dark:bg-[#2D2B26] text-[#1F1E1B] dark:text-[#F2EFE9] font-medium"
        : "hover:bg-[#EAE6DC]/75 dark:hover:bg-[#272622] text-[#3F3C36] dark:text-[#D5D0C5]"
    }`}
  >
    <button
      type="button"
      onClick={onSelect}
      className="flex-1 text-left truncate py-1 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#C96442] rounded"
      title={conv.title}
    >
      {conv.title || "New conversation"}
    </button>
    <div className="flex items-center gap-0.5 opacity-80 sm:opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity shrink-0">
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onToggleStar();
        }}
        aria-label={conv.starred ? "Unstar conversation" : "Star conversation"}
        title={conv.starred ? "Unstar" : "Star"}
        className={`p-1 rounded-md hover:bg-[#DCD7CA] dark:hover:bg-[#383630] cursor-pointer ${
          conv.starred ? "text-[#C96442] dark:text-[#D97757] opacity-100" : "text-[#6B675E]"
        }`}
      >
        <Star size={12} fill={conv.starred ? "currentColor" : "none"} />
      </button>
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onDelete();
        }}
        aria-label="Delete conversation"
        title="Delete chat"
        className="p-1 rounded-md hover:bg-red-500/15 text-[#6B675E] hover:text-red-600 dark:hover:text-red-400 cursor-pointer"
      >
        <Trash2 size={12} />
      </button>
    </div>
  </div>
);
