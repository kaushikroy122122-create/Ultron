import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Settings, Save, X } from 'lucide-react';

interface ControlPoint {
  id: string;
  label: string;
  x: number; // Percentage 0-100
  y: number; // Percentage 0-100
}

interface GamingOverlayProps {
  isActive: boolean;
  isConfiguring: boolean;
  points: ControlPoint[];
  onUpdatePoint: (id: string, x: number, y: number) => void;
  onExit: () => void;
}

export const GamingOverlay: React.FC<GamingOverlayProps> = ({ isActive, isConfiguring, points, onUpdatePoint, onExit }) => {
  if (!isActive) return null;

  return (
    <div className={`absolute inset-0 z-50 pointer-events-none ${isConfiguring ? 'bg-black/40' : ''}`}>
      {points.map((point) => (
        <motion.button
          key={point.id}
          className={`absolute w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg pointer-events-auto ${
            isConfiguring 
              ? 'bg-purple-600 border-2 border-white shadow-lg cursor-crosshair'
              : 'bg-white/10 border border-white/20 hover:bg-white/20'
          }`}
          style={{ left: `${point.x}%`, top: `${point.y}%` }}
          onClick={(e) => {
            if (isConfiguring) {
              // Simple "re-position" logic: click to set position
              const rect = e.currentTarget.parentElement?.getBoundingClientRect();
              if (rect) {
                const x = ((e.clientX - rect.left) / rect.width) * 100;
                const y = ((e.clientY - rect.top) / rect.height) * 100;
                onUpdatePoint(point.id, x, y);
              }
            } else {
              // Simulated trigger
              console.log(`Triggering ${point.label}`);
            }
          }}
        >
          {point.label}
        </motion.button>
      ))}

      {isConfiguring && (
          <div className="absolute top-4 left-4 p-4 bg-black/80 rounded-xl text-white font-mono space-y-2">
              <p>Configuration Mode</p>
              <button 
                  onClick={() => {
                      const newId = `p${points.length + 1}`;
                      // Add new button at center initially
                      onUpdatePoint(newId, 50, 50); // This needs the parent handler to support adding
                  }}
                  className="bg-purple-600 px-3 py-1 rounded-lg text-xs"
              >
                  + Add Button
              </button>
              <button 
                  onClick={onExit}
                  className="block text-red-400 text-xs mt-2"
              >
                  Exit Config
              </button>
          </div>
      )}
    </div>
  );
};
