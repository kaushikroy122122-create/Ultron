import React, { useState } from "react";
import { Activity, ChevronDown, ChevronUp, Mic, MicOff, Wifi, AlertCircle } from "lucide-react";
import { LiveDebugTelemetry } from "../services/liveSession";

interface LiveDebugPanelProps {
  info: LiveDebugTelemetry;
  isReconnecting?: boolean;
}

export const LiveDebugPanel: React.FC<LiveDebugPanelProps> = ({ info, isReconnecting }) => {
  const [isOpen, setIsOpen] = useState(false);

  const wsLabel =
    isReconnecting || info.wsStatus === "reconnecting"
      ? `reconnecting (${info.reconnectAttempt}/${info.maxReconnectAttempts})`
      : info.wsStatus;

  const wsColor =
    info.wsStatus === "open"
      ? "text-emerald-400"
      : info.wsStatus === "reconnecting" || info.wsStatus === "connecting"
      ? "text-amber-400"
      : info.wsStatus === "error"
      ? "text-red-400"
      : "text-white/50";

  return (
    <div className="fixed bottom-4 left-4 z-40 select-none">
      {isOpen && (
        <div className="mb-2 w-72 rounded-2xl bg-black/85 backdrop-blur-xl border border-white/15 p-3 shadow-2xl text-[11px] font-mono text-white/80 space-y-2">
          <div className="flex items-center justify-between border-b border-white/10 pb-1.5">
            <span className="font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <Activity size={12} />
              Live Audio Debug
            </span>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white/50 hover:text-white cursor-pointer"
              title="Collapse Debug Panel"
            >
              <ChevronDown size={14} />
            </button>
          </div>

          <div className="grid grid-cols-[120px_1fr] gap-y-1.5 gap-x-2">
            <span className="text-white/50 flex items-center gap-1">
              <Wifi size={10} /> WebSocket:
            </span>
            <span className={`font-bold uppercase ${wsColor}`}>{wsLabel}</span>

            <span className="text-white/50 flex items-center gap-1">
              {info.micActive ? <Mic size={10} className="text-emerald-400" /> : <MicOff size={10} />}
              Microphone:
            </span>
            <span className={info.micActive ? "text-emerald-400 font-bold" : "text-white/50"}>
              {info.micActive ? "Yes" : "No"}
            </span>

            <span className="text-white/50">Chunks Sent:</span>
            <span className="text-cyan-300 font-bold">{info.chunksSent}</span>

            <span className="text-white/50">Chunks Recv:</span>
            <span className="text-pink-300 font-bold">{info.chunksReceived}</span>

            <span className="text-white/50">State:</span>
            <span className="text-violet-300 font-bold uppercase">{info.state}</span>
          </div>

          <div className="pt-1.5 border-t border-white/10">
            <div className="text-white/50 flex items-center gap-1 mb-0.5">
              <AlertCircle size={10} className={info.lastError ? "text-red-400" : "text-white/40"} />
              <span>Last Error:</span>
            </div>
            <div
              className={`text-[10px] leading-snug break-words rounded-lg p-1.5 ${
                info.lastError
                  ? "bg-red-500/15 border border-red-500/30 text-red-300"
                  : "bg-white/5 text-white/40"
              }`}
            >
              {info.lastError || "None"}
            </div>
          </div>
        </div>
      )}

      <button
        onClick={() => setIsOpen((prev) => !prev)}
        className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-black/60 hover:bg-black/80 border border-white/10 hover:border-white/25 text-[10px] font-mono text-white/60 hover:text-white backdrop-blur-md shadow-lg transition-all cursor-pointer"
        title="Toggle Live Voice Debug Panel"
      >
        <span
          className={`w-1.5 h-1.5 rounded-full ${
            info.wsStatus === "open"
              ? "bg-emerald-400"
              : info.wsStatus === "reconnecting" || info.wsStatus === "connecting"
              ? "bg-amber-400 animate-pulse"
              : info.wsStatus === "error"
              ? "bg-red-500"
              : "bg-white/30"
          }`}
        />
        <span>Debug</span>
        {isOpen ? <ChevronDown size={11} /> : <ChevronUp size={11} />}
      </button>
    </div>
  );
};
