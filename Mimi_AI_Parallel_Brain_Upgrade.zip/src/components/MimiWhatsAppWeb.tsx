import React, { useState, useEffect, useRef } from "react";
import { 
  MessageSquare, Phone, Video, CheckCheck, Send, User, ChevronRight, 
  ExternalLink, Sparkles, Brain, Bot, RotateCcw, Volume2, UserCheck, Search, Loader2 
} from "lucide-react";

interface MimiWhatsAppWebProps {
  recipient: string;
  phone?: string;
  message: string;
  url: string;
}

interface ChatBubble {
  id: string;
  sender: "them" | "me";
  text: string;
  time: string;
  isSent?: boolean;
}

interface Contact {
  name: string;
  phone: string;
  avatarColor: string;
  status: string;
  lastSeen: string;
}

export const MimiWhatsAppWeb: React.FC<MimiWhatsAppWebProps> = ({ recipient, phone = "9876543210", message, url }) => {
  const [typedMsg, setTypedMsg] = useState("");
  const [typing, setTyping] = useState(false);
  const [customInput, setCustomInput] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  
  // Contacts Database
  const [contacts, setContacts] = useState<Contact[]>([
    { name: recipient || "Kaushik Roy", phone: phone || "9876543210", avatarColor: "bg-emerald-600", status: "online", lastSeen: "Active now" },
    { name: "Amit Sen", phone: "9830012345", avatarColor: "bg-amber-600", status: "offline", lastSeen: "Last seen 5m ago" },
    { name: "Rahul Das", phone: "9874454321", avatarColor: "bg-fuchsia-600", status: "online", lastSeen: "Active now" },
    { name: "Srinjoy Bose", phone: "9007788910", avatarColor: "bg-sky-600", status: "offline", lastSeen: "Last seen 2h ago" },
    { name: "Srabonti Banerjee", phone: "9163355210", avatarColor: "bg-violet-600", status: "online", lastSeen: "Active now" }
  ]);
  
  const [selectedContact, setSelectedContact] = useState<Contact>(contacts[0]);
  
  // Conversations stored per-contact
  const [conversations, setConversations] = useState<Record<string, ChatBubble[]>>({
    [contacts[0].name]: [
      { id: "1", sender: "them", text: "Hi! Are we still on for today's system check?", time: "10:15 AM" },
      { id: "2", sender: "me", text: "Yes, Mimi is initializing modules now.", time: "10:18 AM" },
      { id: "3", sender: "them", text: "Perfect, let me know when ready!", time: "10:19 AM" }
    ],
    "Amit Sen": [
      { id: "1", sender: "them", text: "ভাই, আমার ওই ফাইলটা কি একটু দেখবি?", time: "Yesterday" },
      { id: "2", sender: "me", text: "হ্যাঁ, একটু পরে পাঠিয়ে দিচ্ছি তোকে।", time: "Yesterday" }
    ],
    "Rahul Das": [
      { id: "1", sender: "them", text: "Did you update the Gemini Live framework?", time: "09:30 AM" },
      { id: "2", sender: "me", text: "Yes, fully integrated now.", time: "09:35 AM" }
    ],
    "Srinjoy Bose": [
      { id: "1", sender: "them", text: "Please call me once you are free.", time: "Monday" }
    ],
    "Srabonti Banerjee": [
      { id: "1", sender: "them", text: "অরিজিৎ সিং এর নতুন গানটা শুনেছিস? অসাধারণ!", time: "08:12 AM" }
    ]
  });

  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);
  const [isGeneratingSuggestions, setIsGeneratingSuggestions] = useState(false);
  const [aiAnalysisPrompt, setAiAnalysisPrompt] = useState("");
  const chatEndRef = useRef<HTMLDivElement>(null);

  const activeConversation = conversations[selectedContact.name] || [];

  // Scroll to bottom on updates
  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [activeConversation, typing]);

  // Handle auto-typing of incoming trigger message
  useEffect(() => {
    if (!message) return;
    
    // Switch to first contact if voice triggers it
    const cleanRecipient = recipient || contacts[0].name;
    const existingContact = contacts.find(c => c.name.toLowerCase() === cleanRecipient.toLowerCase());
    
    if (existingContact) {
      setSelectedContact(existingContact);
    } else {
      // Add new contact on the fly
      const newContact: Contact = {
        name: recipient,
        phone: phone || "9876543210",
        avatarColor: "bg-teal-600",
        status: "online",
        lastSeen: "Active now"
      };
      setContacts(prev => [newContact, ...prev]);
      setSelectedContact(newContact);
      setConversations(prev => ({
        ...prev,
        [recipient]: [
          { id: "init-1", sender: "them", text: "হ্যালো! আমার হোয়াটসঅ্যাপে মেসেজ করার জন্য ধন্যবাদ।", time: "Just now" }
        ]
      }));
    }

    let charIndex = 0;
    setTyping(true);
    setTypedMsg("");

    const typingInterval = setInterval(() => {
      if (charIndex < message.length) {
        setTypedMsg((prev) => prev + message.charAt(charIndex));
        charIndex++;
      } else {
        clearInterval(typingInterval);
        setTyping(false);
        
        // Push the typed message into active chat
        setTimeout(() => {
          const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          const newMessageObj: ChatBubble = {
            id: Date.now().toString(),
            sender: "me",
            text: message,
            time: now,
            isSent: true
          };
          
          setConversations(prev => {
            const currentList = prev[selectedContact.name] || [];
            return {
              ...prev,
              [selectedContact.name]: [...currentList, newMessageObj]
            };
          });
          setTypedMsg("");
        }, 600);
      }
    }, 30);

    return () => clearInterval(typingInterval);
  }, [message, recipient]);

  // Generate dynamic Gemini Smart Replies based on the last message in the conversation
  useEffect(() => {
    if (activeConversation.length === 0) return;
    
    const lastMsg = activeConversation[activeConversation.length - 1];
    if (lastMsg) {
      setIsGeneratingSuggestions(true);
      setAiAnalysisPrompt(`Analyzing: "${lastMsg.text}"`);
      
      // Mimic Gemini Live & Multimodal intelligence generation
      setTimeout(() => {
        let suggestions: string[] = [];
        const txt = lastMsg.text.toLowerCase();
        
        if (lastMsg.sender === "me") {
          // Suggested follow ups from contact
          suggestions = [
            "পেলয়ারে গানটি প্লে করো 🎶",
            "দয়া করে গানটির লিরিক্স দিন",
            "গুগল ক্রোম ব্রাউজারটি ওপেন করতে পারো?"
          ];
        } else {
          // Smart options to answer contact
          if (txt.includes("ready") || txt.includes("check")) {
            suggestions = [
              "Yes! Mimi is fully active & ready now. 🚀",
              "Give me 2 minutes, wrapping up tests.",
              "সব ঠিক আছে ভাই, আমি রেডি!"
            ];
          } else if (txt.includes("গান") || txt.includes("sing") || txt.includes("arijit")) {
            suggestions = [
              "হ্যাঁ ভাই, দারুণ গান! আমিও শুনছি। 🎵",
              "অরিজিৎ সিং এর কন্ঠ অসাধারণ!",
              "গানটা প্লে করো তো একটু শুনি।"
            ];
          } else if (txt.includes("file") || txt.includes("দেখবি") || txt.includes("পাঠিয়ে")) {
            suggestions = [
              "অবশ্যই ভাই, এখনই চেক করছি।",
              "কোন ফাইলটা? একটু গুগল ড্রাইভে শেয়ার করবি?",
              "I am opening Google Drive right now to check."
            ];
          } else {
            suggestions = [
              "আমি একদম ঠিক আছি! আপনি কেমন আছেন?",
              "ধন্যবাদ মেসেজ করার জন্য! 🌟",
              "Okay, let's explore this with Gemini Live."
            ];
          }
        }
        
        setAiSuggestions(suggestions);
        setIsGeneratingSuggestions(false);
      }, 700);
    }
  }, [activeConversation.length, selectedContact.name]);

  // Send a custom chat bubble message
  const handleSendCustomMessage = (textToSend?: string) => {
    const text = textToSend || customInput;
    if (!text.trim()) return;

    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const userMsg: ChatBubble = {
      id: Date.now().toString(),
      sender: "me",
      text: text,
      time: now,
      isSent: true
    };

    setConversations(prev => {
      const currentList = prev[selectedContact.name] || [];
      return {
        ...prev,
        [selectedContact.name]: [...currentList, userMsg]
      };
    });

    if (!textToSend) {
      setCustomInput("");
    }

    // Trigger AI automatic response to keep chat interactive and immersive
    setTyping(true);
    setTimeout(() => {
      const respTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      let responseText = "Excellent! I have processed your instruction gracefully.";
      
      const lowerT = text.toLowerCase();
      if (lowerT.includes("গান") || lowerT.includes("music") || lowerT.includes("youtube") || lowerT.includes("ইউটিউব")) {
        responseText = "দারুণ! আপনি চাইলে আমার ভয়েস অ্যাসিস্ট্যান্টের কাছে যেকোনো গানের অনুরোধ করতে পারেন। আমি সেটি সরাসরি ইউটিউবে প্লে করে দেবো।";
      } else if (lowerT.includes("কেমন আছ") || lowerT.includes("how are you")) {
        responseText = "আমি দুর্দান্ত আছি! আমাদের চ্যাট এবং ভয়েস কমান্ড অটোমেশন এখন পুরোপুরি সচল ও রেডি। 🚀";
      } else if (lowerT.includes("hello") || lowerT.includes("হ্যালো") || lowerT.includes("হাই")) {
        responseText = "হ্যালো! আমি মিমি এআই অটোমেশন সাপোর্ট। আপনাকে কীভাবে সাহায্য করতে পারি?";
      }

      const replyMsg: ChatBubble = {
        id: (Date.now() + 1).toString(),
        sender: "them",
        text: responseText,
        time: respTime
      };

      setConversations(prev => {
        const currentList = prev[selectedContact.name] || [];
        return {
          ...prev,
          [selectedContact.name]: [...currentList, replyMsg]
        };
      });
      setTyping(false);
    }, 1800);
  };

  const getCleanPhone = (p: string) => {
    const cleanNumbers = p.replace(/\D/g, "");
    if (!cleanNumbers) return "919876543210";
    return cleanNumbers;
  };

  // Filter contacts based on search query
  const filteredContacts = contacts.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.phone.includes(searchQuery)
  );

  return (
    <div className="w-full rounded-2xl overflow-hidden border border-[#222e35] bg-[#0c1317] shadow-2xl flex flex-col font-sans mb-4 text-white max-w-2xl self-center mx-auto transition-all" id="whatsapp-web-portal">
      {/* Dynamic Header */}
      <div className="px-5 py-4 bg-[#202d33] flex items-center justify-between border-b border-[#2a3942] shrink-0 select-none">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className={`w-11 h-11 rounded-full ${selectedContact.avatarColor} border border-emerald-500/20 flex items-center justify-center font-bold text-base text-white uppercase`}>
              {selectedContact.name.substring(0, 2)}
            </div>
            {selectedContact.status === "online" && (
              <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-green-500 border border-[#202d33] animate-pulse" />
            )}
          </div>

          <div className="flex flex-col">
            <span className="text-sm font-semibold text-white/90 flex items-center gap-1.5">
              {selectedContact.name}
              <span className="bg-emerald-500/10 text-emerald-400 text-[10px] uppercase font-mono px-1.5 py-0.5 rounded border border-emerald-500/20 font-bold">
                Mimi AI Connected
              </span>
            </span>
            <span className="text-[10px] text-green-400 font-mono tracking-wide">
              {typing ? "typing reply..." : "active • automated agent web portal"}
            </span>
          </div>
        </div>

        {/* Integration Details Actions */}
        <div className="flex items-center gap-4 text-white/65">
          <div className="hidden md:flex items-center gap-2 bg-emerald-500/10 text-emerald-400 text-xs px-3 py-1.5 rounded-xl border border-emerald-500/20">
            <Brain size={13} className="animate-pulse" />
            <span className="font-mono text-[10px] font-bold">GEMINI LIVE REPLIES • ONLINE</span>
          </div>
          <a
            href={`https://wa.me/${getCleanPhone(selectedContact.phone)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 hover:bg-white/5 rounded-full transition-all text-emerald-400 hover:scale-105"
            title="Open native WhatsApp App"
          >
            <ExternalLink size={16} />
          </a>
        </div>
      </div>

      {/* Main split display: Left Contacts, Right Chat */}
      <div className="flex h-[380px] w-full overflow-hidden bg-[#0b141a]">
        {/* Left Side Contacts lists with search functionality */}
        <div className="hidden sm:flex flex-col w-[200px] bg-[#111b21] border-r border-[#222e35] shrink-0">
          {/* Contacts Search Input bar */}
          <div className="p-2 border-b border-[#222e35]">
            <div className="relative flex items-center bg-[#202d33] rounded-lg px-2.5 py-1.5">
              <Search size={12} className="text-white/40 mr-1.5 shrink-0" />
              <input
                type="text"
                placeholder="Search contact..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent text-xs text-white placeholder:text-white/30 border-none outline-none w-full"
              />
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto divide-y divide-white/5 scrollbar-thin">
            {filteredContacts.map((contact) => (
              <div
                key={contact.name}
                onClick={() => setSelectedContact(contact)}
                className={`p-3 flex items-center justify-between cursor-pointer transition-all hover:bg-white/5
                  ${selectedContact.name === contact.name ? "bg-[#2a3942]/60 border-l-4 border-emerald-500" : ""}
                `}
              >
                <div className="flex items-center gap-2 overflow-hidden w-full">
                  <div className={`w-7 h-7 rounded-full ${contact.avatarColor} text-[11px] font-bold flex items-center justify-center shrink-0`}>
                    {contact.name.charAt(0)}
                  </div>
                  <div className="flex flex-col text-left overflow-hidden w-full">
                    <span className={`text-[12px] font-medium truncate ${selectedContact.name === contact.name ? "text-emerald-400" : "text-white/80"}`}>
                      {contact.name}
                    </span>
                    <span className="text-[9px] text-white/40 truncate">{contact.lastSeen}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right side WhatsApp Chat logs background screen */}
        <div className="flex-1 flex flex-col justify-between relative overflow-hidden bg-center">
          {/* Chat Bubble Logs */}
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 z-10 scrollbar-thin">
            <div className="self-center bg-[#182229] px-3 py-1 rounded-md border border-[#233138] text-[10px] text-white/50 mb-2 font-mono select-none uppercase tracking-wider">
              🛡️ End-to-End Encrypted via Mimi AI Secure Tunnel
            </div>

            {activeConversation.map((bubble) => (
              <div
                key={bubble.id}
                className={`flex w-full ${bubble.sender === "me" ? "justify-end" : "justify-start"} animate-all transition-all`}
              >
                <div
                  className={`max-w-[85%] px-3.5 py-2 rounded-xl text-[13px] leading-relaxed relative flex flex-col gap-1 shadow-md
                    ${bubble.sender === "me" 
                      ? "bg-[#002B22] border-r-4 border-emerald-500 text-[#e9edef] rounded-tr-none" 
                      : "bg-[#1f2c34] border-l-4 border-indigo-500 text-[#e9edef] rounded-tl-none"
                    }
                  `}
                >
                  <p className="font-sans whitespace-pre-wrap">{bubble.text}</p>
                  <div className="flex items-center justify-end gap-1.5 self-end mt-0.5">
                    <span className="text-[9px] text-white/50">{bubble.time}</span>
                    {bubble.sender === "me" && (
                      <CheckCheck size={12} className={bubble.isSent ? "text-[#53bdeb]" : "text-white/45"} />
                    )}
                  </div>
                </div>
              </div>
            ))}
            
            {/* Typing Indicator */}
            {typing && (
              <div className="flex w-full justify-start animate-pulse">
                <div className="px-4 py-2 rounded-xl bg-[#1f2c34] text-xs text-emerald-400 font-mono border border-emerald-500/10 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce" />
                  <span>{selectedContact.name} is typing...</span>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* AI Smart Replies Suggestions Section */}
          <div className="px-3.5 py-2 bg-[#1c272d]/70 backdrop-blur-md border-t border-[#2a3942] z-10">
            <div className="flex items-center justify-between mb-1.5 select-none">
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest flex items-center gap-1.5">
                <Sparkles size={11} className="animate-spin text-amber-400" />
                Gemini Live Smart Suggestion Engine
              </span>
              {isGeneratingSuggestions ? (
                <div className="flex items-center gap-1.5 text-[9px] text-white/50 font-mono">
                  <Loader2 size={10} className="animate-spin" />
                  <span>thinking...</span>
                </div>
              ) : (
                <span className="text-[9px] text-white/40 font-mono truncate max-w-[150px]">{aiAnalysisPrompt}</span>
              )}
            </div>

            <div className="flex gap-2 overflow-x-auto pb-1 flex-row flex-nowrap shrink-0 scrollbar-none scroll-smooth">
              {aiSuggestions.map((suggestion, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendCustomMessage(suggestion)}
                  disabled={isGeneratingSuggestions || typing}
                  className="px-3 py-1.5 rounded-lg bg-teal-500/10 border border-teal-500/20 text-teal-300 hover:bg-teal-500/25 active:scale-95 text-xs text-left cursor-pointer transition-all font-sans whitespace-nowrap shrink-0 flex items-center gap-1"
                >
                  <Bot size={11} className="text-teal-400 shrink-0" />
                  <span>{suggestion}</span>
                </button>
              ))}
              
              {aiSuggestions.length === 0 && (
                <span className="text-[10px] text-white/30 italic">No incoming requests to analyze yet</span>
              )}
            </div>
          </div>

          {/* Interactive Footer Typing Input Box */}
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              handleSendCustomMessage();
            }}
            className="p-3 bg-[#202d33] flex items-center gap-2 border-t border-[#2a3942] z-10 shrink-0"
          >
            <div className="flex-1 px-4 py-2 bg-[#2a3942] rounded-xl text-xs flex items-center justify-between gap-2 overflow-hidden transition-all border border-white/5 focus-within:border-emerald-500/30">
              <input
                type="text"
                placeholder="Type your reply message safely here..."
                value={customInput}
                onChange={(e) => setCustomInput(e.target.value)}
                className="bg-transparent border-none outline-none text-white flex-1 placeholder:text-white/20 text-xs"
              />
              {typing && <span className="w-2 h-2 bg-green-400 rounded-full animate-ping shrink-0" />}
            </div>
            
            <button 
              type="submit"
              className="p-2.5 rounded-xl bg-[#00a884] hover:bg-[#00c298] text-white shrink-0 hover:scale-105 transition-transform cursor-pointer"
            >
              <Send size={14} className={typing ? "opacity-50" : ""} />
            </button>
          </form>
        </div>
      </div>

      {/* Integration Control Bar */}
      <div className="p-3 bg-[#111b21] border-t border-[#222e35] flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
        <div className="flex flex-col text-left">
          <span className="text-[9px] font-bold text-white/50 uppercase tracking-widest">Automation target endpoint</span>
          <span className="text-xs font-mono text-cyan-300 truncate max-w-[200px] md:max-w-xs">{cleanPhoneUrl(url)}</span>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <a
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto px-4 py-2 rounded-xl text-xs font-bold bg-[#00a884] hover:bg-[#00c298] hover:scale-[1.02] active:scale-95 text-white transition-all shadow-md shadow-emerald-950/25 flex items-center justify-center gap-1.5 cursor-pointer border border-[#00c298]/30 group"
            id="whatsapp-launch-button"
          >
            <Send size={13} className="group-hover:translate-x-0.5 transition-transform text-white" />
            <span>Launch Native WhatsApp Web</span>
            <ExternalLink size={10} className="opacity-75" />
          </a>
        </div>
      </div>
    </div>
  );
};

function cleanPhoneUrl(urlStr: string): string {
  try {
    const url = new URL(urlStr);
    const phone = url.searchParams.get("phone") || "Standard Access";
    const textDesc = url.searchParams.get("text") || "";
    return `whatsapp.com/send?phone=${phone}&text=${textDesc.substring(0, 15)}...`;
  } catch (e) {
    return "whatsapp.com/web";
  }
}
