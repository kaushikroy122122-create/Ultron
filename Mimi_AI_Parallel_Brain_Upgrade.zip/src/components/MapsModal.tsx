import React, { useState } from "react";
import { MapPin, LocateFixed, Navigation, ExternalLink, X } from "lucide-react";

interface MapsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAskDirections?: (place: string) => void;
  themeVariant?: "warm-light" | "warm-dark" | "space";
}

export const MapsModal: React.FC<MapsModalProps> = ({
  isOpen,
  onClose,
  onAskDirections,
  themeVariant = "space",
}) => {
  const [mapQuery, setMapQuery] = useState("Kolkata, India");
  const [activeMapPlace, setActiveMapPlace] = useState("Kolkata, India");
  const [isLocating, setIsLocating] = useState(false);

  if (!isOpen) return null;

  const isLight = themeVariant === "warm-light";
  const isWarmDark = themeVariant === "warm-dark";

  const handleLocateUser = () => {
    if (!navigator.geolocation) return;
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const coords = `${pos.coords.latitude.toFixed(5)},${pos.coords.longitude.toFixed(5)}`;
        setMapQuery(coords);
        setActiveMapPlace(coords);
        setIsLocating(false);
      },
      () => setIsLocating(false),
      { timeout: 8000 }
    );
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Maps and Navigation"
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 md:p-6"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className={`w-full max-w-3xl rounded-3xl border shadow-2xl flex flex-col overflow-hidden ${
          isLight
            ? "bg-[#FAF9F5] border-[#E5E2D9] text-[#1F1E1B]"
            : isWarmDark
              ? "bg-[#22211E] border-[#383630] text-[#F2EFE9]"
              : "bg-[#070c22]/95 border-sky-400/35 text-white backdrop-blur-2xl"
        }`}
      >
        <div
          className={`px-5 py-4 border-b flex items-center justify-between ${
            isLight ? "border-[#E5E2D9]" : isWarmDark ? "border-[#383630]" : "border-white/10"
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                isLight || isWarmDark
                  ? "bg-[#C96442]/15 text-[#C96442]"
                  : "bg-sky-500/20 border border-sky-400/40 text-sky-300"
              }`}
            >
              <MapPin size={18} />
            </div>
            <div>
              <h2 className="text-base font-semibold leading-tight">Maps & Navigation</h2>
              <p
                className={`text-xs ${
                  isLight ? "text-[#6B675E]" : isWarmDark ? "text-[#A6A196]" : "text-slate-300/75"
                }`}
              >
                Search destinations or open live directions
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Maps Modal"
            className={`min-h-[38px] min-w-[38px] rounded-xl border flex items-center justify-center cursor-pointer ${
              isLight
                ? "bg-[#F3F1EA] hover:bg-[#EAE6DC] border-[#E5E2D9] text-[#1F1E1B]"
                : isWarmDark
                  ? "bg-[#2A2925] hover:bg-[#35332E] border-[#383630] text-[#F2EFE9]"
                  : "bg-white/5 hover:bg-white/15 border-white/10 text-slate-200"
            }`}
          >
            <X size={16} />
          </button>
        </div>

        <div className="p-4 space-y-3">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (mapQuery.trim()) setActiveMapPlace(mapQuery.trim());
            }}
            className="flex flex-wrap sm:flex-nowrap items-center gap-2"
          >
            <input
              type="text"
              value={mapQuery}
              onChange={(e) => setMapQuery(e.target.value)}
              placeholder="Search city, address, or landmark..."
              aria-label="Destination or location search"
              className={`flex-1 min-w-[200px] min-h-[44px] rounded-xl border px-3.5 text-sm focus:outline-none ${
                isLight
                  ? "bg-white border-[#DDD8CC] text-[#1F1E1B] placeholder:text-[#8E897E] focus:border-[#C96442]"
                  : isWarmDark
                    ? "bg-[#191816] border-[#383630] text-[#F2EFE9] placeholder:text-[#78746B] focus:border-[#D97757]"
                    : "bg-white/8 border-white/15 text-white placeholder:text-slate-400 focus:border-sky-400"
              }`}
            />
            <button
              type="button"
              onClick={handleLocateUser}
              disabled={isLocating}
              className={`min-h-[44px] px-3.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
                isLight
                  ? "bg-[#F3F1EA] hover:bg-[#EAE6DC] border-[#DDD8CC] text-[#1F1E1B]"
                  : isWarmDark
                    ? "bg-[#2A2925] hover:bg-[#35332E] border-[#383630] text-[#F2EFE9]"
                    : "bg-white/8 hover:bg-white/15 border-white/15 text-sky-200"
              }`}
            >
              <LocateFixed size={15} />
              <span>{isLocating ? "Locating..." : "My Location"}</span>
            </button>
            <button
              type="submit"
              className={`min-h-[44px] px-4 rounded-xl font-semibold text-xs flex items-center gap-1.5 cursor-pointer ${
                isLight || isWarmDark
                  ? "bg-[#C96442] hover:bg-[#B55534] text-white"
                  : "bg-gradient-to-r from-sky-500 to-cyan-500 text-slate-950 font-bold"
              }`}
            >
              <Navigation size={15} />
              <span>Locate</span>
            </button>
          </form>

          <div
            className={`w-full h-64 md:h-80 rounded-2xl overflow-hidden border ${
              isLight ? "border-[#E5E2D9] bg-[#F3F1EA]" : isWarmDark ? "border-[#383630] bg-[#191816]" : "border-white/15 bg-[#040818]"
            }`}
          >
            <iframe
              title={`Map of ${activeMapPlace}`}
              src={`https://maps.google.com/maps?q=${encodeURIComponent(activeMapPlace)}&z=13&output=embed`}
              className="w-full h-full border-0"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
            {onAskDirections && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onAskDirections(`open google maps for ${activeMapPlace}`);
                }}
                className={`min-h-[40px] px-4 rounded-xl border text-xs font-semibold cursor-pointer ${
                  isLight
                    ? "bg-[#F3F1EA] hover:bg-[#EAE6DC] border-[#DDD8CC] text-[#1F1E1B]"
                    : isWarmDark
                      ? "bg-[#2A2925] hover:bg-[#35332E] border-[#383630] text-[#F2EFE9]"
                      : "bg-violet-500/20 hover:bg-violet-500/30 border-violet-400/35 text-violet-200"
                }`}
              >
                Ask Mimi for Directions
              </button>
            )}
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(activeMapPlace)}`}
              target="_blank"
              rel="noopener noreferrer"
              className={`min-h-[40px] px-4 rounded-xl border text-xs font-semibold flex items-center gap-1.5 ml-auto ${
                isLight
                  ? "bg-white hover:bg-[#F3F1EA] border-[#DDD8CC] text-[#1F1E1B]"
                  : isWarmDark
                    ? "bg-[#2A2925] hover:bg-[#35332E] border-[#383630] text-[#F2EFE9]"
                    : "bg-white/10 hover:bg-white/20 border-white/15 text-white"
              }`}
            >
              <ExternalLink size={14} />
              <span>Open Google Maps</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
