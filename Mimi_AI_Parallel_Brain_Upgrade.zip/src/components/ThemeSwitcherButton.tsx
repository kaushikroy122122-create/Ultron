import React, { useState, useRef, useEffect } from "react";
import { LayoutGrid, Orbit, Feather, Check, ChevronDown } from "lucide-react";

export type HomeThemeMode = "classic" | "3d" | "claude";

interface ThemeOption {
  id: HomeThemeMode;
  label: string;
  description: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
}

const THEME_OPTIONS: ThemeOption[] = [
  {
    id: "claude",
    label: "Claude Style",
    description: "Calm, minimal editorial workspace",
    icon: Feather,
  },
  {
    id: "3d",
    label: "Neural 3D",
    description: "Glowing 3D orb & orbiting cards",
    icon: Orbit,
  },
  {
    id: "classic",
    label: "Classic",
    description: "Original cyber orbital interface",
    icon: LayoutGrid,
  },
];

interface ThemeSwitcherButtonProps {
  currentTheme: HomeThemeMode;
  onSelectTheme: (theme: HomeThemeMode) => void;
  variant?: "claude-light" | "claude-dark" | "space" | "classic";
}

export const ThemeSwitcherButton: React.FC<ThemeSwitcherButtonProps> = ({
  currentTheme,
  onSelectTheme,
  variant = "claude-light",
}) => {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", handleOutside);
    document.addEventListener("keydown", handleEsc);
    return () => {
      document.removeEventListener("mousedown", handleOutside);
      document.removeEventListener("keydown", handleEsc);
    };
  }, []);

  const activeOption = THEME_OPTIONS.find((t) => t.id === currentTheme) || THEME_OPTIONS[0];
  const ActiveIcon = activeOption.icon;

  const isLight = variant === "claude-light";
  const isClaudeDark = variant === "claude-dark";

  const buttonClasses = isLight
    ? "bg-[#F3F1EA] hover:bg-[#EAE6DC] border-[#E0DCD1] text-[#1F1E1B]"
    : isClaudeDark
      ? "bg-[#262420] hover:bg-[#302E29] border-[#383630] text-[#F2EFE9]"
      : variant === "space"
        ? "bg-white/8 hover:bg-white/15 border-white/15 text-slate-100"
        : "bg-white/8 hover:bg-white/15 border-white/15 text-white";

  const menuClasses = isLight
    ? "bg-[#FFFFFF] border-[#E5E2D9] text-[#1F1E1B] shadow-[0_12px_36px_rgba(31,30,27,0.12)]"
    : isClaudeDark
      ? "bg-[#22211E] border-[#383630] text-[#F2EFE9] shadow-[0_16px_44px_rgba(0,0,0,0.55)]"
      : "bg-[#090d24]/95 border-white/15 text-white backdrop-blur-2xl shadow-[0_16px_44px_rgba(0,0,0,0.75)]";

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label={`Switch theme, current theme ${activeOption.label}`}
        title="Switch Home Theme (Classic / Neural 3D / Claude Style)"
        className={`min-h-[38px] px-2.5 sm:px-3 py-1.5 rounded-xl border text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#C96442] ${buttonClasses}`}
      >
        <ActiveIcon
          size={14}
          className={
            isLight
              ? "text-[#C96442]"
              : isClaudeDark
                ? "text-[#D97757]"
                : "text-cyan-300"
          }
        />
        <span className="hidden sm:inline">{activeOption.label}</span>
        <ChevronDown
          size={13}
          className={`opacity-60 transition-transform duration-150 ${open ? "rotate-180" : ""}`}
        />
      </button>

      {open && (
        <div
          role="listbox"
          aria-label="Home interface themes"
          className={`absolute right-0 mt-2 w-64 rounded-2xl border p-1.5 z-50 ${menuClasses}`}
        >
          <div
            className={`px-2.5 py-1.5 text-[11px] font-medium ${
              isLight ? "text-[#6B675E]" : "text-white/55"
            }`}
          >
            Home Theme
          </div>
          {THEME_OPTIONS.map((opt) => {
            const Icon = opt.icon;
            const selected = opt.id === currentTheme;
            return (
              <button
                key={opt.id}
                type="button"
                role="option"
                aria-selected={selected}
                onClick={() => {
                  onSelectTheme(opt.id);
                  setOpen(false);
                }}
                className={`w-full text-left px-2.5 py-2 rounded-xl flex items-center justify-between gap-2.5 transition-colors cursor-pointer ${
                  selected
                    ? isLight
                      ? "bg-[#F3F1EA] text-[#1F1E1B]"
                      : isClaudeDark
                        ? "bg-[#302E29] text-[#F2EFE9]"
                        : "bg-cyan-500/15 text-white"
                    : isLight
                      ? "hover:bg-[#FAF9F5] text-[#1F1E1B]"
                      : isClaudeDark
                        ? "hover:bg-[#2A2925] text-[#F2EFE9]"
                        : "hover:bg-white/10 text-white/85"
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      selected
                        ? isLight || isClaudeDark
                          ? "bg-[#C96442]/15 text-[#C96442]"
                          : "bg-cyan-400/20 text-cyan-300"
                        : isLight
                          ? "bg-[#EFECE4] text-[#6B675E]"
                          : "bg-white/8 text-white/65"
                    }`}
                  >
                    <Icon size={15} />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-semibold leading-tight">{opt.label}</div>
                    <div
                      className={`text-[11px] truncate mt-0.5 ${
                        isLight ? "text-[#6B675E]" : "text-white/55"
                      }`}
                    >
                      {opt.description}
                    </div>
                  </div>
                </div>
                {selected && (
                  <Check
                    size={14}
                    className={
                      isLight || isClaudeDark ? "text-[#C96442] shrink-0" : "text-cyan-300 shrink-0"
                    }
                  />
                )}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};
