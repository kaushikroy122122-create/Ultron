import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  X, RefreshCw, Sparkles, BookOpen, Clock, Settings,
  History, ShieldAlert, Cpu, Heart, CheckCircle2, Save, Trash2, ArrowRight
} from "lucide-react";
import { aiStudioSyncService, SyncConfig } from "../services/aiStudioSyncService";
import { historyMemoryService, Memory } from "../services/historyMemoryService";
import { auth } from "../services/firebaseService";

interface LiveSyncControllerProps {
  isOpen: boolean;
  onClose: () => void;
  user: any;
}

export const LiveSyncController: React.FC<LiveSyncControllerProps> = ({ isOpen, onClose, user }) => {
  // AI Twin / Sync Settings State from Service
  const [syncConfig, setSyncConfig] = useState<SyncConfig>(() => aiStudioSyncService.getConfig());
  const [syncLogs, setSyncLogs] = useState<string[]>(() => aiStudioSyncService.getLogs());
  const [correctionsCount, setCorrectionsCount] = useState(() => aiStudioSyncService.getAutoCorrectionCount());

  // Life History / Future Stories States
  const [storyInput, setStoryInput] = useState("");
  const [storyCategory, setStoryCategory] = useState<"future_vision" | "life_history" | "milestone">("future_vision");
  const [stories, setStories] = useState<Memory[]>([]);
  const [isLoadingStories, setIsLoadingStories] = useState(false);
  const [activeStoryTab, setActiveStoryTab] = useState<"write" | "timeline">("timeline");

  // Round controller dial selection state: (alignment sync multiplier)
  const [dialMultiplier, setDialMultiplier] = useState<number>(4); // 1x, 2x, 4x, 8x, Ultra
  const [activeDialAngle, setActiveDialAngle] = useState(135); // Degrees for visual rotation effect

  // Sync state changes with our singleton service
  useEffect(() => {
    const unsubscribe = aiStudioSyncService.registerListener(() => {
      setSyncConfig(aiStudioSyncService.getConfig());
      setSyncLogs([...aiStudioSyncService.getLogs()]);
      setCorrectionsCount(aiStudioSyncService.getAutoCorrectionCount());
    });
    return () => unsubscribe();
  }, []);

  // Fetch stories on load or when user changes
  useEffect(() => {
    if (isOpen) {
      loadUserStories();
    }
  }, [isOpen, user]);

  const loadUserStories = async () => {
    if (!user) return;
    setIsLoadingStories(true);
    try {
      const allMemories = await historyMemoryService.getMemories(user.uid);
      // Filter out only user-centric stories
      const storyMems = allMemories.filter(m => 
        m.category === "life_story" || 
        m.category === "future_vision" || 
        m.category === "life_history" ||
        m.category === "milestone"
      );
      setStories(storyMems);
    } catch (e) {
      console.error("Failed to load life stories:", e);
    } finally {
      setIsLoadingStories(false);
    }
  };

  const handleToggleSync = (key: keyof SyncConfig) => {
    const current = syncConfig[key];
    aiStudioSyncService.updateConfig({ [key]: !current });
    aiStudioSyncService.addLog("CONTROL", `Toggled policy flag [${key}] to ${!current}`);
  };

  const handleSaveStory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!storyInput.trim() || !user) return;

    try {
      // Save to long-term memories using standard schema with specific category
      const saved = await historyMemoryService.saveMemory(
        user.uid, 
        storyInput.trim(), 
        storyCategory
      );
      if (saved) {
        setStories(prev => [saved, ...prev]);
        setStoryInput("");
        setActiveStoryTab("timeline");
        aiStudioSyncService.addLog("STORY", `Recorded new biographical narrative point under "${storyCategory}".`);
      }
    } catch (error) {
      console.error("Failed to write to story archive:", error);
    }
  };

  const handleDeleteStory = async (storyId: string) => {
    if (!user) return;
    try {
      await historyMemoryService.deleteMemory(user.uid, storyId);
      setStories(prev => prev.filter(s => s.id !== storyId));
      aiStudioSyncService.addLog("STORY", `Excised biographical memory reference.`);
    } catch (e) {
      console.error("Failed to delete memory:", e);
    }
  };

  // Adjust circular dial state
  const handleDialClick = (mult: number, angle: number) => {
    setDialMultiplier(mult);
    setActiveDialAngle(angle);
    aiStudioSyncService.updateConfig({ syncIntervalMin: Math.max(1, Math.floor(60 / mult)) });
    aiStudioSyncService.addLog("DIAL", `Calibrated physical dial sync interval: ${Math.floor(60 / mult)} min (Multiplier: ${mult}x)`);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md pointer-events-auto">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 30 }}
        transition={{ type: "spring", duration: 0.5 }}
        className="relative w-full max-w-4xl h-[85vh] bg-[#07070a] border border-violet-500/35 rounded-3xl overflow-hidden shadow-[0_0_60px_rgba(139,92,246,0.3)] flex flex-col"
      >
        {/* Colorful High-Glow Header Accent */}
        <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-violet-500 via-pink-500 via-cyan-400 to-emerald-400 animate-pulse" />

        {/* Floating background grids */}
        <div className="absolute inset-0 bg-[radial-gradient(#8b5cf608_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none" />

        {/* Header bar */}
        <div className="flex items-center justify-between p-6 border-b border-white/5 relative z-10 bg-black/25 backdrop-blur-xl">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-violet-500/10 border border-violet-500/30 flex items-center justify-center animate-pulse">
              <RefreshCw size={18} className="text-violet-400 animate-spin-slow" />
            </div>
            <div>
              <h3 className="text-base font-black text-white uppercase tracking-wider font-sans">AI Studio Live Sync & Tactical Controller</h3>
              <p className="text-[10px] text-white/45 leading-none mt-1">Upgrade your future, write life history & command the sync core</p>
            </div>
          </div>
          
          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition-all border border-white/5 cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        {/* Content Body Grid */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 relative z-10">
          
          {/* LEFT SIDE: Switch controls and Round Dial (lg:col-span-5) */}
          <div className="lg:col-span-5 flex flex-col gap-5">
            
            {/* Live Sync Master Switch Button */}
            <div className="p-5 rounded-2xl bg-neutral-900/35 border border-white/5 relative overflow-hidden group">
              <div className="absolute -right-12 -top-12 w-28 h-28 bg-violet-500/5 rounded-full blur-2xl pointer-events-none group-hover:bg-violet-500/10 transition-all" />
              
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <span className="text-[8px] font-mono text-violet-400 uppercase tracking-widest font-black">Core Switch State</span>
                  <h4 className="text-sm font-bold text-white uppercase tracking-wide">Live Studio Sync</h4>
                  <p className="text-[10px] text-white/40 leading-tight pr-4">Active real-time telemetry, model upgrades and feature handshakes.</p>
                </div>

                {/* Big high-contrast tactile toggle switch */}
                <button
                  onClick={() => handleToggleSync("autoSync")}
                  className={`w-14 h-8 rounded-full p-1 relative flex items-center transition-all duration-500 border cursor-pointer ${
                    syncConfig.autoSync
                      ? "bg-gradient-to-r from-violet-600 to-pink-500 border-violet-400/50 shadow-[0_0_15px_rgba(139,92,246,0.6)]"
                      : "bg-neutral-950 border-white/10"
                  }`}
                >
                  <motion.div
                    layout
                    className={`w-6 h-6 rounded-full bg-white shadow-lg flex items-center justify-center ${
                      syncConfig.autoSync ? "text-violet-600" : "text-neutral-500"
                    }`}
                  >
                    <Cpu size={12} className={syncConfig.autoSync ? "animate-pulse" : ""} />
                  </motion.div>
                </button>
              </div>

              {/* Status flag */}
              <div className="mt-4 flex items-center gap-2 pt-3 border-t border-white/5">
                <span className={`w-1.5 h-1.5 rounded-full ${syncConfig.autoSync ? "bg-emerald-400 animate-ping" : "bg-red-500"}`} />
                <span className="text-[9px] font-mono font-bold uppercase text-white/55">
                  SYSTEM STATUS: {syncConfig.autoSync ? "LINK ESTABLISHED & SYNCING" : "STANDBY OFFLINE MODE"}
                </span>
              </div>
            </div>

            {/* ROUND FEATURE DIAL: Alignment & Speed controller */}
            <div className="p-5 rounded-2xl bg-neutral-900/35 border border-white/5 flex flex-col items-center text-center relative overflow-hidden">
              <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-violet-500/20 via-pink-500/20 to-cyan-500/20" />
              
              <div className="w-full text-left mb-3">
                <span className="text-[8px] font-mono text-cyan-400 uppercase tracking-widest font-black">Round Tactical Dial</span>
                <h4 className="text-xs font-bold text-white uppercase">System Speed Calibration</h4>
              </div>

              {/* The Round Dial component (Circular dial interface) */}
              <div className="relative w-44 h-44 my-2 flex items-center justify-center">
                {/* Glowing Outer Rings */}
                <div className="absolute inset-0 rounded-full border border-white/5 pointer-events-none" />
                <div className="absolute inset-3 rounded-full border border-dashed border-cyan-500/20 animate-spin-slow pointer-events-none" />
                
                {/* Dial Center Rotating Wheel pointer */}
                <motion.div 
                  animate={{ rotate: activeDialAngle }}
                  transition={{ type: "spring", stiffness: 80 }}
                  className="absolute inset-8 rounded-full border border-cyan-400/40 bg-neutral-950/80 shadow-[0_0_20px_rgba(34,211,238,0.15)] flex items-center justify-center pointer-events-none"
                >
                  {/* Glowing Arrow Ticker */}
                  <div className="absolute top-1.5 w-1 h-3 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
                  <div className="w-2 h-2 rounded-full bg-white/20" />
                </motion.div>

                {/* Dial Multiplier Options (Surrounding circular targets) */}
                {[
                  { mult: 1, angle: 45, label: "1x", desc: "Eco" },
                  { mult: 2, angle: 90, label: "2x", desc: "Mid" },
                  { mult: 4, angle: 135, label: "4x", desc: "Sync" },
                  { mult: 8, angle: 180, label: "8x", desc: "Turbo" },
                  { mult: 12, angle: 225, label: "Max", desc: "Ultra" }
                ].map((opt) => {
                  const isSelected = dialMultiplier === opt.mult;
                  const rad = (opt.angle - 90) * (Math.PI / 180);
                  const x = Math.cos(rad) * 65; // Position on circle radius 65
                  const y = Math.sin(rad) * 65;
                  
                  return (
                    <button
                      key={opt.mult}
                      onClick={() => handleDialClick(opt.mult, opt.angle)}
                      style={{ transform: `translate(${x}px, ${y}px)` }}
                      className={`absolute w-9 h-9 rounded-full flex flex-col items-center justify-center text-[9px] border transition-all cursor-pointer ${
                        isSelected
                          ? "bg-gradient-to-tr from-cyan-600 to-teal-500 border-cyan-300 text-white shadow-[0_0_12px_rgba(34,211,238,0.5)] scale-110 font-black"
                          : "bg-neutral-950/90 border-white/10 text-white/50 hover:border-cyan-500/40 hover:text-white"
                      }`}
                      title={`Multiplier: ${opt.mult}x - Sync frequency ${Math.floor(60 / opt.mult)}m`}
                    >
                      <span>{opt.label}</span>
                    </button>
                  );
                })}

                {/* Dial Central Information Display */}
                <div className="absolute flex flex-col items-center pointer-events-none">
                  <span className="text-[15px] font-black font-mono text-cyan-400 tracking-tighter">
                    {dialMultiplier}x
                  </span>
                  <span className="text-[7px] text-white/30 uppercase tracking-widest font-mono">
                    Alignment
                  </span>
                </div>
              </div>

              <div className="mt-2 w-full">
                <p className="text-[9px] text-white/50 leading-normal bg-black/40 p-2.5 rounded-xl border border-white/5">
                  Interval Calibrated to <span className="text-cyan-400 font-bold">{Math.floor(60 / dialMultiplier)} Minutes</span>. Deep telemetry loops will automatically fire at this rate.
                </p>
              </div>
            </div>

            {/* Sync Toggles Grid */}
            <div className="grid grid-cols-2 gap-3">
              {[
                { key: "intelligentAutoCorrection", title: "Intelligent Fix", icon: ShieldAlert, color: "text-amber-400" },
                { key: "serverHealthMonitoring", title: "Health telemetry", icon: Clock, color: "text-emerald-400" },
                { key: "featureGeneration", title: "Auto-Synthesis", icon: Sparkles, color: "text-pink-400" },
                { key: "secureUpdateDeploy", title: "Secure patches", icon: Cpu, color: "text-cyan-400" }
              ].map((cfg) => {
                const isActive = syncConfig[cfg.key as keyof SyncConfig];
                const Icon = cfg.icon;
                return (
                  <button
                    key={cfg.key}
                    onClick={() => handleToggleSync(cfg.key as keyof SyncConfig)}
                    className={`p-3 rounded-xl border text-left transition-all flex flex-col gap-1.5 cursor-pointer hover:translate-y-[-1px] ${
                      isActive
                        ? "bg-white/5 border-white/15 text-white"
                        : "bg-black/30 border-white/5 text-white/45"
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <Icon size={12} className={isActive ? cfg.color : "text-white/30"} />
                      <div className={`w-1.5 h-1.5 rounded-full ${isActive ? "bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)]" : "bg-neutral-700"}`} />
                    </div>
                    <span className="text-[9px] font-bold uppercase tracking-wider">{cfg.title}</span>
                  </button>
                );
              })}
            </div>

          </div>

          {/* RIGHT SIDE: Life History & Story settings (lg:col-span-7) */}
          <div className="lg:col-span-7 flex flex-col bg-neutral-900/15 border border-white/5 rounded-2xl overflow-hidden">
            
            {/* Story Navigation Tabs */}
            <div className="flex border-b border-white/5 bg-black/40">
              <button
                onClick={() => setActiveStoryTab("timeline")}
                className={`flex-1 py-3 text-center text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  activeStoryTab === "timeline"
                    ? "border-violet-500 text-white bg-violet-500/5 font-black"
                    : "border-transparent text-white/40 hover:text-white hover:bg-white/5"
                }`}
              >
                <History size={13} />
                <span>Life History timeline ({stories.length})</span>
              </button>
              <button
                onClick={() => setActiveStoryTab("write")}
                className={`flex-1 py-3 text-center text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  activeStoryTab === "write"
                    ? "border-pink-500 text-white bg-pink-500/5 font-black"
                    : "border-transparent text-white/40 hover:text-white hover:bg-white/5"
                }`}
              >
                <BookOpen size={13} />
                <span>Write Life Story</span>
              </button>
            </div>

            {/* Story Panel Body */}
            <div className="flex-1 overflow-y-auto p-5 min-h-[300px]">
              
              {/* timeline View */}
              {activeStoryTab === "timeline" && (
                <div className="space-y-4">
                  {isLoadingStories ? (
                    <div className="flex flex-col items-center justify-center py-12 text-white/40 gap-3">
                      <RefreshCw size={18} className="animate-spin text-violet-400" />
                      <span className="text-xs font-mono uppercase">Retrieving your biological trace...</span>
                    </div>
                  ) : stories.length === 0 ? (
                    <div className="flex flex-col items-center justify-center text-center py-12 text-white/40 gap-3 px-4">
                      <div className="p-3.5 rounded-full bg-white/5 border border-white/5">
                        <BookOpen size={24} className="text-white/20" />
                      </div>
                      <div>
                        <h5 className="text-xs font-bold text-white uppercase">No Life Stories Found</h5>
                        <p className="text-[10px] text-white/45 max-w-xs mt-1 leading-normal">
                          Connect with your historical or future narratives. Write your future predictions, milestones or biographical memories.
                        </p>
                      </div>
                      <button
                        onClick={() => setActiveStoryTab("write")}
                        className="mt-2 text-[10px] font-bold px-4 py-2 bg-violet-600 hover:bg-violet-500 text-white rounded-xl shadow-lg hover:shadow-violet-600/30 transition-all cursor-pointer"
                      >
                        Create Story Node
                      </button>
                    </div>
                  ) : (
                    <div className="relative border-l border-white/10 ml-3.5 pl-6 space-y-4 py-2">
                      {stories.map((story, idx) => {
                        const dateStr = story.timestamp?.toDate 
                          ? story.timestamp.toDate().toLocaleString() 
                          : new Date(story.timestamp).toLocaleString();
                        
                        // Category colors and badges
                        const catColors = {
                          future_vision: { text: "text-cyan-400", bg: "bg-cyan-500/10 border-cyan-500/30", label: "Future Vision" },
                          life_history: { text: "text-pink-400", bg: "bg-pink-500/10 border-pink-500/30", label: "Life History" },
                          milestone: { text: "text-amber-400", bg: "bg-amber-500/10 border-amber-500/30", label: "System Milestone" }
                        };
                        const config = catColors[story.category as keyof typeof catColors] || { text: "text-violet-400", bg: "bg-violet-500/10 border-violet-500/30", label: "General Memory" };

                        return (
                          <motion.div 
                            key={story.id}
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: idx * 0.05 }}
                            className="relative group p-4 rounded-xl bg-black/40 border border-white/5 hover:border-violet-500/20 transition-all flex items-start gap-3"
                          >
                            {/* Point node on timeline */}
                            <span className="absolute -left-[31px] top-4.5 w-2 h-2 rounded-full bg-violet-400 ring-4 ring-[#07070a] shadow-[0_0_8px_rgba(139,92,246,0.8)]" />

                            <div className="flex-1 space-y-1.5">
                              <div className="flex items-center justify-between gap-2 flex-wrap">
                                <span className={`text-[8px] font-extrabold uppercase px-2 py-0.5 rounded-md border ${config.bg} ${config.text}`}>
                                  {config.label}
                                </span>
                                <span className="text-[8px] font-mono text-white/35">
                                  {dateStr}
                                </span>
                              </div>

                              <p className="text-xs text-white/80 leading-normal font-sans pr-6">
                                {story.fact}
                              </p>
                            </div>

                            {/* Delete point trigger */}
                            <button
                              onClick={() => handleDeleteStory(story.id)}
                              className="p-1.5 rounded-lg bg-white/5 hover:bg-red-500/10 border border-white/5 hover:border-red-500/25 text-white/30 hover:text-red-400 transition-all opacity-0 group-hover:opacity-100 cursor-pointer"
                              title="Excise narrative node"
                            >
                              <Trash2 size={11} />
                            </button>
                          </motion.div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* write Story View */}
              {activeStoryTab === "write" && (
                <form onSubmit={handleSaveStory} className="space-y-4">
                  <div className="bg-gradient-to-r from-violet-950/20 to-pink-950/20 border border-violet-500/25 p-4 rounded-xl space-y-2">
                    <div className="flex items-center gap-2 text-violet-400">
                      <Sparkles size={14} className="animate-pulse" />
                      <h5 className="text-xs font-bold uppercase tracking-wider">Holographic Narrative Synthesis</h5>
                    </div>
                    <p className="text-[10px] text-white/50 leading-relaxed">
                      Your historical timeline, future predictions, or daily milestones are synced live to the AI Studio system and Mimi's cognitive long-term core memory.
                    </p>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[9px] font-bold text-white/50 uppercase tracking-wider pl-1 font-mono">Narrative Type</label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: "future_vision", label: "Future Vision", color: "border-cyan-500/40 text-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.1)]" },
                        { id: "life_history", label: "Life History", color: "border-pink-500/40 text-pink-400 shadow-[0_0_8px_rgba(236,72,153,0.1)]" },
                        { id: "milestone", label: "Milestone Log", color: "border-amber-500/40 text-amber-400 shadow-[0_0_8px_rgba(245,158,11,0.1)]" }
                      ].map((type) => {
                        const isSelected = storyCategory === type.id;
                        return (
                          <button
                            key={type.id}
                            type="button"
                            onClick={() => setStoryCategory(type.id as any)}
                            className={`py-2 text-[10px] rounded-lg border font-bold transition-all text-center cursor-pointer ${
                              isSelected
                                ? `bg-white/5 ${type.color} font-black scale-105`
                                : "bg-black/40 border-white/5 text-white/45 hover:bg-white/5"
                            }`}
                          >
                            {type.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[9px] font-bold text-white/50 uppercase tracking-wider pl-1 font-mono">Biographical Entry / Story Context</label>
                    <textarea
                      value={storyInput}
                      onChange={(e) => setStoryInput(e.target.value)}
                      placeholder={
                        storyCategory === "future_vision" 
                          ? "What is your vision for your future? E.g., 'By 2027, I will expand my AI development studio to launch full-stack neural agents globally...'"
                          : storyCategory === "life_history"
                          ? "Write down a significant past memory or achievement that you expect Mimi to always remember about you..."
                          : "Log an important milestone achieved by you or this AI system today..."
                      }
                      rows={5}
                      className="w-full bg-[#050508] border border-white/10 rounded-xl p-4 text-xs text-white focus:border-violet-500/50 outline-none transition-all placeholder:text-white/20 leading-relaxed resize-none font-sans"
                      maxLength={1000}
                    />
                    <div className="flex justify-between items-center text-[9px] text-white/30 pl-1">
                      <span>Limit: 1000 characters</span>
                      <span>{storyInput.length}/1000</span>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={!storyInput.trim()}
                    className="w-full py-3.5 bg-gradient-to-r from-violet-600 via-purple-600 to-pink-500 hover:from-violet-500 hover:to-pink-400 text-white text-xs font-black uppercase tracking-wider rounded-xl shadow-[0_5px_15px_rgba(139,92,246,0.45)] hover:shadow-[0_8px_25px_rgba(139,92,246,0.65)] disabled:opacity-40 disabled:pointer-events-none active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Save size={13} />
                    <span>Synchronize & Save Story Point</span>
                  </button>
                </form>
              )}

            </div>
          </div>

        </div>

        {/* Live sync logs footer */}
        <div className="bg-black/60 border-t border-white/5 p-4 px-6 relative z-10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-white/40 font-mono text-[9px]">
            <Clock size={11} className="text-violet-400" />
            <span className="text-white/60 font-bold uppercase">Recent Live Trace:</span>
            <span className="truncate max-w-[280px] sm:max-w-[400px]">
              {syncLogs[0] || "No telemetry logged yet."}
            </span>
          </div>

          <div className="flex items-center gap-4 text-[9px] font-mono font-bold text-white/50">
            <span className="flex items-center gap-1.5 bg-violet-500/10 border border-violet-500/25 rounded px-2 py-0.5 text-violet-400">
              <Cpu size={10} /> Auto-repairs: {correctionsCount}
            </span>
            <span className="text-white/35">Version: v9.6.2 Stable</span>
          </div>
        </div>

      </motion.div>
    </div>
  );
};
