import React, { useState, useEffect } from "react";
import { Play, Pause, SkipBack, SkipForward, Volume2, ExternalLink, Youtube, Disc3, MonitorPlay, AlertCircle, Loader2 } from "lucide-react";
import { searchVideo } from "../services/youtubeService";

interface MimiYouTubePlayerProps {
  query: string;
  url: string;
}

export const MimiYouTubePlayer: React.FC<MimiYouTubePlayerProps> = ({ query, url }) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(0);
  const [showEmbed, setShowEmbed] = useState(true); // Requirement 3: Auto-open embedded player
  const [videoId, setVideoId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Search and resolve exact YouTube video ID
  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    setError(null);

    searchVideo(query)
      .then((data) => {
        if (!isMounted) return;
        if (data && data.videoId) {
          setVideoId(data.videoId);
        } else {
          setError("Sorry, I couldn't find that song.");
        }
        setLoading(false);
      })
      .catch((err) => {
        if (!isMounted) return;
        console.error("YouTube search error:", err);
        setError("Sorry, I couldn't find that song.");
        setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [query]);

  // Fake fallback progress bar animation for visual effect when not embedding
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (isPlaying && !showEmbed) {
      interval = setInterval(() => {
        setProgress((prev) => (prev >= 100 ? 0 : prev + 0.5));
      }, 500);
    }
    return () => clearInterval(interval);
  }, [isPlaying, showEmbed]);

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const finalWatchUrl = videoId 
    ? `https://youtube.com/watch?v=${videoId}` 
    : (url || `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`);

  return (
    <div className="w-full rounded-2xl overflow-hidden border border-white/10 bg-[#0f0f11] shadow-2xl flex flex-col font-sans mb-3 text-white max-w-lg md:max-w-xl self-center mx-auto" id={`youtube-player-${query.substring(0, 5)}`}>
      {/* Header Banner */}
      <div className="px-4 py-3 bg-[#1e1e24] flex items-center justify-between border-b border-white/5 shrink-0">
        <div className="flex items-center gap-2">
          <Youtube size={16} className="text-red-500" />
          <span className="text-[11px] font-bold tracking-widest text-white/70 uppercase">Mimi Music Station</span>
        </div>
        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-red-500/20 border border-red-500/30">
          <div className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
          <span className="text-[9px] font-medium text-red-300 uppercase tracking-wider">Mimi Active Player</span>
        </div>
      </div>

      {/* Embedded Live Iframe Player when active */}
      {showEmbed && !loading && !error && videoId ? (
        <div className="w-full aspect-video bg-black relative border-b border-white/5">
          <iframe
            width="100%"
            height="100%"
            src={`https://www.youtube.com/embed/${videoId}?autoplay=1&mute=0`}
            title={`Mimi Stream: ${query}`}
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            className="w-full h-full"
          />
        </div>
      ) : null}

      {/* Loading state spinner */}
      {loading && (
        <div className="w-full aspect-video flex flex-col items-center justify-center bg-black/60 p-6 min-h-[160px] border-b border-white/5 gap-3">
          <Loader2 size={32} className="text-cyan-400 animate-spin" />
          <span className="text-xs text-white/60 font-mono">Sourcing best audio match from YouTube Nodes...</span>
        </div>
      )}

      {/* Error state display */}
      {error && !loading && (
        <div className="w-full aspect-video flex flex-col items-center justify-center bg-red-950/20 p-6 min-h-[160px] border-b border-white/5 gap-3">
          <AlertCircle size={32} className="text-red-400" />
          <span className="text-sm font-semibold text-red-200">{error}</span>
          <span className="text-[10px] text-white/40">Try saying another song name or use normal search.</span>
        </div>
      )}

      {/* Player Controls & Info Dashboard */}
      <div className="p-5 flex flex-col sm:flex-row items-center gap-5 bg-gradient-to-br from-[#121215] to-[#18181f]">
        
        {/* Album Art / Disk Animation */}
        {(!showEmbed || loading || error) && (
          <div className="relative shrink-0 flex items-center justify-center">
            <div className={`w-24 h-24 rounded-full bg-gradient-to-tr from-rose-900 to-indigo-900 flex items-center justify-center shadow-lg border border-white/10 ${isPlaying ? 'animate-spin-slow' : ''}`} style={{ animationDuration: '4s' }}>
              <Disc3 size={40} className="text-white/40" />
              <div className="absolute inset-0 rounded-full border-4 border-black/40" />
              <div className="w-6 h-6 rounded-full bg-[#121215] absolute z-10 border border-white/5" />
            </div>
          </div>
        )}
 
        {/* Track Info & Controls */}
        <div className="flex-1 w-full flex flex-col">
          <div className="flex flex-col text-center sm:text-left">
            <span className="text-cyan-400 text-[10px] font-mono tracking-widest uppercase mb-1 drop-shadow-sm">Now Auditing</span>
            <h3 className="text-sm sm:text-base font-bold text-white line-clamp-2 leading-tight">{query}</h3>
            <p className="text-xs text-white/50 mt-1">Sourced from Live Search Database</p>
          </div>

          {/* Progress Bar (Only show if not streaming live video directly) */}
          {(!showEmbed || loading || error) && (
            <div className="w-full mt-4 flex items-center gap-2">
              <span className="text-[10px] text-white/40 font-mono">0:00</span>
              <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-500 ease-linear"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <span className="text-[10px] text-white/40 font-mono">3:45</span>
            </div>
          )}

          {/* Player controls */}
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 mt-4">
            <Volume2 size={14} className="text-white/40 hover:text-white transition-colors cursor-pointer" />
            <SkipBack size={18} className="text-white/60 hover:text-white transition-colors cursor-pointer" />
            
            <button 
              onClick={togglePlay}
              disabled={loading}
              className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 transition-transform disabled:opacity-50"
            >
              {isPlaying && (!showEmbed || loading) ? <Pause size={18} className="fill-current" /> : <Play size={18} className="fill-current ml-1" />}
            </button>
            
            <SkipForward size={18} className="text-white/60 hover:text-white transition-colors cursor-pointer" />

            {videoId && !error && (
              <button
                onClick={() => setShowEmbed(!showEmbed)}
                className={`px-3 py-1.5 rounded-lg text-[10px] font-bold tracking-wider uppercase transition-all flex items-center gap-1.5 ${showEmbed ? 'bg-red-500/20 border border-red-500/40 text-red-400 hover:bg-red-500/30' : 'bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 hover:bg-cyan-500/25'}`}
              >
                <MonitorPlay size={12} />
                {showEmbed ? "Close Video Screen" : "Play inside Mimi"}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Launch YouTube Button Footer */}
      <div className="p-3 bg-black flex justify-between items-center sm:hidden">
        <span className="text-[10px] text-white/50">Listen directly from YouTube</span>
        <a
          href={finalWatchUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-red-600/20 hover:bg-red-600/40 text-red-400 transition-colors flex items-center gap-1.5"
        >
          <Youtube size={14} /> Open watch URL
        </a>
      </div>
      <div className="hidden sm:flex p-3 bg-black justify-between items-center px-5">
        <span className="text-xs text-white/50 flex items-center gap-1.5">
           Listen on official service player node
        </span>
        <a
          href={finalWatchUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="px-4 py-2 rounded-lg text-xs font-bold bg-white text-black hover:bg-gray-200 transition-colors flex items-center gap-2 shadow-lg"
        >
          <Youtube size={16} className="text-red-600" /> Complete Playback on YouTube <ExternalLink size={14} className="opacity-50 text-black" />
        </a>
      </div>
    </div>
  );
};
