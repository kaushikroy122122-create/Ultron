import React, { useEffect, useState, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Terminal, Cpu, Search, Code, ShieldCheck, Activity, Brain, Server, Zap, ChevronRight, AlertCircle } from "lucide-react";
import { selfRepairer, DiagnosticLog } from "../services/selfRepairService";
import { cn } from "../lib/utils";

interface SystemMonitorProps {
  neuralCore: string;
  isActive: boolean;
}

export const SystemMonitor: React.FC<SystemMonitorProps> = ({ neuralCore, isActive }) => {
  const [logs, setLogs] = useState<DiagnosticLog[]>([]);
  const [activeTask, setActiveTask] = useState<{ type: string, message: string } | null>(null);
  const [performance, setPerformance] = useState({ cpu: 12, mem: 45, latency: 120 });
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    selfRepairer.setLogListener((newLogs) => {
      setLogs(newLogs);
    });
    selfRepairer.setTaskListener((task) => {
      setActiveTask(task);
    });

    // Simulate performance fluctuations
    const interval = setInterval(() => {
      setPerformance({
        cpu: Math.floor(Math.random() * 20) + 5,
        mem: Math.floor(Math.random() * 5) + 40,
        latency: Math.floor(Math.random() * 30) + 110,
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  if (!isActive) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-40 overflow-hidden font-mono">
      {/* Decorative Grid Lines */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(18,24,27,0.8)_1px,transparent_1px),linear-gradient(90deg,rgba(18,24,27,0.8)_1px,transparent_1px)] bg-[size:40px_40px] opacity-20" />
      
      {/* Top Status Bar */}
      <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-start">
        <div className="flex flex-col gap-2">
          <motion.div 
            initial={{ x: -100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="flex items-center gap-3 bg-black/60 backdrop-blur-md border border-cyan-500/30 px-4 py-2 rounded-lg"
          >
            <div className="relative">
              <Brain size={20} className="text-cyan-400" />
              <motion.div 
                animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute inset-0 bg-cyan-400/20 blur-md rounded-full"
              />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] text-cyan-400/60 uppercase font-bold tracking-widest leading-none">Neural Link Status</span>
              <span className="text-sm font-bold text-white tracking-tighter">Synchronized (Build: v2.4 Active)</span>
            </div>
          </motion.div>

          <AnimatePresence>
            {activeTask && (
              <motion.div 
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -20, opacity: 0 }}
                className="flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/30 px-4 py-2 rounded-lg"
              >
                {activeTask.type === 'search' ? <Search size={14} className="text-emerald-400 animate-pulse" /> : <Code size={14} className="text-emerald-400 animate-pulse" />}
                <span className="text-xs text-emerald-400 font-bold uppercase tracking-tight">
                  {activeTask.type === 'search' ? 'Searching:' : 'Processing:'} {activeTask.message}
                </span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <motion.div 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="flex gap-4"
        >
          <div className="bg-black/60 border border-white/5 px-4 py-2 rounded-lg flex gap-6">
            <div className="flex flex-col">
              <span className="text-[8px] text-white/30 uppercase font-bold">CPU Load</span>
              <span className="text-xs text-cyan-400 font-bold">{performance.cpu}%</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[8px] text-white/30 uppercase font-bold">Memory</span>
              <span className="text-xs text-cyan-400 font-bold">{performance.mem}%</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[8px] text-white/30 uppercase font-bold">Latency</span>
              <span className="text-xs text-emerald-400 font-bold">{performance.latency}ms</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Bottom Right: Diagnostic Logs */}
      <motion.div 
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="absolute bottom-6 right-6 w-80 max-h-[40vh] bg-black/80 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden flex flex-col pointer-events-auto shadow-2xl"
      >
        <div className="px-4 py-2 border-b border-white/5 bg-white/5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Terminal size={14} className="text-cyan-400" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">Logic Optimization Logs</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[8px] text-white/20 uppercase">Debug: Passive</span>
            <Activity size={12} className="text-emerald-500 animate-pulse" />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar text-[10px] border border-solid border-white/5">
          {logs.length === 0 && (
            <div className="text-white/20 italic">Awaiting neural signals...</div>
          )}
          {logs.map((log) => (
            <div key={log.id} className="flex gap-2 group">
              <span className="text-white/20 shrink-0">{log.timestamp.toLocaleTimeString([], { hour12: false })}</span>
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-1.5">
                  <span className={cn(
                    "w-1 h-3 rounded-full",
                    log.type === 'sync' ? 'bg-amber-400' : 
                    log.type === 'drift' ? 'bg-orange-500' :
                    log.type === 'optimize' ? 'bg-emerald-500' : 'bg-cyan-500'
                  )} />
                  <span className={cn(
                    "font-bold uppercase tracking-tighter",
                    log.type === 'sync' ? 'text-amber-400' : 
                    log.type === 'drift' ? 'text-orange-400' :
                    log.type === 'optimize' ? 'text-emerald-400' : 'text-cyan-400'
                  )}>
                    {log.message}
                  </span>
                </div>
                {log.details && (
                  <p className="text-white/40 leading-relaxed font-sans">{log.details}</p>
                )}
              </div>
            </div>
          ))}
          <div ref={logEndRef} />
        </div>
      </motion.div>

      {/* Left Center: Auto-Code Matrix */}
      <AnimatePresence>
        {['Gemini', 'ChatGPT', 'Claude', 'Grok', 'DeepSeek', 'MetaAI', 'Copilot', 'Perplexity', 'Kimi'].includes(neuralCore) && (
          <motion.div 
            initial={{ x: -200, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -200, opacity: 0 }}
            className="absolute left-6 top-1/2 -translate-y-1/2 w-64 bg-black/55 border-l border-cyan-500/30 p-4 flex flex-col gap-4 shadow-xl backdrop-blur-md rounded-r-xl"
          >
            <div className="flex items-center gap-2">
              <div className="p-1 rounded bg-cyan-500/20 text-cyan-400">
                <Zap size={14} />
              </div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-cyan-400">
                {neuralCore === 'MetaAI' ? 'Meta AI Core' :
                 neuralCore === 'Copilot' ? 'Copilot Suite' :
                 neuralCore === 'Perplexity' ? 'Perplexity Search' :
                 `${neuralCore} Core`}
              </span>
            </div>
            
            <div className="space-y-4">
              {neuralCore === 'Gemini' && (
                <>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Live Frame Rate</span>
                      <span className="text-cyan-400">60 FPS</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div animate={{ width: "95%" }} className="h-full bg-cyan-400" />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Workspace Tools</span>
                      <span className="text-emerald-400">GSD-Link-OK</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div animate={{ x: ["-100%", "100%"] }} transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }} className="h-full w-1/3 bg-emerald-400" />
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-white/5 rounded-lg border border-white/5 text-[9px] text-white/40 leading-loose italic">
                    "Google Gemini model processes multimodal webcam frames and system voice stream inputs."
                  </div>
                </>
              )}

              {neuralCore === 'ChatGPT' && (
                <>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>GPT-4o Logic Core</span>
                      <span className="text-cyan-400">99.8%</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div animate={{ width: "99.8%" }} className="h-full bg-cyan-400" />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Interactive Directive</span>
                      <span className="text-pink-400">Enabled</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div animate={{ width: "100%" }} className="h-full bg-pink-500" />
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-white/5 rounded-lg border border-white/5 text-[9px] text-white/40 leading-loose italic">
                    "OpenAI weights synchronized for conversational responses with rich formatting."
                  </div>
                </>
              )}

              {neuralCore === 'Claude' && (
                <>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Meticulous Web Tracing</span>
                      <span className="text-amber-400">Active</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div animate={{ width: "94%" }} className="h-full bg-amber-400" />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Artifact Refactoring</span>
                      <span className="text-indigo-400">Armed</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div animate={{ x: ["-100%", "100%"] }} transition={{ duration: 2.2, repeat: Infinity, ease: "linear" }} className="h-full w-1/4 bg-indigo-400" />
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-white/5 rounded-lg border border-white/5 text-[9px] text-white/40 leading-loose italic">
                    "Anthropic's nuanced code profiles and clear UI suggestions successfully mapped."
                  </div>
                </>
              )}

              {neuralCore === 'Grok' && (
                <>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Real-time X Data</span>
                      <span className="text-cyan-400">Grounded</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div animate={{ width: "91%" }} className="h-full bg-cyan-400" />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Sarcasm Level</span>
                      <span className="text-purple-400">Max Active</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div animate={{ width: "85%" }} className="h-full bg-purple-500" />
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-white/5 rounded-lg border border-white/5 text-[9px] text-white/40 leading-loose italic">
                    "xAI real-time context streaming active. Prepared to deliver humorous and trendy views."
                  </div>
                </>
              )}

              {neuralCore === 'DeepSeek' && (
                <>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Deep Reasoning (R1)</span>
                      <span className="text-emerald-400">Thinking</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div animate={{ x: ["-100%", "100%"] }} transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }} className="h-full w-1/3 bg-emerald-400" />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Log Trace Math</span>
                      <span className="text-sky-400">Verifying</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div animate={{ width: '88%' }} className="h-full bg-sky-400" />
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-white/5 rounded-lg border border-white/5 text-[9px] text-white/40 leading-loose italic">
                    "Mimi deep reasoning parser enabled. Output starting with {'<think>'} block traces logical chains."
                  </div>
                </>
              )}

              {neuralCore === 'MetaAI' && (
                <>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Llama 3.3 Companionship</span>
                      <span className="text-rose-400">Empathy On</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div animate={{ scaleX: [1, 1.2, 1] }} transition={{ duration: 1.8, repeat: Infinity }} className="h-full bg-rose-400 origin-left" />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Fast Social Context</span>
                      <span className="text-violet-400">92%</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div animate={{ width: "92%" }} className="h-full bg-violet-400" />
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-white/5 rounded-lg border border-white/5 text-[9px] text-white/40 leading-loose italic">
                    "Meta-weighted models set up for engaging, creative response delivery in English / Bengali."
                  </div>
                </>
              )}

              {neuralCore === 'Copilot' && (
                <>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Office Productivity Link</span>
                      <span className="text-teal-400">Active</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div animate={{ width: "93%" }} className="h-full bg-teal-400" />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Template Helper</span>
                      <span className="text-blue-400">Online</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div animate={{ x: ["-100%", "100%"] }} transition={{ duration: 2, repeat: Infinity, ease: "linear" }} className="h-full w-1/5 bg-blue-400" />
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-white/5 rounded-lg border border-white/5 text-[9px] text-white/40 leading-loose italic">
                    "Microsoft business-optimized copilot parameters linked. Ideal for spreadsheet mapping and reports."
                  </div>
                </>
              )}

              {neuralCore === 'Perplexity' && (
                <>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Multi-Agent Search</span>
                      <span className="text-cyan-400">Grounding...</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div animate={{ x: ["-100%", "100%"] }} transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }} className="h-full w-1/2 bg-cyan-400" />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Dense Citation links</span>
                      <span className="text-emerald-400">[1][2][3] OK</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div animate={{ width: "97%" }} className="h-full bg-emerald-400" />
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-white/5 rounded-lg border border-white/5 text-[9px] text-white/40 leading-loose italic">
                    "Deep-grounding crawler enabled. Responses generated with authentic research bibliographies."
                  </div>
                </>
              )}

              {neuralCore === 'Kimi' && (
                <>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Logic Synthesis</span>
                      <span className="text-cyan-400">98%</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div 
                        animate={{ width: "98%" }}
                        className="h-full bg-cyan-400"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-[8px] uppercase font-bold text-white/40">
                      <span>Auto-Repair Flow</span>
                      <span className="text-emerald-400">Active</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div 
                        animate={{ x: ["-100%", "100%"] }}
                        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                        className="h-full w-1/3 bg-emerald-400"
                      />
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-white/5 rounded-lg border border-white/5 text-[9px] text-white/40 leading-loose italic">
                    "System stability prioritized via Kimi-optimized neural weights. Auto-coding buffer initialized."
                  </div>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Center: System Alert Overlay (Only during Optimization) */}
      <AnimatePresence>
        {logs[0]?.type === 'optimize' && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center gap-6"
          >
            <div className="relative">
              <ShieldCheck size={80} className="text-emerald-500/40" />
              <motion.div 
                animate={{ scale: [1, 1.5], opacity: [0.5, 0] }}
                transition={{ duration: 1, repeat: Infinity }}
                className="absolute inset-0 border-4 border-emerald-500 rounded-full"
              />
            </div>
            <div className="text-center space-y-2">
              <h2 className="text-xl font-bold text-emerald-400 uppercase tracking-widest">Neural Optimization Active</h2>
              <p className="text-xs text-white/40 uppercase tracking-tighter">Synchronizing High-Level Logic Pathways</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
