import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";

export default function SassyAnimations({ sassiness, isJoking, isAngry }: { sassiness: number, isJoking: boolean, isAngry: boolean }) {
  const isSassy = sassiness > 85;
  const [emojis, setEmojis] = useState<{ id: number; symbol: string; x: number }[]>([]);

  useEffect(() => {
    if (!isSassy || (!isJoking && !isAngry)) return;

    const interval = setInterval(() => {
      let symbols: string[] = [];
      if (isJoking) symbols = ["😜", "😂", "🤣", "😝", "🤪"];
      if (isAngry) symbols = ["😡", "😤", "🤬", "😠", "💢"];
      
      if (symbols.length === 0) return;

      const newEmoji = {
        id: Date.now(),
        symbol: symbols[Math.floor(Math.random() * symbols.length)],
        x: Math.random() * 80 + 10,
      };
      setEmojis((prev) => [...prev.slice(-10), newEmoji]);
    }, 1500);

    return () => clearInterval(interval);
  }, [isSassy, isJoking, isAngry]);

  if (!isSassy || (!isJoking && !isAngry)) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {/* Background Strobe */}
      <motion.div
        animate={{ opacity: [0, 0.05, 0] }}
        transition={{ duration: 0.5, repeat: Infinity, repeatType: "mirror" }}
        className="absolute inset-0 bg-pink-500"
      />

      {/* Floating Emojis */}
      <AnimatePresence>
        {emojis.map((emoji) => (
          <motion.div
            key={emoji.id}
            initial={{ y: "100vh", opacity: 0 }}
            animate={{ y: "-10vh", opacity: 1, scale: [1, 1.5, 1] }}
            exit={{ opacity: 0 }}
            transition={{ duration: 4, ease: "linear" }}
            className="absolute text-6xl"
            style={{ left: `${emoji.x}%` }}
            onAnimationComplete={() => {
              setEmojis((prev) => prev.filter((e) => e.id !== emoji.id));
            }}
          >
            {emoji.symbol}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
