import React, { useState, useEffect, useCallback } from "react";
import { Wifi, WifiOff, RefreshCw, Activity, Server, CheckCircle2, AlertTriangle, X } from "lucide-react";

interface ServerLinkItem {
  id: string;
  name: string;
  url: string;
  type: string;
  enabled: boolean;
}

interface WifiScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  serverLinks?: ServerLinkItem[];
  darkMode?: boolean;
}

interface ProbeResult {
  online: boolean;
  effectiveType: string;
  downlinkMbps: number | null;
  rttMs: number | null;
  saveData: boolean;
  apiLatencyMs: number | null;
  apiHealthy: boolean;
  apiKeyReady: boolean;
  checkedAt: string;
}

export const WifiScannerModal: React.FC<WifiScannerModalProps> = ({
  isOpen,
  onClose,
  serverLinks = [],
  darkMode = false,
}) => {
  const [scanning, setScanning] = useState(false);
  const [probe, setProbe] = useState<ProbeResult | null>(null);

  const runNetworkScan = useCallback(async () => {
    setScanning(true);
    const navConn = (navigator as unknown as {
      connection?: {
        effectiveType?: string;
        downlink?: number;
        rtt?: number;
        saveData?: boolean;
      };
    }).connection;

    let apiLatencyMs: number | null = null;
    let apiHealthy = false;
    let apiKeyReady = false;

    const start = performance.now();
    try {
      const res = await fetch("/api/health", { cache: "no-store" });
      apiLatencyMs = Math.round(performance.now() - start);
      if (res.ok) {
        const data = await res.json();
        apiHealthy = data.status === "ok";
        apiKeyReady = Boolean(data.apiKeySet);
      }
    } catch {
      apiHealthy = false;
    }

    setProbe({
      online: navigator.onLine,
      effectiveType: navConn?.effectiveType || "unknown",
      downlinkMbps: typeof navConn?.downlink === "number" ? navConn.downlink : null,
      rttMs: typeof navConn?.rtt === "number" ? navConn.rtt : null,
      saveData: Boolean(navConn?.saveData),
      apiLatencyMs,
      apiHealthy,
      apiKeyReady,
      checkedAt: new Date().toLocaleTimeString(),
    });
    setScanning(false);
  }, []);

  useEffect(() => {
    if (isOpen) {
      runNetworkScan();
    }
  }, [isOpen, runNetworkScan]);

  if (!isOpen) return null;

  const qualityLabel = !probe?.online
    ? "Offline"
    : probe.apiLatencyMs !== null && probe.apiLatencyMs < 150
      ? "Excellent"
      : probe.apiLatencyMs !== null && probe.apiLatencyMs < 400
        ? "Good"
        : "Fair";

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Wi-Fi and Network Scanner"
      className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className={`w-full max-w-lg rounded-3xl border shadow-2xl overflow-hidden ${
          darkMode
            ? "bg-[#22211E] border-[#383630] text-[#F2EFE9]"
            : "bg-[#FAF9F5] border-[#E5E2D9] text-[#1F1E1B]"
        }`}
      >
        <div
          className={`px-5 py-4 border-b flex items-center justify-between ${
            darkMode ? "border-[#383630]" : "border-[#E5E2D9]"
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#C96442]/15 text-[#C96442] flex items-center justify-center">
              {probe?.online === false ? <WifiOff size={18} /> : <Wifi size={18} />}
            </div>
            <div>
              <h2 className="text-base font-semibold">Wi-Fi & Network Diagnostics</h2>
              <p className={`text-xs ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>
                Live browser connection & Mimi server probe
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Wi-Fi Scanner"
            className={`min-h-[38px] min-w-[38px] rounded-xl border flex items-center justify-center cursor-pointer ${
              darkMode
                ? "bg-[#2A2925] hover:bg-[#34322D] border-[#383630] text-[#F2EFE9]"
                : "bg-[#F3F1EA] hover:bg-[#EAE6DC] border-[#E5E2D9] text-[#1F1E1B]"
            }`}
          >
            <X size={16} />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div
              className={`p-3.5 rounded-2xl border ${
                darkMode ? "bg-[#191816] border-[#383630]" : "bg-white border-[#E5E2D9]"
              }`}
            >
              <div className={`text-xs ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>
                Link Status
              </div>
              <div className="mt-1 flex items-center gap-2 text-sm font-semibold">
                {probe?.online ? (
                  <CheckCircle2 size={15} className="text-emerald-600 dark:text-emerald-400" />
                ) : (
                  <AlertTriangle size={15} className="text-amber-500" />
                )}
                <span>{probe ? `${probe.online ? "Online" : "Offline"} (${qualityLabel})` : "Checking..."}</span>
              </div>
            </div>

            <div
              className={`p-3.5 rounded-2xl border ${
                darkMode ? "bg-[#191816] border-[#383630]" : "bg-white border-[#E5E2D9]"
              }`}
            >
              <div className={`text-xs ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>
                API Round-Trip
              </div>
              <div className="mt-1 flex items-center gap-2 text-sm font-semibold">
                <Activity size={15} className="text-[#C96442]" />
                <span>
                  {probe?.apiLatencyMs !== null && probe?.apiLatencyMs !== undefined
                    ? `${probe.apiLatencyMs} ms`
                    : "Unreachable"}
                </span>
              </div>
            </div>

            <div
              className={`p-3.5 rounded-2xl border ${
                darkMode ? "bg-[#191816] border-[#383630]" : "bg-white border-[#E5E2D9]"
              }`}
            >
              <div className={`text-xs ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>
                Downlink / Type
              </div>
              <div className="mt-1 text-sm font-semibold">
                {probe?.downlinkMbps !== null && probe?.downlinkMbps !== undefined
                  ? `${probe.downlinkMbps} Mbps`
                  : "Browser restricted"}{" "}
                <span className={`text-xs font-normal ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>
                  ({probe?.effectiveType || "n/a"})
                </span>
              </div>
            </div>

            <div
              className={`p-3.5 rounded-2xl border ${
                darkMode ? "bg-[#191816] border-[#383630]" : "bg-white border-[#E5E2D9]"
              }`}
            >
              <div className={`text-xs ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>
                Gemini Server Node
              </div>
              <div className="mt-1 flex items-center gap-2 text-sm font-semibold">
                <Server size={14} className="text-[#C96442]" />
                <span>{probe?.apiHealthy ? (probe.apiKeyReady ? "Ready" : "Proxy Active") : "Standby"}</span>
              </div>
            </div>
          </div>

          {serverLinks.length > 0 && (
            <div
              className={`p-3.5 rounded-2xl border space-y-2 ${
                darkMode ? "bg-[#191816] border-[#383630]" : "bg-white border-[#E5E2D9]"
              }`}
            >
              <div className={`text-xs font-medium ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>
                Configured Network Endpoints ({serverLinks.filter((s) => s.enabled).length} enabled)
              </div>
              <div className="space-y-1.5 max-h-32 overflow-y-auto claude-scroll">
                {serverLinks.map((node) => (
                  <div
                    key={node.id}
                    className={`flex items-center justify-between text-xs px-2.5 py-1.5 rounded-lg ${
                      darkMode ? "bg-[#22211E]" : "bg-[#FAF9F5]"
                    }`}
                  >
                    <span className="font-medium truncate mr-2">{node.name}</span>
                    <span
                      className={`text-[11px] px-2 py-0.5 rounded-full ${
                        node.enabled
                          ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300"
                          : "bg-stone-500/15 text-stone-500"
                      }`}
                    >
                      {node.enabled ? node.type : "disabled"}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <p className={`text-[11px] leading-relaxed ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>
            Note: Web browsers do not expose nearby Wi-Fi SSID lists for privacy reasons. Above metrics show live browser Network Information API & server reachability readings.
          </p>

          <div className="flex items-center justify-between pt-1">
            <span className={`text-xs ${darkMode ? "text-[#A6A196]" : "text-[#6B675E]"}`}>
              {probe ? `Last checked at ${probe.checkedAt}` : ""}
            </span>
            <button
              type="button"
              onClick={runNetworkScan}
              disabled={scanning}
              className="min-h-[40px] px-4 rounded-xl bg-[#C96442] hover:bg-[#B55534] disabled:opacity-60 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer"
            >
              <RefreshCw size={14} className={scanning ? "animate-spin" : ""} />
              <span>{scanning ? "Scanning..." : "Rescan Network"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
