import React, { useState } from "react";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

interface SortableWidgetProps {
  id: string;
  children: React.ReactNode;
  key?: React.Key;
}

const SortableWidget = ({ id, children }: SortableWidgetProps) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div ref={setNodeRef} style={style} {...attributes} {...listeners} className="cursor-grab">
      {children}
    </div>
  );
};

interface DashboardGridProps {
  isEditMode: boolean;
  widgets: { id: string; content: React.ReactNode }[];
  onOrderChange: (widgets: { id: string; content: React.ReactNode }[]) => void;
}

export const DashboardGrid = ({ isEditMode, widgets, onOrderChange }: DashboardGridProps) => {
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = (event: any) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = widgets.findIndex((item) => item.id === active.id);
      const newIndex = widgets.findIndex((item) => item.id === over.id);

      if (oldIndex !== -1 && newIndex !== -1) {
        onOrderChange(arrayMove(widgets, oldIndex, newIndex));
      }
    }
  };

  return (
    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
      <SortableContext items={widgets.map((w) => w.id)} strategy={verticalListSortingStrategy}>
        <div className="grid gap-4 dashboard-grid">
          {widgets.map((widget) => (
            isEditMode ? (
              <SortableWidget key={widget.id} id={widget.id}>
                <div className="widget-container">{widget.content}</div>
              </SortableWidget>
            ) : (
              <div key={widget.id} className="widget-container">{widget.content}</div>
            )
          ))}
        </div>
      </SortableContext>
    </DndContext>
  );
};
