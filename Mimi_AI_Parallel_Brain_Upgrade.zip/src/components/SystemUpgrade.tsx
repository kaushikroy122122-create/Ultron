import React, { useState, useEffect } from "react";
import { Terminal, Cpu, Database, Network, ShieldCheck, Download, Code2, Server } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface SystemUpgradeProps {
  onComplete: () => void;
}

export const SystemUpgrade: React.FC<SystemUpgradeProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [currentTask, setCurrentTask] = useState("Initializing kernel modules...");
  const [logs, setLogs] = useState<string[]>([]);
  const [phase, setPhase] = useState(0);

  const tasks = [
    "Compiling advanced audio codecs...",
    "Rebuilding audio visualizer core...",
    "Updating Mimi semantic routing...",
    "Enhancing neural processor nodes...",
    "Synchronizing cloud configurations...",
    "Upgrading database schemas...",
    "Applying quantum shield patches...",
    "Finalizing system update..."
  ];

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    
    interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => onComplete(), 1000);
          return 100;
        }
        
        const next = prev + (Math.random() * 2 + 1); // 1-3% jumps
        
        // Update task phase based on progress
        const taskIdx = Math.min(Math.floor((next / 100) * tasks.length), tasks.length - 1);
        if (taskIdx !== phase) {
          setPhase(taskIdx);
          setCurrentTask(tasks[taskIdx]);
        }
        
        // Add random log
        if (Math.random() > 0.6) {
          const hex = Array(4).fill(0).map(() => Math.floor(Math.random()*16).toString(16)).join('');
          setLogs(prevLogs => {
            const newLogs = [...prevLogs, `[${new Date().toISOString().split('T')[1].slice(0, -1)}] SYS_UPDATE_0x${hex} OK`];
            return newLogs.slice(-6);
          });
        }
        
        return Math.min(next, 100);
      });
    }, 100);
    
    return () => clearInterval(interval);
  }, [phase, onComplete]);

  return (
    <div className="absolute inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl font-mono">
      <div className="w-full max-w-2xl bg-[#09090b] border border-cyan-500/30 rounded-2xl p-6 shadow-[0_0_50px_rgba(6,182,212,0.15)] flex flex-col overflow-hidden relative">
        
        {/* Background grid */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
             style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '24px 24px' }} />

        {/* Header */}
        <div className="flex items-center justify-between mb-8 pb-4 border-b border-white/10 z-10">
           <div className="flex items-center gap-3">
             <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center">
               <Server size={20} className="text-cyan-400" />
             </div>
             <div>
               <h2 className="text-xl font-bold text-white tracking-widest uppercase">System Upgrade</h2>
               <p className="text-xs text-cyan-500 font-mono">Audio Engine & Core System</p>
             </div>
           </div>
           
           <div className="flex items-center gap-2">
             <span className="w-2.5 h-2.5 rounded-full bg-red-500/50" />
             <span className="w-2.5 h-2.5 rounded-full bg-amber-500/50" />
             <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
           </div>
        </div>

        {/* Status Body */}
        <div className="flex flex-col md:flex-row gap-8 mb-8 z-10">
          
          {/* Main Progress section */}
          <div className="flex-1 flex flex-col gap-4 justify-between">
             <div className="space-y-4">
               <div className="flex items-center justify-between">
                 <span className="text-sm text-white/70 uppercase">Progress</span>
                 <span className="text-2xl font-bold text-cyan-400 drop-shadow-[0_0_8px_rgba(6,182,212,0.45)]">{Math.floor(progress)}%</span>
               </div>
               
               {/* Progress Bar */}
               <div className="w-full h-3 bg-black border border-white/10 rounded-full overflow-hidden relative">
                 <motion.div 
                   className="absolute top-0 left-0 bottom-0 bg-gradient-to-r from-cyan-550 via-violet-550 to-pink-500 shadow-[0_0_15px_rgba(139,92,246,0.65)]"
                   initial={{ width: 0 }}
                   animate={{ width: `${progress}%` }}
                 />
               </div>

               <div className="text-xs text-cyan-300 mt-2 min-h-[1.5rem] flex items-center gap-2">
                  <motion.div 
                    animate={{ rotate: 360 }} 
                    transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  >
                    <Cpu size={14} className="text-cyan-400" />
                  </motion.div>
                  {currentTask}
               </div>
             </div>

             {/* Console Output */}
             <div className="bg-black/50 border border-white/5 rounded-2xl p-4 flex flex-col font-mono text-[9px] text-white/40 h-28 overflow-hidden relative">
               <div className="flex items-center justify-between border-b border-white/5 pb-2 mb-2">
                 <span className="uppercase tracking-widest font-black text-emerald-400/80">Calibration Logs</span>
                 <Terminal size={10} className="text-emerald-400/80" />
               </div>
               <div className="flex flex-col gap-1 flex-1 overflow-hidden">
                  {logs.slice(-3).map((log, i) => (
                    <span key={i} className="text-emerald-400/80 truncate font-semibold">{log}</span>
                  ))}
                  <span className="animate-pulse text-emerald-400/90 font-bold">_ SYSTEM_ACTIVE_PING_SECURE_STABLE_UPGRADE:OK</span>
               </div>
             </div>
          </div>

          {/* 3D Hologram Server Core Panel on Right column */}
          <div className="flex-[0.9] border border-white/10 p-4 rounded-3xl bg-black/40 backdrop-blur-2xl relative overflow-hidden group select-none flex flex-col justify-between">
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent z-10 pointer-events-none" />
            <div className="absolute -top-12 -right-12 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />
            
            {/* 3D Quantum Server Image with Hover Depth */}
            <div className="relative w-full h-36 rounded-2xl overflow-hidden border border-white/10 shadow-[0_8px_30px_rgb(0,0,0,0.8)]">
              <img 
                src="/src/assets/images/colorful_3d_core_1782217293823.jpg"
                alt="Quantum Server Core Upgrade Hologram"
                className="w-full h-full object-cover transition-transform duration-700 hover:scale-110" 
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-x-0 bottom-0 bg-black/60 backdrop-blur-sm p-2 flex items-center justify-between border-t border-white/5">
                <span className="text-[8px] text-white/50 font-mono tracking-widest">GRID ALIGNED</span>
                <span className="text-[8px] bg-cyan-400/20 text-cyan-300 font-black border border-cyan-400/30 px-1.5 py-0.5 rounded font-mono">CORE_V9.4</span>
              </div>
            </div>

            <div className="mt-3 space-y-1 text-left">
              <div className="flex items-center gap-1.5 text-violet-400">
                <Server size={12} className="animate-pulse" />
                <span className="text-[10px] font-black uppercase tracking-wider font-mono">Dynamic Thermal Vector</span>
              </div>
              <p className="text-[10px] text-white/55 font-sans leading-tight">
                Quantum alignment of SOTA kernels is running in dry-mode auto-recoil. No system logs are lost during hot-swapping.
              </p>
            </div>
          </div>
        </div>

        {/* Modules status */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 z-10">
          {[
            { icon: Code2, label: "Audio Codec", p: progress > 15 },
            { icon: Database, label: "Data Schema", p: progress > 45 },
            { icon: Network, label: "Neural Routing", p: progress > 70 },
            { icon: ShieldCheck, label: "Security", p: progress > 90 }
          ].map((m, i) => (
            <div key={i} className={`flex flex-col gap-2 p-3 rounded-xl border transition-all duration-500 ${m.p ? 'bg-cyan-500/10 border-cyan-500/30' : 'bg-white/5 border-white/5'}`}>
              <div className="flex items-center justify-between">
                <m.icon size={16} className={m.p ? 'text-cyan-400' : 'text-white/20'} />
                {m.p ? <span className="text-[10px] text-cyan-400 font-bold uppercase">Online</span> : <span className="text-[10px] text-white/20 uppercase">Pending</span>}
              </div>
              <span className={`text-[10px] uppercase font-bold tracking-wider ${m.p ? 'text-white' : 'text-white/40'}`}>{m.label}</span>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};
