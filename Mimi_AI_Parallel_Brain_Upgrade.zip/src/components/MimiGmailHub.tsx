import React, { useState, useEffect, useRef } from "react";
import { 
  Mail, X, Search, Send, RefreshCw, Trash2, Check, AlertTriangle, 
  ChevronRight, Inbox, Clock, Edit3, Send as SentIcon, ExternalLink,
  Bot, ShieldCheck, MailQuestion, Compass, Star, HardDrive, MessageSquare,
  CheckSquare, Users, PlusCircle, UserPlus, Upload, FileText, FileImage, FileCode, CheckCircle2,
  Trash, Eye, AlertCircle, FileSpreadsheet, Plus, CornerDownLeft, Table
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { 
  GmailMessage, getGmailInbox, markAsRead, trashMessage, sendEmail 
} from "../services/gmailService";
import {
  DriveFile, listDriveFiles, uploadDriveFile, deleteDriveFile
} from "../services/driveService";
import {
  ChatSpace, ChatMessage, listChatSpaces, listChatMessages, sendChatMessage
} from "../services/chatService";
import {
  GoogleTaskList, GoogleTask, listTaskLists, listTasks, createGoogleTask, updateGoogleTask, deleteGoogleTask
} from "../services/tasksService";
import {
  GoogleContact, listGoogleContacts, createGoogleContact, deleteGoogleContact
} from "../services/contactsService";
import {
  SheetInfo, SheetTab, SpreadsheetDetail, listSpreadsheets, createSpreadsheet, getSpreadsheetDetails, getSheetValues, updateSheetValues, appendSheetRow
} from "../services/sheetsService";

interface MimiGmailHubProps {
  isOpen: boolean;
  onClose: () => void;
  user: any;
  accessToken: string | null;
  onLogin: () => Promise<void>;
  mimiVocalize?: (text: string) => void;
}

type ActiveSystem = "gmail" | "drive" | "chat" | "tasks" | "contacts" | "sheets";

export default function MimiGmailHub({
  isOpen,
  onClose,
  user,
  accessToken,
  onLogin,
  mimiVocalize
}: MimiGmailHubProps) {
  // Navigation Modules
  const [activeSystem, setActiveSystem] = useState<ActiveSystem>("gmail");
  
  // High-level States
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [statusNotice, setStatusNotice] = useState<{ text: string; type: "error" | "success" | "info" } | null>(null);

  // 1. Gmail Specific States
  const [messages, setMessages] = useState<GmailMessage[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeMessage, setActiveMessage] = useState<GmailMessage | null>(null);
  const [activeGmailTab, setActiveGmailTab] = useState<"inbox" | "sent" | "starred" | "compose">("inbox");
  const [composeTo, setComposeTo] = useState("");
  const [composeSubject, setComposeSubject] = useState("");
  const [composeBody, setComposeBody] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [confirmSendOpen, setConfirmSendOpen] = useState(false);
  const [confirmTrashOpen, setConfirmTrashOpen] = useState(false);
  const [tgtTrashMessage, setTgtTrashMessage] = useState<GmailMessage | null>(null);

  // 2. Drive Specific States
  const [driveFiles, setDriveFiles] = useState<DriveFile[]>([]);
  const [driveSearch, setDriveSearch] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const driveFileInputRef = useRef<HTMLInputElement>(null);
  const [confirmTrashDriveOpen, setConfirmTrashDriveOpen] = useState(false);
  const [tgtTrashDriveFile, setTgtTrashDriveFile] = useState<DriveFile | null>(null);

  // 3. Chat Specific States
  const [chatSpaces, setChatSpaces] = useState<ChatSpace[]>([]);
  const [activeSpace, setActiveSpace] = useState<ChatSpace | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const chatMessagesEndRef = useRef<HTMLDivElement>(null);
  const [isSendingChat, setIsSendingChat] = useState(false);

  // 4. Tasks Specific States
  const [taskLists, setTaskLists] = useState<GoogleTaskList[]>([]);
  const [activeTaskList, setActiveTaskList] = useState<GoogleTaskList | null>(null);
  const [tasks, setTasks] = useState<GoogleTask[]>([]);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskNotes, setNewTaskNotes] = useState("");
  const [confirmDeleteTaskOpen, setConfirmDeleteTaskOpen] = useState(false);
  const [tgtDeleteTask, setTgtDeleteTask] = useState<GoogleTask | null>(null);

  // 5. Contacts Specific States
  const [contacts, setContacts] = useState<GoogleContact[]>([]);
  const [contactSearch, setContactSearch] = useState("");
  const [showAddContact, setShowAddContact] = useState(false);
  const [newContactFirstName, setNewContactFirstName] = useState("");
  const [newContactLastName, setNewContactLastName] = useState("");
  const [newContactEmail, setNewContactEmail] = useState("");
  const [newContactPhone, setNewContactPhone] = useState("");
  const [confirmDeleteContactOpen, setConfirmDeleteContactOpen] = useState(false);
  const [tgtDeleteContact, setTgtDeleteContact] = useState<GoogleContact | null>(null);

  // 6. Google Sheets Specific States
  const [spreadsheets, setSpreadsheets] = useState<SheetInfo[]>([]);
  const [spreadsheetSearch, setSpreadsheetSearch] = useState("");
  const [activeSpreadsheet, setActiveSpreadsheet] = useState<SheetInfo | null>(null);
  const [spreadsheetDetail, setSpreadsheetDetail] = useState<SpreadsheetDetail | null>(null);
  const [activeTab, setActiveTab] = useState<string | null>(null);
  const [sheetValues, setSheetValues] = useState<string[][]>([]);
  const [loadingSheetData, setLoadingSheetData] = useState(false);
  const [showCreateSpreadsheet, setShowCreateSpreadsheet] = useState(false);
  const [newSpreadsheetTitle, setNewSpreadsheetTitle] = useState("");
  const [isCreatingSpreadsheet, setIsCreatingSpreadsheet] = useState(false);
  const [newRowInput, setNewRowInput] = useState<string>("");
  const [editingCell, setEditingCell] = useState<{ r: number; c: number; original: string; current: string } | null>(null);


  // Safe dismiss for toasts
  useEffect(() => {
    if (statusNotice) {
      const t = setTimeout(() => setStatusNotice(null), 4000);
      return () => clearTimeout(t);
    }
  }, [statusNotice]);

  // Sync current active system's initial data list
  const syncActiveSystemData = async () => {
    if (!accessToken) return;
    setLoading(true);
    setErrorMsg(null);
    try {
      if (activeSystem === "gmail") {
        await fetchEmails();
      } else if (activeSystem === "drive") {
        await fetchDriveFiles();
      } else if (activeSystem === "chat") {
        await fetchChatSpaces();
      } else if (activeSystem === "tasks") {
        await fetchTaskLists();
      } else if (activeSystem === "contacts") {
        await fetchContacts();
      } else if (activeSystem === "sheets") {
        await fetchSpreadsheets();
      }
    } catch (e: any) {
      console.error(e);
      setErrorMsg(`Synchronization failed for ${activeSystem.toUpperCase()}: ${e.message}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && accessToken) {
      syncActiveSystemData();
    }
  }, [activeSystem, isOpen, accessToken]);

  // Nested observers for active items within modules
  useEffect(() => {
    if (activeSpace && accessToken) {
      fetchChatMessages(activeSpace.name);
    }
  }, [activeSpace, accessToken]);

  useEffect(() => {
    if (activeTaskList && accessToken) {
      fetchTasks(activeTaskList.id);
    }
  }, [activeTaskList, accessToken]);

  // Auto-scroll chat window
  useEffect(() => {
    if (chatMessagesEndRef.current) {
      chatMessagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chatMessages]);

  // ==========================================
  // 1. Gmail Service Operations
  // ==========================================
  const fetchEmails = async () => {
    if (!accessToken) return;
    let finalQuery = searchQuery;
    if (activeGmailTab === "starred") {
      finalQuery = (finalQuery ? `${finalQuery} ` : "") + "is:starred";
    } else if (activeGmailTab === "sent") {
      finalQuery = (finalQuery ? `${finalQuery} ` : "") + "from:me";
    } else {
      finalQuery = (finalQuery ? `${finalQuery} ` : "") + "label:INBOX";
    }
    const emails = await getGmailInbox(accessToken, 15, finalQuery);
    setMessages(emails);
    if (emails.length > 0 && !activeMessage) {
      setActiveMessage(emails[0]);
    }
  };

  const handleSelectMessage = async (msg: GmailMessage) => {
    setActiveMessage(msg);
    if (!msg.isRead && accessToken) {
      setMessages(prev => prev.map(m => m.id === msg.id ? { ...m, isRead: true } : m));
      await markAsRead(accessToken, msg.id);
    }
  };

  const triggerSendConfirmation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!composeTo.trim()) {
      setStatusNotice({ text: "Please specify a recipient email address!", type: "error" });
      return;
    }
    if (!composeSubject.trim()) {
      setStatusNotice({ text: "Please specify a subject!", type: "error" });
      return;
    }
    if (!composeBody.trim()) {
      setStatusNotice({ text: "Please write some message body!", type: "error" });
      return;
    }
    setConfirmSendOpen(true);
  };

  const executeSendEmail = async () => {
    if (!accessToken) return;
    setIsSending(true);
    setConfirmSendOpen(false);
    try {
      const response = await sendEmail(accessToken, composeTo, composeSubject, composeBody);
      if (response.success) {
        if (mimiVocalize) {
          mimiVocalize("Mimi execution node completed. Your email has been successfully dispatched! What is your next instruction, Dada?");
        }
        setStatusNotice({ text: "Email sent successfully!", type: "success" });
        setActiveGmailTab("inbox");
        fetchEmails();
      }
    } catch (e: any) {
      console.error(e);
      setStatusNotice({ text: "Failed sending email: " + e.message, type: "error" });
    } finally {
      setIsSending(false);
    }
  };

  const executeTrashMessage = async () => {
    if (!accessToken || !tgtTrashMessage) return;
    setConfirmTrashOpen(false);
    try {
      const ok = await trashMessage(accessToken, tgtTrashMessage.id);
      if (ok) {
        setMessages(prev => prev.filter(m => m.id !== tgtTrashMessage.id));
        if (activeMessage?.id === tgtTrashMessage.id) {
          setActiveMessage(null);
        }
        setStatusNotice({ text: "Email successfully trashed!", type: "success" });
      }
    } catch (e: any) {
      console.error(e);
      setStatusNotice({ text: "Failed to delete email: " + e.message, type: "error" });
    } finally {
      setTgtTrashMessage(null);
    }
  };

  // ==========================================
  // 2. Drive Service Operations
  // ==========================================
  const fetchDriveFiles = async () => {
    if (!accessToken) return;
    const files = await listDriveFiles(accessToken, driveSearch);
    setDriveFiles(files);
  };

  const handleDriveUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !accessToken) return;
    setIsUploading(true);
    try {
      await uploadDriveFile(accessToken, file.name, file.type, file);
      setStatusNotice({ text: `"${file.name}" successfully uploaded to Google Drive!`, type: "success" });
      fetchDriveFiles();
    } catch (e: any) {
      console.error(e);
      setStatusNotice({ text: `Upload failed: ${e.message}`, type: "error" });
    } finally {
      setIsUploading(false);
      if (driveFileInputRef.current) driveFileInputRef.current.value = "";
    }
  };

  const executeDeleteDriveFile = async () => {
    if (!accessToken || !tgtTrashDriveFile) return;
    setConfirmTrashDriveOpen(false);
    try {
      await deleteDriveFile(accessToken, tgtTrashDriveFile.id);
      setDriveFiles(prev => prev.filter(f => f.id !== tgtTrashDriveFile.id));
      setStatusNotice({ text: `"${tgtTrashDriveFile.name}" deleted from Google Drive.`, type: "success" });
    } catch (e: any) {
      console.error(e);
      setStatusNotice({ text: `Failed to delete file: ${e.message}`, type: "error" });
    } finally {
      setTgtTrashDriveFile(null);
    }
  };

  // ==========================================
  // 3. Chat Service Operations
  // ==========================================
  const fetchChatSpaces = async () => {
    if (!accessToken) return;
    const spaces = await listChatSpaces(accessToken);
    setChatSpaces(spaces);
    if (spaces.length > 0 && !activeSpace) {
      setActiveSpace(spaces[0]);
    }
  };

  const fetchChatMessages = async (spaceName: string) => {
    if (!accessToken) return;
    const msgs = await listChatMessages(accessToken, spaceName);
    setChatMessages(msgs);
  };

  const handleSendChatMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !activeSpace || !accessToken) return;
    const msg = chatInput;
    setChatInput("");
    setIsSendingChat(true);
    try {
      await sendChatMessage(accessToken, activeSpace.name, msg);
      await fetchChatMessages(activeSpace.name);
    } catch (e: any) {
      console.error(e);
      setStatusNotice({ text: `Failed to dispatch Chat message: ${e.message}`, type: "error" });
    } finally {
      setIsSendingChat(false);
    }
  };

  // ==========================================
  // 4. Tasks Service Operations
  // ==========================================
  const fetchTaskLists = async () => {
    if (!accessToken) return;
    const lists = await listTaskLists(accessToken);
    setTaskLists(lists);
    if (lists.length > 0 && !activeTaskList) {
      setActiveTaskList(lists[0]);
    }
  };

  const fetchTasks = async (listId: string) => {
    if (!accessToken) return;
    const items = await listTasks(accessToken, listId);
    setTasks(items);
  };

  const handleToggleTaskStatus = async (task: GoogleTask) => {
    if (!activeTaskList || !accessToken) return;
    const nextStatus = task.status === "completed" ? "needsAction" : "completed";
    
    // Optimistic toggle
    setTasks(prev => prev.map(t => t.id === task.id ? { ...t, status: nextStatus } : t));
    
    try {
      await updateGoogleTask(accessToken, activeTaskList.id, task.id, { status: nextStatus });
      fetchTasks(activeTaskList.id);
    } catch (e: any) {
      console.error(e);
      setStatusNotice({ text: "Failed to update Google Task status.", type: "error" });
    }
  };

  const handleCreateTaskSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim() || !activeTaskList || !accessToken) return;
    const tTitle = newTaskTitle;
    const tNotes = newTaskNotes;
    setNewTaskTitle("");
    setNewTaskNotes("");
    try {
      await createGoogleTask(accessToken, activeTaskList.id, { title: tTitle, notes: tNotes });
      setStatusNotice({ text: "New Workspace Task synced!", type: "success" });
      fetchTasks(activeTaskList.id);
    } catch (e: any) {
      console.error(e);
      setStatusNotice({ text: `Failed to create task: ${e.message}`, type: "error" });
    }
  };

  const executeDeleteTask = async () => {
    if (!accessToken || !activeTaskList || !tgtDeleteTask) return;
    setConfirmDeleteTaskOpen(false);
    try {
      await deleteGoogleTask(accessToken, activeTaskList.id, tgtDeleteTask.id);
      setTasks(prev => prev.filter(t => t.id !== tgtDeleteTask.id));
      setStatusNotice({ text: "Task deleted successfully.", type: "success" });
    } catch (e: any) {
      console.error(e);
      setStatusNotice({ text: `Failed to delete task: ${e.message}`, type: "error" });
    } finally {
      setTgtDeleteTask(null);
    }
  };

  // ==========================================
  // 5. Contacts Service Operations
  // ==========================================
  const fetchContacts = async () => {
    if (!accessToken) return;
    const items = await listGoogleContacts(accessToken);
    setContacts(items);
  };

  const handleCreateContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContactFirstName.trim() || !accessToken) return;
    try {
      await createGoogleContact(accessToken, {
        givenName: newContactFirstName,
        familyName: newContactLastName,
        email: newContactEmail,
        phone: newContactPhone
      });
      setStatusNotice({ text: `Contact "${newContactFirstName}" added successfully!`, type: "success" });
      setShowAddContact(false);
      setNewContactFirstName("");
      setNewContactLastName("");
      setNewContactEmail("");
      setNewContactPhone("");
      fetchContacts();
    } catch (e: any) {
      console.error(e);
      setStatusNotice({ text: `Failed to save contact: ${e.message}`, type: "error" });
    }
  };

  const executeDeleteContact = async () => {
    if (!accessToken || !tgtDeleteContact) return;
    setConfirmDeleteContactOpen(false);
    try {
      await deleteGoogleContact(accessToken, tgtDeleteContact.resourceName);
      setContacts(prev => prev.filter(c => c.resourceName !== tgtDeleteContact.resourceName));
      setStatusNotice({ text: `Contact "${tgtDeleteContact.name}" deleted.`, type: "success" });
    } catch (e: any) {
      console.error(e);
      setStatusNotice({ text: `Failed to delete contact: ${e.message}`, type: "error" });
    } finally {
      setTgtDeleteContact(null);
    }
  };

  // ==========================================
  // 6. Google Sheets Service Operations
  // ==========================================
  const fetchSpreadsheets = async () => {
    if (!accessToken) return;
    try {
      const list = await listSpreadsheets(accessToken, spreadsheetSearch);
      setSpreadsheets(list);
    } catch (err: any) {
      console.error(err);
      setStatusNotice({ text: `Failed to fetch spreadsheets: ${err.message}`, type: "error" });
    }
  };

  const handleSelectSpreadsheet = async (sheet: SheetInfo) => {
    if (!accessToken) return;
    setActiveSpreadsheet(sheet);
    setSpreadsheetDetail(null);
    setSheetValues([]);
    setActiveTab(null);
    setLoadingSheetData(true);
    try {
      const detail = await getSpreadsheetDetails(accessToken, sheet.id);
      setSpreadsheetDetail(detail);
      if (detail.sheets.length > 0) {
        const firstTab = detail.sheets[0].title;
        setActiveTab(firstTab);
        await loadSheetTabValues(sheet.id, firstTab);
      }
    } catch (err: any) {
      console.error(err);
      setStatusNotice({ text: `Failed to load sheets: ${err.message}`, type: "error" });
    } finally {
      setLoadingSheetData(false);
    }
  };

  const loadSheetTabValues = async (sheetId: string, tabTitle: string) => {
    if (!accessToken) return;
    setLoadingSheetData(true);
    try {
      const vals = await getSheetValues(accessToken, sheetId, `${tabTitle}!A1:Z50`);
      setSheetValues(vals);
    } catch (err: any) {
      console.error(err);
      setStatusNotice({ text: `Failed to load values: ${err.message}`, type: "error" });
    } finally {
      setLoadingSheetData(false);
    }
  };

  const handleTabChange = async (tabTitle: string) => {
    if (!activeSpreadsheet) return;
    setActiveTab(tabTitle);
    await loadSheetTabValues(activeSpreadsheet.id, tabTitle);
  };

  const handleCreateNewSpreadsheet = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessToken || !newSpreadsheetTitle.trim() || isCreatingSpreadsheet) return;
    setIsCreatingSpreadsheet(true);
    try {
      const newSheet = await createSpreadsheet(accessToken, newSpreadsheetTitle.trim());
      setStatusNotice({ text: `Spreadsheet "${newSpreadsheetTitle}" created successfully`, type: "success" });
      setNewSpreadsheetTitle("");
      setShowCreateSpreadsheet(false);
      await fetchSpreadsheets();
      await handleSelectSpreadsheet(newSheet);
    } catch (err: any) {
      console.error(err);
      setStatusNotice({ text: `Failed to create sheet: ${err.message}`, type: "error" });
    } finally {
      setIsCreatingSpreadsheet(false);
    }
  };

  const handleAppendRow = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessToken || !activeSpreadsheet || !activeTab || !newRowInput.trim()) return;
    
    // Parse comma separated values into spreadsheet row
    const rowValues = newRowInput.split(",").map(val => val.trim());
    try {
      await appendSheetRow(accessToken, activeSpreadsheet.id, `${activeTab}!A1`, [rowValues]);
      setStatusNotice({ text: "Row appended successfully", type: "success" });
      setNewRowInput("");
      await loadSheetTabValues(activeSpreadsheet.id, activeTab);
    } catch (err: any) {
      console.error(err);
      setStatusNotice({ text: `Failed to append row: ${err.message}`, type: "error" });
    }
  };

  const handleCellClick = (rIdx: number, cIdx: number, val: string) => {
    setEditingCell({
      r: rIdx,
      c: cIdx,
      original: val,
      current: val
    });
  };

  const handleSaveCellEdit = async () => {
    if (!accessToken || !activeSpreadsheet || !activeTab || !editingCell) return;
    const { r, c, original, current } = editingCell;
    if (original === current) {
      setEditingCell(null);
      return;
    }
    
    const colLetter = String.fromCharCode(65 + c);
    const rowNum = r + 1;
    const cellRange = `${activeTab}!${colLetter}${rowNum}`;

    try {
      await updateSheetValues(accessToken, activeSpreadsheet.id, cellRange, [[current]]);
      setStatusNotice({ text: `Cell updated to "${current}"`, type: "success" });
      
      const newValues = [...sheetValues];
      while (newValues.length <= r) {
        newValues.push([]);
      }
      while (newValues[r].length <= c) {
        newValues[r].push("");
      }
      newValues[r][c] = current;
      setSheetValues(newValues);
    } catch (err: any) {
      console.error(err);
      setStatusNotice({ text: `Failed to update cell: ${err.message}`, type: "error" });
    } finally {
      setEditingCell(null);
    }
  };

  useEffect(() => {
    if (activeSystem === "sheets" && accessToken) {
      fetchSpreadsheets();
    }
  }, [spreadsheetSearch, activeSystem, accessToken]);


  // Helper file icons
  const getFileIcon = (mime: string) => {
    if (mime.includes("image")) return <FileImage size={18} className="text-pink-400" />;
    if (mime.includes("json") || mime.includes("javascript") || mime.includes("html") || mime.includes("css")) {
      return <FileCode size={18} className="text-green-400" />;
    }
    return <FileText size={18} className="text-blue-400" />;
  };

  const formatFileSize = (bytes?: string) => {
    if (!bytes) return "N/A";
    const num = parseInt(bytes, 10);
    if (isNaN(num)) return "N/A";
    if (num < 1024) return `${num} B`;
    if (num < 1024 * 1024) return `${(num / 1024).toFixed(1)} KB`;
    return `${(num / (1024 * 1024)).toFixed(1)} MB`;
  };

  const filteredContacts = contacts.filter(c => 
    c.name?.toLowerCase().includes(contactSearch.toLowerCase()) ||
    c.email?.toLowerCase().includes(contactSearch.toLowerCase()) ||
    c.phone?.toLowerCase().includes(contactSearch.toLowerCase())
  );

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl pointer-events-auto"
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              className="relative w-full max-w-6xl h-[90vh] md:h-[84vh] bg-[#09090b] border border-white/10 rounded-[2rem] overflow-hidden shadow-2xl flex flex-col font-sans text-white"
            >
              
              {/* Core Suite Header */}
              <div className="flex items-center justify-between px-8 py-5 border-b border-white/5 bg-white/[0.01]">
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
                    <ShieldCheck size={20} />
                  </div>
                  <div>
                    <h2 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2">
                      Mimi Workspace Suite
                      <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 font-mono tracking-normal border border-indigo-500/20 flex items-center gap-1">
                        <ShieldCheck size={11} /> Unified Gateway
                      </span>
                    </h2>
                    <p className="text-[10px] text-white/40">Secure, offline-hardend Google Sandbox synchronization panel</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  {accessToken && (
                    <button
                      onClick={syncActiveSystemData}
                      disabled={loading}
                      className="p-2.5 rounded-full bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-all border border-white/5 disabled:opacity-50 cursor-pointer"
                      title="Force Synchronize with Workspace"
                    >
                      <RefreshCw size={15} className={loading ? "animate-spin" : ""} />
                    </button>
                  )}
                  <button
                    onClick={onClose}
                    className="p-2.5 rounded-full bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-all border border-white/10 cursor-pointer"
                  >
                    <X size={15} />
                  </button>
                </div>
              </div>

              {/* Login Block / Unified Auth Screen */}
              {!accessToken ? (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-8 bg-black/40">
                  <div className="max-w-md space-y-6">
                    <div className="mx-auto w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-indigo-400 shadow-xl">
                      <Bot size={34} />
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-lg font-bold">Connect Your Workspace Account</h3>
                      <p className="text-xs text-white/50 leading-relaxed max-w-sm mx-auto">
                        To browse files, answer chats, track checklists, or send emails, authorize Mimi with sandbox access.
                      </p>
                    </div>

                    <div className="pt-2 flex justify-center">
                      <button 
                        onClick={onLogin}
                        className="gsi-material-button cursor-pointer"
                        style={{
                          background: "white",
                          border: "1px solid #dadce0",
                          borderRadius: "4px",
                          boxSizing: "border-box",
                          color: "#3c4043",
                          fontFamily: "Roboto, arial, sans-serif",
                          fontSize: "14px",
                          height: "40px",
                          letterSpacing: "0.21px",
                          padding: "0 12px",
                          position: "relative",
                          textAlign: "center",
                          verticalAlign: "middle",
                          whiteSpace: "nowrap",
                          width: "auto"
                        }}
                      >
                        <div className="gsi-material-button-state" style={{ borderRadius: "4px" }}></div>
                        <div className="gsi-material-button-content-wrapper" style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
                          <div className="gsi-material-button-icon" style={{ display: "block", marginRight: "12px", width: "18px", height: "18px" }}>
                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" style={{ display: "block" }}>
                              <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                              <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                              <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                              <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                            </svg>
                          </div>
                          <span className="gsi-material-button-contents" style={{ fontWeight: 500 }}>Authorize Workspace</span>
                        </div>
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
                  
                  {/* Far-Left Mini-Sidebar Suite Controller */}
                  <div className="w-full md:w-16 bg-[#0c0c0e]/95 border-r border-white/5 flex flex-row md:flex-col items-center justify-between md:justify-start p-3 md:py-6 gap-3 md:gap-5 shrink-0 overflow-x-auto md:overflow-x-visible">
                    
                    <div className="flex flex-row md:flex-col gap-2.5 md:gap-4 w-full items-center">
                      <button
                        onClick={() => setActiveSystem("gmail")}
                        className={`p-3 rounded-2xl border transition-all relative group cursor-pointer ${
                          activeSystem === "gmail" 
                            ? "bg-red-500/10 border-red-500/30 text-red-400" 
                            : "bg-white/5 border-white/[0.03] text-white/50 hover:bg-white/10"
                        }`}
                        title="Google Mail (Gmail)"
                      >
                        <Mail size={18} />
                      </button>

                      <button
                        onClick={() => setActiveSystem("drive")}
                        className={`p-3 rounded-2xl border transition-all relative group cursor-pointer ${
                          activeSystem === "drive" 
                            ? "bg-yellow-500/10 border-yellow-500/30 text-yellow-500" 
                            : "bg-white/5 border-white/[0.03] text-white/50 hover:bg-white/10"
                        }`}
                        title="Google Drive"
                      >
                        <HardDrive size={18} />
                      </button>

                      <button
                        onClick={() => setActiveSystem("chat")}
                        className={`p-3 rounded-2xl border transition-all relative group cursor-pointer ${
                          activeSystem === "chat" 
                            ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400" 
                            : "bg-white/5 border-white/[0.03] text-white/50 hover:bg-white/10"
                        }`}
                        title="Google Chat API"
                      >
                        <MessageSquare size={18} />
                      </button>

                      <button
                        onClick={() => setActiveSystem("tasks")}
                        className={`p-3 rounded-2xl border transition-all relative group cursor-pointer ${
                          activeSystem === "tasks" 
                            ? "bg-blue-500/10 border-blue-500/30 text-blue-400" 
                            : "bg-white/5 border-white/[0.03] text-white/50 hover:bg-white/10"
                        }`}
                        title="Google Tasks"
                      >
                        <CheckSquare size={18} />
                      </button>

                      <button
                        onClick={() => setActiveSystem("contacts")}
                        className={`p-3 rounded-2xl border transition-all relative group cursor-pointer ${
                          activeSystem === "contacts" 
                            ? "bg-purple-500/10 border-purple-500/30 text-purple-400" 
                            : "bg-white/5 border-white/[0.03] text-white/50 hover:bg-white/10"
                        }`}
                        title="Google Contacts"
                      >
                        <Users size={18} />
                      </button>

                      <button
                        onClick={() => setActiveSystem("sheets")}
                        className={`p-3 rounded-2xl border transition-all relative group cursor-pointer ${
                          activeSystem === "sheets" 
                            ? "bg-emerald-600/15 border-emerald-500/30 text-emerald-400" 
                            : "bg-white/5 border-white/[0.03] text-white/50 hover:bg-white/10"
                        }`}
                        title="Google Sheets"
                      >
                        <FileSpreadsheet size={18} />
                      </button>
                    </div>

                    <div className="hidden md:block mt-auto text-[9px] font-mono text-white/25">MIMI v2</div>
                  </div>

                  {/* =======================================================
                      MODULE 1: GOOGLE MAIL (GMAIL) VIEW
                      ======================================================= */}
                  {activeSystem === "gmail" && (
                    <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
                      
                      {/* Folder sidebar */}
                      <div className="w-full md:w-48 bg-black/20 border-r border-white/5 flex flex-col p-4 shrink-0 justify-between">
                        <div className="space-y-1">
                          <button
                            onClick={() => { setActiveGmailTab("inbox"); setActiveMessage(null); }}
                            className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                              activeGmailTab === "inbox" ? "bg-red-500/10 text-red-400 border border-red-500/20" : "text-white/60 hover:bg-white/5"
                            }`}
                          >
                            <Inbox size={14} /> Inbox
                          </button>
                          
                          <button
                            onClick={() => { setActiveGmailTab("starred"); setActiveMessage(null); }}
                            className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                              activeGmailTab === "starred" ? "bg-red-500/10 text-red-400 border border-red-500/20" : "text-white/60 hover:bg-white/5"
                            }`}
                          >
                            <Star size={14} /> Starred
                          </button>

                          <button
                            onClick={() => { setActiveGmailTab("sent"); setActiveMessage(null); }}
                            className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                              activeGmailTab === "sent" ? "bg-red-500/10 text-red-400 border border-red-500/20" : "text-white/60 hover:bg-white/5"
                            }`}
                          >
                            <SentIcon size={14} /> Sent
                          </button>

                          <div className="h-px bg-white/5 my-3" />

                          <button
                            onClick={() => { setActiveGmailTab("compose"); }}
                            className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-xs font-bold bg-gradient-to-tr from-red-500 to-orange-500 text-white shadow-lg shadow-red-500/10 transition-all hover:scale-[1.02] cursor-pointer"
                          >
                            <Edit3 size={14} /> Compose
                          </button>
                        </div>
                        
                        <div className="p-2 border border-white/5 bg-white/[0.01] rounded-xl text-[10px] text-white/40">
                          ID: <span className="font-mono text-white/50">{user?.email || "sandbox_usr"}</span>
                        </div>
                      </div>

                      {/* Content panel */}
                      {activeGmailTab === "compose" ? (
                        <div className="flex-1 p-6 md:p-8 overflow-y-auto bg-black/35">
                          <div className="max-w-2xl mx-auto space-y-5">
                            <h3 className="text-sm font-bold uppercase tracking-wider text-red-400">Initialize Email Node Dispatch</h3>
                            <form onSubmit={triggerSendConfirmation} className="space-y-4">
                              <div className="space-y-1.5">
                                <label className="text-[10px] font-mono text-white/40 uppercase">Recipient Account (To)</label>
                                <input 
                                  type="email" 
                                  value={composeTo} 
                                  onChange={(e) => setComposeTo(e.target.value)}
                                  className="w-full bg-white/[0.02] border border-white/10 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-red-500/50"
                                  placeholder="target-recipient@example.com"
                                />
                              </div>
                              <div className="space-y-1.5">
                                <label className="text-[10px] font-mono text-white/40 uppercase">Subject Topic</label>
                                <input 
                                  type="text" 
                                  value={composeSubject} 
                                  onChange={(e) => setComposeSubject(e.target.value)}
                                  className="w-full bg-white/[0.02] border border-white/10 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-red-500/50"
                                  placeholder="Enter transmission subject..."
                                />
                              </div>
                              <div className="space-y-1.5">
                                <label className="text-[10px] font-mono text-white/40 uppercase">Message Payload</label>
                                <textarea 
                                  value={composeBody} 
                                  onChange={(e) => setComposeBody(e.target.value)}
                                  rows={8}
                                  className="w-full bg-white/[0.02] border border-white/10 rounded-2xl p-4 text-xs text-white focus:outline-none focus:border-red-500/50 resize-none leading-relaxed"
                                  placeholder="Write secure body payload..."
                                />
                              </div>
                              <div className="flex justify-end">
                                <button
                                  type="submit"
                                  disabled={isSending}
                                  className="px-6 py-3 rounded-xl bg-gradient-to-tr from-red-500 to-orange-500 text-xs font-bold shadow-lg shadow-red-500/25 flex items-center gap-2 hover:scale-[1.02] cursor-pointer disabled:opacity-50"
                                >
                                  {isSending ? <RefreshCw className="animate-spin" size={13} /> : <Send size={13} />} Dispatch Node
                                </button>
                              </div>
                            </form>
                          </div>
                        </div>
                      ) : (
                        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
                          
                          {/* Messages list column */}
                          <div className="w-full md:w-80 border-r border-white/5 flex flex-col">
                            <div className="p-4 border-b border-white/5 bg-white/[0.01]">
                              <div className="relative">
                                <input
                                  type="text"
                                  value={searchQuery}
                                  onChange={(e) => setSearchQuery(e.target.value)}
                                  placeholder="Search incoming streams..."
                                  className="w-full bg-white/[0.02] border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white focus:outline-none focus:border-red-500/40"
                                />
                                <Search size={13} className="absolute left-3.5 top-3.5 text-white/40" />
                              </div>
                            </div>

                            <div className="flex-1 overflow-y-auto divide-y divide-white/5">
                              {loading ? (
                                <div className="p-8 text-center flex justify-center items-center">
                                  <Loader2 className="text-white/30" size={18} />
                                </div>
                              ) : messages.length === 0 ? (
                                <div className="p-8 text-center text-xs text-white/40 h-full flex flex-col justify-center">
                                  No records archived.
                                </div>
                              ) : (
                                messages.map((msg) => (
                                  <div
                                    key={msg.id}
                                    onClick={() => handleSelectMessage(msg)}
                                    className={`p-4 text-left transition-all cursor-pointer relative ${
                                      activeMessage?.id === msg.id ? "bg-white/[0.04]" : "hover:bg-white/[0.01]"
                                    }`}
                                  >
                                    {!msg.isRead && (
                                      <div className="absolute left-1.5 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-red-500" />
                                    )}
                                    <div className="flex justify-between items-start gap-1 pb-1">
                                      <span className="text-xs font-black truncate text-white/90 max-w-[150px]">{msg.from.split('<')[0] || msg.from}</span>
                                      <span className="text-[9px] font-mono text-white/30 shrink-0">{msg.date.split(',')[1]?.split(' ')[1] || msg.date}</span>
                                    </div>
                                    <h4 className="text-[11px] font-bold text-white/70 truncate pb-0.5">{msg.subject || "No Subject"}</h4>
                                    <p className="text-[10px] text-white/40 line-clamp-1">{msg.snippet}</p>
                                    
                                    <div className="flex justify-end gap-1.5 mt-2 opacity-0 hover:opacity-100 transition-opacity absolute right-4 bottom-3">
                                      <button
                                        onClick={(e) => { e.stopPropagation(); setTgtTrashMessage(msg); setConfirmTrashOpen(true); }}
                                        className="p-1.5 rounded-md bg-red-500/15 text-red-400 border border-red-500/20 hover:bg-red-500 hover:text-white transition-all cursor-pointer"
                                        title="Trash email item"
                                      >
                                        <Trash2 size={11} />
                                      </button>
                                    </div>
                                  </div>
                                ))
                              )}
                            </div>
                          </div>

                          {/* Reader viewport */}
                          <div className="flex-1 flex flex-col bg-black/55 p-6 md:p-8 overflow-y-auto">
                            {activeMessage ? (
                              <div className="flex-1 flex flex-col justify-between gap-6">
                                <div className="space-y-6">
                                  <div className="flex items-start justify-between border-b border-white/5 pb-4">
                                    <div className="min-w-0 flex-1 space-y-1.5">
                                      <h3 className="text-base font-bold text-white tracking-tight break-words pr-4">
                                        {activeMessage.subject}
                                      </h3>
                                      <div className="text-[11px] space-y-0.5 text-white/50">
                                        <p><strong className="text-white/30 font-mono">FROM:</strong> {activeMessage.from}</p>
                                        <p><strong className="text-white/30 font-mono">DATE:</strong> {activeMessage.date}</p>
                                      </div>
                                    </div>
                                  </div>

                                  <div className="text-xs text-white/80 leading-relaxed font-sans whitespace-pre-wrap break-words border border-white/5 p-5 rounded-2xl bg-white/[0.01]">
                                    {activeMessage.body || activeMessage.snippet}
                                  </div>
                                </div>
                              </div>
                            ) : (
                              <div className="flex-1 flex flex-col items-center justify-center text-center p-6">
                                <Mail size={40} className="text-white/10 mb-3" />
                                <span className="text-xs font-bold text-white/50">No Email Loaded</span>
                                <p className="text-[10px] text-white/30 max-w-xs mt-1">Select an incoming email to view the record in this security viewport.</p>
                              </div>
                            )}
                          </div>

                        </div>
                      )}

                    </div>
                  )}

                  {/* =======================================================
                      MODULE 2: GOOGLE DRIVE VIEW
                      ======================================================= */}
                  {activeSystem === "drive" && (
                    <div className="flex-1 flex flex-col overflow-hidden">
                      <div className="p-5 border-b border-white/5 bg-white/[0.01] flex flex-wrap items-center justify-between gap-4">
                        <div className="flex items-center gap-3 w-full sm:w-auto">
                          <div className="relative w-full sm:w-64">
                            <input
                              type="text"
                              value={driveSearch}
                              onChange={(e) => setDriveSearch(e.target.value)}
                              placeholder="Search Drive files..."
                              className="w-full bg-white/[0.02] border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white focus:outline-none focus:border-yellow-500/40"
                            />
                            <Search size={13} className="absolute left-3.5 top-3.5 text-white/40" />
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <input 
                            type="file" 
                            ref={driveFileInputRef}
                            onChange={handleDriveUpload}
                            className="hidden"
                          />
                          <button
                            onClick={() => driveFileInputRef.current?.click()}
                            disabled={isUploading}
                            className="px-4 py-2 bg-gradient-to-tr from-yellow-500 to-amber-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-yellow-500/10 flex items-center gap-2 hover:scale-[1.02] cursor-pointer disabled:opacity-50"
                          >
                            {isUploading ? <Loader2 size={13} /> : <Upload size={13} />}
                            Upload New File
                          </button>
                        </div>
                      </div>

                      <div className="flex-1 overflow-y-auto p-6 md:p-8">
                        {loading && driveFiles.length === 0 ? (
                          <div className="flex h-full items-center justify-center">
                            <Loader2 className="text-white/30" size={24} />
                          </div>
                        ) : driveFiles.length === 0 ? (
                          <div className="flex flex-col h-full items-center justify-center text-center">
                            <HardDrive size={42} className="text-white/10 mb-3 animate-pulse" />
                            <h4 className="text-xs font-bold text-white/60">No Google Drive Records</h4>
                            <p className="text-[10px] text-white/30 max-w-sm mt-1">Deploy folders or upload local assets directly into Google Cloud storage.</p>
                          </div>
                        ) : (
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {driveFiles.map((file) => (
                              <div 
                                key={file.id}
                                className="border border-white/5 bg-white/[0.01] rounded-2xl p-4 flex flex-col justify-between hover:bg-white/[0.04] transition-all group"
                              >
                                <div className="flex items-start gap-3">
                                  <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 shrink-0">
                                    {getFileIcon(file.mimeType)}
                                  </div>
                                  <div className="min-w-0 flex-1">
                                    <h4 className="text-xs font-bold text-white truncate group-hover:text-yellow-400 transition-colors" title={file.name}>
                                      {file.name}
                                    </h4>
                                    <p className="text-[9px] text-white/30 font-mono mt-0.5 truncate">{file.mimeType}</p>
                                    <div className="flex items-center gap-2 mt-2 text-[9px] text-white/40 font-mono">
                                      <span>{formatFileSize(file.size)}</span>
                                      <span>•</span>
                                      <span>{new Date(file.modifiedTime).toLocaleDateString()}</span>
                                    </div>
                                  </div>
                                </div>

                                <div className="flex items-center justify-end gap-1.5 border-t border-white/5 mt-4 pt-3.5">
                                  {file.webViewLink && (
                                    <a 
                                      href={file.webViewLink} 
                                      target="_blank" 
                                      rel="noreferrer"
                                      className="p-1 px-3.5 bg-white/5 hover:bg-white/10 text-white/70 hover:text-white border border-white/10 rounded-lg text-[10px] font-semibold flex items-center gap-1.5 transition-all"
                                    >
                                      <Eye size={12} /> View
                                    </a>
                                  )}
                                  <button
                                    onClick={() => { setTgtTrashDriveFile(file); setConfirmTrashDriveOpen(true); }}
                                    className="p-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/15 hover:border-red-500/30 transition-all cursor-pointer"
                                    title="Delete file"
                                  >
                                    <Trash2 size={12} />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* =======================================================
                      MODULE 3: GOOGLE CHAT MODULE
                      ======================================================= */}
                  {activeSystem === "chat" && (
                    <div className="flex-1 flex flex-col md:flex-row overflow-hidden bg-black/5 flex-col-reverse md:flex-row">
                      
                      {/* Left Column: Spaces / DMs list */}
                      <div className="w-full md:w-60 border-r border-white/5 flex flex-col bg-black/15 shrink-0">
                        <div className="p-4 border-b border-white/5 bg-white/[0.01]">
                          <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-emerald-400 font-bold block">Active Chat Channels</span>
                        </div>
                        <div className="flex-1 overflow-y-auto divide-y divide-white/[0.02]">
                          {chatSpaces.length === 0 ? (
                            <div className="p-8 text-center text-xs text-white/30">
                              No spaces found. Ensure your workspace project supports Chat API.
                            </div>
                          ) : (
                            chatSpaces.map((space) => (
                              <button
                                key={space.name}
                                onClick={() => setActiveSpace(space)}
                                className={`w-full text-left p-4 flex flex-col gap-1 transition-all border-l-2 cursor-pointer ${
                                  activeSpace?.name === space.name 
                                    ? "bg-emerald-500/5 border-emerald-500 text-emerald-400" 
                                    : "border-transparent text-white/60 hover:bg-white/5"
                                }`}
                              >
                                <span className="text-xs font-bold truncate">
                                  {space.displayName || space.name.split("/")[1]}
                                </span>
                                <span className="text-[9px] font-mono text-white/30 uppercase shrink-0">
                                  {space.spaceType || "SPACE"}
                                </span>
                              </button>
                            ))
                          )}
                        </div>
                      </div>

                      {/* Right Column: Chat messages room */}
                      <div className="flex-1 flex flex-col overflow-hidden bg-black/30">
                        {activeSpace ? (
                          <>
                            {/* Room Header */}
                            <div className="p-4 bg-white/[0.01] border-b border-white/5 flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <MessageSquare size={16} className="text-emerald-400" />
                                <h3 className="text-xs font-black text-white uppercase">
                                  {activeSpace.displayName || activeSpace.name.split("/")[1]}
                                </h3>
                              </div>
                              <span className="text-[9px] font-mono text-white/30">API TARGET: {activeSpace.name}</span>
                            </div>

                            {/* Chat messages viewer */}
                            <div className="flex-1 overflow-y-auto p-6 space-y-4 flex flex-col">
                              {chatMessages.length === 0 ? (
                                <div className="flex-1 flex flex-col items-center justify-center text-center opacity-40">
                                  <MessageSquare size={32} className="mb-2" />
                                  <p className="text-xs">Beginning of secure transmission channel feed.</p>
                                </div>
                              ) : (
                                chatMessages.map((msg) => (
                                  <div 
                                    key={msg.name}
                                    className={`flex gap-3.5 max-w-[85%] ${
                                      msg.sender.name.includes("me") || msg.sender.displayName?.includes(user?.displayName || "Kaushik")
                                        ? "ml-auto flex-row-reverse" 
                                        : "mr-auto"
                                    }`}
                                  >
                                    <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 text-white flex items-center justify-center shrink-0 overflow-hidden text-[10px] font-bold">
                                      {msg.sender.avatarUrl ? (
                                        <img src={msg.sender.avatarUrl} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                      ) : (
                                        msg.sender.displayName?.charAt(0) || "U"
                                      )}
                                    </div>
                                    <div>
                                      <div className={`flex items-center gap-2 pb-1 ${msg.sender.name.includes("me") || msg.sender.displayName?.includes(user?.displayName || "Kaushik") ? "flex-row-reverse" : ""}`}>
                                        <span className="text-[10px] font-bold text-white/70">{msg.sender.displayName}</span>
                                        <span className="text-[8px] font-mono text-white/25">
                                          {new Date(msg.createTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                        </span>
                                      </div>
                                      <div className={`p-3.5 rounded-2xl text-xs leading-relaxed ${
                                        msg.sender.name.includes("me") || msg.sender.displayName?.includes(user?.displayName || "Kaushik")
                                          ? "bg-gradient-to-tr from-emerald-600 to-teal-600 text-white rounded-tr-none" 
                                          : "bg-white/[0.04] border border-white/5 text-white/85 rounded-tl-none"
                                      }`}>
                                        {msg.text}
                                      </div>
                                    </div>
                                  </div>
                                ))
                              )}
                              <div ref={chatMessagesEndRef} />
                            </div>

                            {/* Chat reply submission */}
                            <form onSubmit={handleSendChatMessage} className="p-4 bg-[#0e0e11] border-t border-white/5 flex gap-2">
                              <input 
                                type="text"
                                value={chatInput}
                                onChange={(e) => setChatInput(e.target.value)}
                                placeholder="Write transmission chat message..."
                                className="flex-1 bg-white/[0.02] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500/40"
                              />
                              <button
                                type="submit"
                                disabled={isSendingChat || !chatInput.trim()}
                                className="px-5 py-2.5 bg-gradient-to-tr from-emerald-500 to-teal-500 text-white rounded-xl text-xs font-bold shadow-lg flex items-center justify-center gap-1 cursor-pointer disabled:opacity-40"
                              >
                                Send <Send size={11} />
                              </button>
                            </form>
                          </>
                        ) : (
                          <div className="flex-1 flex flex-col items-center justify-center text-center p-6 h-full">
                            <MessageSquare size={40} className="text-white/10 mb-2" />
                            <p className="text-xs text-white/40 font-bold">No Chat Space Selected</p>
                          </div>
                        )}
                      </div>

                    </div>
                  )}

                  {/* =======================================================
                      MODULE 4: GOOGLE TASKS VIEW
                      ======================================================= */}
                  {activeSystem === "tasks" && (
                    <div className="flex-1 flex flex-col md:flex-row overflow-hidden bg-black/5">
                      
                      {/* Left Column: Task lists folder selectors */}
                      <div className="w-full md:w-52 border-r border-white/5 flex flex-col bg-black/15 shrink-0">
                        <div className="p-4 border-b border-white/5 bg-white/[0.01]">
                          <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-blue-400 font-bold block">Lists & Lists</span>
                        </div>
                        <div className="flex-1 overflow-y-auto divide-y divide-white/[0.02]">
                          {taskLists.length === 0 ? (
                            <div className="p-8 text-center text-xs text-white/30">
                              No lists.
                            </div>
                          ) : (
                            taskLists.map((lst) => (
                              <button
                                key={lst.id}
                                onClick={() => setActiveTaskList(lst)}
                                className={`w-full text-left p-3.5 flex flex-col gap-1 transition-all cursor-pointer ${
                                  activeTaskList?.id === lst.id 
                                    ? "bg-blue-500/5 border-l-2 border-blue-500 text-blue-400" 
                                    : "text-white/60 hover:bg-white/5 border-l-2 border-transparent"
                                }`}
                              >
                                <span className="text-xs font-bold truncate">{lst.title}</span>
                              </button>
                            ))
                          )}
                        </div>
                      </div>

                      {/* Right Column: Active Task Items list */}
                      <div className="flex-1 flex flex-col overflow-hidden bg-black/30 p-6 md:p-8">
                        {activeTaskList ? (
                          <div className="flex-1 flex flex-col overflow-hidden justify-between">
                            
                            <div className="space-y-4 overflow-hidden flex flex-col flex-1">
                              <div className="flex items-center justify-between border-b border-white/5 pb-3 shrink-0">
                                <h3 className="text-xs font-black uppercase text-blue-400">{activeTaskList.title}</h3>
                                <span className="text-[10px] font-mono text-white/40">{tasks.length} Active Records</span>
                              </div>

                              {/* Actions task items list scrolling viewport */}
                              <div className="flex-1 overflow-y-auto space-y-2.5">
                                {tasks.length === 0 ? (
                                  <div className="p-8 text-center text-xs text-white/30">
                                    Checklist is empty. Add a task node below!
                                  </div>
                                ) : (
                                  tasks.map((task) => (
                                    <div 
                                      key={task.id}
                                      className="flex items-center justify-between p-3.5 bg-white/[0.01] border border-white/5 rounded-xl hover:bg-white/[0.03] transition-all group"
                                    >
                                      <div className="flex items-start gap-3 min-w-0 flex-1">
                                        <button 
                                          onClick={() => handleToggleTaskStatus(task)}
                                          className="mt-0.5 outline-none focus:outline-none cursor-pointer shrink-0"
                                        >
                                          {task.status === "completed" ? (
                                            <CheckCircle2 size={16} className="text-blue-500 fill-blue-500/10" />
                                          ) : (
                                            <div className="w-4 h-4 rounded-full border border-white/30 hover:border-blue-400 transition-colors" />
                                          )}
                                        </button>
                                        <div className="min-w-0 flex-1">
                                          <span className={`text-xs font-bold leading-relaxed block ${task.status === "completed" ? "line-through text-white/30" : "text-white/80"}`}>
                                            {task.title}
                                          </span>
                                          {task.notes && (
                                            <p className={`text-[10px] mt-0.5 leading-relaxed truncate ${task.status === "completed" ? "text-white/10" : "text-white/40"}`}>{task.notes}</p>
                                          )}
                                        </div>
                                      </div>

                                      <button 
                                        onClick={() => { setTgtDeleteTask(task); setConfirmDeleteTaskOpen(true); }}
                                        className="p-1.5 rounded-lg bg-red-500/10 border border-red-500/15 hover:bg-red-500 hover:text-white text-red-400 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer shrink-0 ml-4"
                                      >
                                        <Trash2 size={12} />
                                      </button>
                                    </div>
                                  ))
                                )}
                              </div>
                            </div>

                            {/* Create task inline panel */}
                            <form onSubmit={handleCreateTaskSubmit} className="pt-6 border-t border-white/5 mt-4 shrink-0 col-span-1">
                              <span className="text-[10px] font-mono uppercase tracking-wider text-white/40 block pb-2">Sync Task Node</span>
                              <div className="flex flex-col sm:flex-row gap-2">
                                <input 
                                  type="text"
                                  value={newTaskTitle}
                                  onChange={(e) => setNewTaskTitle(e.target.value)}
                                  placeholder="Task Title (e.g. Code feature A)"
                                  className="flex-1 bg-white/[0.02] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-blue-500/40"
                                />
                                <input 
                                  type="text"
                                  value={newTaskNotes}
                                  onChange={(e) => setNewTaskNotes(e.target.value)}
                                  placeholder="Notes/Subtitles (optional)"
                                  className="flex-1 bg-white/[0.02] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-blue-500/40"
                                />
                                <button
                                  type="submit"
                                  disabled={!newTaskTitle.trim()}
                                  className="px-5 py-2.5 bg-gradient-to-tr from-blue-500 to-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg flex items-center justify-center gap-1 cursor-pointer disabled:opacity-40"
                                >
                                  Add Task
                                </button>
                              </div>
                            </form>

                          </div>
                        ) : (
                          <div className="flex-1 flex flex-col items-center justify-center text-center group h-full opacity-45">
                            <CheckSquare size={40} className="mb-2" />
                            <p className="text-xs">Select Tasklist Node to Initialize Board.</p>
                          </div>
                        )}
                      </div>

                    </div>
                  )}

                  {/* =======================================================
                      MODULE 5: GOOGLE CONTACTS (PEOPLE API) VIEW
                      ======================================================= */}
                  {activeSystem === "contacts" && (
                    <div className="flex-1 flex flex-col overflow-hidden">
                      <div className="p-5 border-b border-white/5 bg-white/[0.01] flex flex-wrap items-center justify-between gap-4">
                        <div className="flex items-center gap-3 w-full sm:w-auto">
                          <div className="relative w-full sm:w-64">
                            <input
                              type="text"
                              value={contactSearch}
                              onChange={(e) => setContactSearch(e.target.value)}
                              placeholder="Search connections..."
                              className="w-full bg-white/[0.02] border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white focus:outline-none focus:border-purple-500/40"
                            />
                            <Search size={13} className="absolute left-3.5 top-3.5 text-white/40" />
                          </div>
                        </div>

                        <button
                          onClick={() => setShowAddContact(true)}
                          className="px-4 py-2 bg-gradient-to-tr from-purple-500 to-fuchsia-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-purple-500/10 flex items-center gap-2 hover:scale-[1.02] cursor-pointer"
                        >
                          <UserPlus size={13} />
                          Add Connection
                        </button>
                      </div>

                      <div className="flex-1 overflow-y-auto p-6 md:p-8">
                        {loading && contacts.length === 0 ? (
                          <div className="flex h-full items-center justify-center">
                            <Loader2 className="text-white/30" size={24} />
                          </div>
                        ) : filteredContacts.length === 0 ? (
                          <div className="flex flex-col h-full items-center justify-center text-center">
                            <Users size={42} className="text-white/10 mb-3" />
                            <h4 className="text-xs font-bold text-white/60">No Connections Found</h4>
                            <p className="text-[10px] text-white/30 mt-1">Make a safe add request of contact to link phone networks.</p>
                          </div>
                        ) : (
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {filteredContacts.map((contact) => (
                              <div 
                                key={contact.resourceName}
                                className="border border-white/5 bg-white/[0.01] rounded-2xl p-4 flex flex-col justify-between hover:bg-white/[0.03] transition-all group"
                              >
                                <div className="flex items-center gap-3">
                                  <div className="w-10 h-10 rounded-full border border-white/10 bg-white/5 overflow-hidden flex items-center justify-center text-xs font-bold shrink-0">
                                    {contact.avatarUrl ? (
                                      <img src={contact.avatarUrl} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                    ) : (
                                      contact.name?.charAt(0) || "U"
                                    )}
                                  </div>
                                  <div className="min-w-0 flex-1">
                                    <h4 className="text-xs font-black text-white truncate">{contact.name}</h4>
                                    {contact.email && <p className="text-[10px] text-white/50 truncate font-mono">{contact.email}</p>}
                                    {contact.phone && <p className="text-[10px] text-white/35 truncate font-mono mt-0.5">{contact.phone}</p>}
                                  </div>
                                </div>

                                <div className="flex justify-end mt-4 border-t border-white/[0.03] pt-3">
                                  <button
                                    onClick={() => { setTgtDeleteContact(contact); setConfirmDeleteContactOpen(true); }}
                                    className="p-1 px-3 bg-red-500/5 hover:bg-red-500/15 text-red-400 border border-red-500/15 rounded-lg text-[10px] font-semibold flex items-center gap-1 hover:text-white transition-all cursor-pointer"
                                    title="Delete contact connection"
                                  >
                                    <Trash2 size={11} /> Delete
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {activeSystem === "sheets" && (
                    <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
                      {/* Left Sidebar: Lists Spreadsheets */}
                      <div className="w-full md:w-80 bg-black/20 border-r border-white/5 flex flex-col p-4 shrink-0 overflow-hidden">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-2">
                            <FileSpreadsheet className="text-[#0F9D58]" size={18} />
                            <h3 className="text-xs font-black uppercase tracking-wider text-emerald-400 font-sans">Spreadsheets (স্প্রেডশিট)</h3>
                          </div>
                          <button
                            onClick={() => {
                              setNewSpreadsheetTitle("");
                              setShowCreateSpreadsheet(true);
                            }}
                            className="p-1.5 bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600/30 rounded-xl flex items-center gap-1 text-[10px] font-bold border border-emerald-500/20 transition-all cursor-pointer"
                          >
                            <Plus size={12} /> Create
                          </button>
                        </div>

                        {/* Search spreadsheet bar */}
                        <div className="relative mb-4 font-sans">
                          <input
                            type="text"
                            value={spreadsheetSearch}
                            onChange={(e) => setSpreadsheetSearch(e.target.value)}
                            placeholder="Search spreadsheets..."
                            className="w-full bg-white/[0.02] border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white focus:outline-none focus:border-emerald-500/40"
                          />
                          <Search size={13} className="absolute left-3.5 top-3.5 text-white/40" />
                        </div>

                        {/* List items */}
                        <div className="flex-1 overflow-y-auto space-y-2 pr-1 font-sans">
                          {loading && spreadsheets.length === 0 ? (
                            <div className="flex py-10 items-center justify-center">
                              <Loader2 className="text-emerald-500/30" size={20} />
                            </div>
                          ) : spreadsheets.length === 0 ? (
                            <div className="text-center py-10 opacity-40">
                              <p className="text-xs">No spreadsheets found.</p>
                            </div>
                          ) : (
                            spreadsheets.map((sheet) => {
                              const isActive = activeSpreadsheet?.id === sheet.id;
                              return (
                                <button
                                  key={sheet.id}
                                  onClick={() => handleSelectSpreadsheet(sheet)}
                                  className={`w-full text-left p-3.5 rounded-2xl border transition-all flex flex-col gap-1 cursor-pointer hover:border-emerald-500/20 ${
                                    isActive
                                      ? "bg-emerald-950/15 border-emerald-500/35 text-white"
                                      : "bg-white/[0.01] border-white/5 text-white/70 hover:bg-white/[0.03]"
                                  }`}
                                >
                                  <div className="flex items-start justify-between gap-2">
                                    <span className="text-xs font-bold leading-tight line-clamp-2">{sheet.name}</span>
                                    {sheet.webViewLink && (
                                      <a
                                        href={sheet.webViewLink}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        onClick={(e) => e.stopPropagation()}
                                        className="p-1 hover:bg-white/10 rounded-lg text-white/40 hover:text-white transition-colors"
                                        title="Open in Google Sheets"
                                      >
                                        <ExternalLink size={11} />
                                      </a>
                                    )}
                                  </div>
                                  <span className="text-[9px] text-white/35 font-mono">
                                    Modified: {new Date(sheet.modifiedTime).toLocaleDateString()}
                                  </span>
                                </button>
                              );
                            })
                          )}
                        </div>
                      </div>

                      {/* Right Panel: Content grid and updates */}
                      <div className="flex-1 flex flex-col bg-stone-950/20 overflow-hidden font-sans">
                        {activeSpreadsheet ? (
                          <div className="flex-1 flex flex-col overflow-hidden">
                            {/* Panel Header */}
                            <div className="p-4 bg-white/[0.01] border-b border-white/5 flex flex-wrap items-center justify-between gap-4">
                              <div className="min-w-0 flex-1">
                                <div className="flex items-center gap-2">
                                  <h4 className="text-sm font-black text-white truncate">{activeSpreadsheet.name}</h4>
                                  {activeSpreadsheet.webViewLink && (
                                    <a
                                      href={activeSpreadsheet.webViewLink}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="p-1 hover:bg-white/10 rounded-lg text-[#0F9D58] hover:text-white transition-colors flex items-center gap-1 text-[10px] font-semibold"
                                    >
                                      Go to Web <ExternalLink size={10} />
                                    </a>
                                  )}
                                </div>
                                <p className="text-[10px] text-white/40 mt-1 uppercase tracking-widest font-mono">
                                  Spreadsheet Workspace
                                </p>
                              </div>

                              {/* Sync and Tab listing */}
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => handleSelectSpreadsheet(activeSpreadsheet)}
                                  className="p-2 hover:bg-white/5 rounded-xl text-white/55 hover:text-white transition-all border border-white/5 cursor-pointer flex items-center gap-1.5 text-xs font-semibold"
                                  title="Refresh Sheet Values"
                                >
                                  <RefreshCw size={12} className={loadingSheetData ? "animate-spin text-emerald-400" : ""} />
                                  Reload
                                </button>
                              </div>
                            </div>

                            {/* Spreadsheet Tabs Row */}
                            {spreadsheetDetail && spreadsheetDetail.sheets.length > 0 && (
                              <div className="px-4 py-2 bg-black/10 border-b border-white/5 flex items-center gap-2 overflow-x-auto">
                                <span className="text-[10px] font-mono text-white/30 uppercase tracking-wider shrink-0 mr-1">Tabs:</span>
                                {spreadsheetDetail.sheets.map((tab) => {
                                  const isTabActive = activeTab === tab.title;
                                  return (
                                    <button
                                      key={tab.title}
                                      onClick={() => handleTabChange(tab.title)}
                                      className={`px-3 py-1.5 rounded-xl text-[11px] font-bold border transition-all cursor-pointer whitespace-nowrap ${
                                        isTabActive
                                          ? "bg-emerald-500/10 border-emerald-500/35 text-emerald-400"
                                          : "bg-white/[0.01] border-white/5 text-white/50 hover:bg-white/10 hover:text-white"
                                      }`}
                                    >
                                      {tab.title}
                                    </button>
                                  );
                                })}
                              </div>
                            )}

                            {/* Quick Add Row & Live Interactive Table Container */}
                            <div className="flex-1 overflow-auto p-4 md:p-6 space-y-6">
                              {/* Quick Append Row Board */}
                              {activeTab && (
                                <div className="bg-[#0b100d] border border-emerald-500/10 rounded-2xl p-4 md:p-5 shadow-lg space-y-3.5">
                                  <div className="flex items-center gap-2">
                                    <Plus className="text-emerald-400" size={14} />
                                    <span className="text-xs font-extrabold text-emerald-400 uppercase tracking-widest">
                                      Quick Append Row (নতুন রো যোগ করুন)
                                    </span>
                                  </div>
                                  <form onSubmit={handleAppendRow} className="flex gap-2.5 items-center flex-wrap sm:flex-nowrap">
                                    <input
                                      type="text"
                                      value={newRowInput}
                                      onChange={(e) => setNewRowInput(e.target.value)}
                                      placeholder="Value1, Value2, Value3, Value4... (Comma separated values)"
                                      className="flex-1 min-w-[200px] bg-white/[0.01] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500/40 font-sans"
                                    />
                                    <button
                                      type="submit"
                                      disabled={!newRowInput.trim()}
                                      className="px-5 py-2.5 bg-gradient-to-tr from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white rounded-xl text-xs font-bold shadow-md flex items-center justify-center gap-1 cursor-pointer disabled:opacity-45 h-10 shrink-0 uppercase tracking-wider font-mono text-[10px]"
                                    >
                                      Append Row
                                    </button>
                                  </form>
                                  <p className="text-[10px] text-white/35">
                                    Adds a new row of data at the end of tab <b>"{activeTab}"</b> automatically matching spreadsheet formatting.
                                  </p>
                                </div>
                              )}

                              {/* Interactive Cell Grid Table */}
                              <div className="bg-[#0d0d0e] border border-white/5 rounded-2xl overflow-hidden shadow-2xl">
                                <div className="p-4 border-b border-white/5 bg-white/[0.01] flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    <Table size={14} className="text-emerald-500" />
                                    <span className="text-xs font-bold text-white uppercase tracking-wider font-sans">
                                      Active Grid Viewer (Editable A1-Z50)
                                    </span>
                                  </div>
                                  <span className="text-[9px] font-mono text-white/30 uppercase tracking-wider">
                                    Click cell to Edit online
                                  </span>
                                </div>

                                {loadingSheetData ? (
                                  <div className="flex py-16 justify-center">
                                    <Loader2 className="animate-spin text-emerald-500" size={24} />
                                  </div>
                                ) : sheetValues.length === 0 ? (
                                  <div className="text-center py-16 px-4">
                                    <p className="text-xs text-white/50">This sheet does not have any populated values.</p>
                                    <p className="text-[10px] text-white/30 mt-1">Use "Quick Append Row" section above to initialize some data.</p>
                                  </div>
                                ) : (
                                  <div className="overflow-x-auto">
                                    <table className="w-full border-collapse text-left font-sans select-none">
                                      <thead>
                                        <tr className="border-b border-white/5 bg-white/[0.01] text-[10px] uppercase font-mono text-white/30">
                                          <th className="px-3.5 py-2 border-r border-white/5 w-12 text-center flex-row md:flex-col">Row</th>
                                          {Array.from({ length: Math.max(...sheetValues.map(r => r.length), 4) }).map((_, cIdx) => (
                                            <th key={cIdx} className="px-4 py-2 border-r border-white/5">
                                              {String.fromCharCode(65 + cIdx)}
                                            </th>
                                          ))}
                                        </tr>
                                      </thead>
                                      <tbody>
                                        {sheetValues.map((row, rIdx) => (
                                          <tr key={rIdx} className="border-b border-white/5 hover:bg-white/[0.01] transition-colors text-xs text-white/80">
                                            <td className="px-3.5 py-2.5 border-r border-white/5 bg-white/[0.01] text-center font-mono font-bold text-white/30">
                                              {rIdx + 1}
                                            </td>
                                            {Array.from({ length: Math.max(...sheetValues.map(r => r.length), 4) }).map((_, cIdx) => {
                                              const cellVal = row[cIdx] || "";
                                              const isEditing = editingCell?.r === rIdx && editingCell?.c === cIdx;
                                              return (
                                                <td
                                                  key={cIdx}
                                                  onClick={() => !isEditing && handleCellClick(rIdx, cIdx, cellVal)}
                                                  className="px-4 py-2.5 border-r border-white/5 relative min-w-[120px] max-w-[240px] truncate hover:bg-emerald-500/5 hover:text-white transition-colors cursor-pointer group"
                                                >
                                                  {isEditing ? (
                                                    <div className="absolute inset-0 bg-stone-900 border border-emerald-500 p-1 z-10 flex items-center gap-1.5 shadow-2xl">
                                                      <input
                                                        type="text"
                                                        value={editingCell.current}
                                                        onChange={(e) => setEditingCell(prev => prev ? { ...prev, current: e.target.value } : null)}
                                                        onKeyDown={(e) => {
                                                          if (e.key === "Enter") handleSaveCellEdit();
                                                          if (e.key === "Escape") setEditingCell(null);
                                                        }}
                                                        autoFocus
                                                        className="w-full h-full bg-transparent text-white focus:outline-none text-xs px-2"
                                                      />
                                                      <button
                                                        onClick={(e) => { e.stopPropagation(); handleSaveCellEdit(); }}
                                                        className="p-1 text-emerald-400 hover:bg-emerald-500/10 rounded cursor-pointer"
                                                      >
                                                        <Check size={12} />
                                                      </button>
                                                      <button
                                                        onClick={(e) => { e.stopPropagation(); setEditingCell(null); }}
                                                        className="p-1 text-red-400 hover:bg-red-500/10 rounded cursor-pointer"
                                                      >
                                                        <X size={12} />
                                                      </button>
                                                    </div>
                                                  ) : (
                                                    <span className="block w-full min-h-[16px]">{cellVal}</span>
                                                  )}
                                                </td>
                                              );
                                            })}
                                          </tr>
                                        ))}
                                      </tbody>
                                    </table>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div className="flex-1 flex flex-col items-center justify-center text-center opacity-45 px-6">
                            <FileSpreadsheet size={48} className="text-[#0F9D58] mb-3" />
                            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-sans">Google Sheets Workroom</h4>
                            <p className="text-xs text-white/50 max-w-sm mt-1.5 leading-relaxed font-sans">
                              Select a spreadsheet file from the sidebar roster or create a new blank workspace with Mimi to begin editing cells!
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                </div>
              )}

              {/* Toast message overlays */}
              <AnimatePresence>
                {statusNotice && (
                  <motion.div
                    initial={{ opacity: 0, y: 15, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className={`absolute bottom-6 left-1/2 -translate-x-1/2 z-[80] px-5 py-3 rounded-2xl border text-xs font-semibold shadow-xl flex items-center gap-3 backdrop-blur-xl ${
                      statusNotice.type === "error" 
                        ? "bg-red-950/85 border-red-500/30 text-red-200 shadow-red-950/20" 
                        : statusNotice.type === "success"
                        ? "bg-emerald-950/85 border-emerald-500/30 text-emerald-200 shadow-emerald-950/20"
                        : "bg-zinc-900/90 border-zinc-700/55 text-zinc-100 shadow-black/40"
                    }`}
                  >
                    <span>{statusNotice.text}</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* =======================================================
          MODAL SAFEGARDS: SYSTEM DOUBLE-CONFIRMATIONS
          ======================================================= */}
      
      {/* 1. Gmail Dispatch Confirmation */}
      <AnimatePresence>
        {confirmSendOpen && (
          <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 cursor-default pointer-events-auto">
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="w-full max-w-md bg-[#0e0e11] border border-red-500/20 p-6 rounded-2xl shadow-2xl space-y-5 text-white"
            >
              <div className="flex items-center gap-3 text-red-400">
                <AlertTriangle size={24} className="shrink-0" />
                <h4 className="text-sm font-black uppercase tracking-wider">Authorize Gmail Dispatch</h4>
              </div>
              <div className="space-y-3.5 text-xs text-white/70 leading-relaxed bg-white/[0.01] border border-white/5 p-4 rounded-xl">
                <p>Are you sure you want to dispatch a real Google Mail email to the recipient below?</p>
                <div className="space-y-1 pl-3 border-l border-red-500/30 text-[11px] font-mono text-white/50">
                  <p><span className="text-white/30">To:</span> {composeTo}</p>
                  <p><span className="text-white/30">Subj:</span> {composeSubject}</p>
                </div>
              </div>
              <div className="flex gap-2 justify-end">
                <button
                  onClick={() => setConfirmSendOpen(false)}
                  className="px-4 py-2 bg-white/5 border border-white/10 text-white/70 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={executeSendEmail}
                  className="px-5 py-2 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-bold shadow-lg"
                >
                  Confirm Dispatch
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 2. Gmail Trash Confirmation */}
      <AnimatePresence>
        {confirmTrashOpen && tgtTrashMessage && (
          <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 cursor-default pointer-events-auto">
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="w-full max-w-md bg-[#0e0e11] border border-red-500/20 p-6 rounded-2xl shadow-2xl space-y-5 text-white"
            >
              <div className="flex items-center gap-3 text-red-500">
                <AlertCircle size={24} />
                <h4 className="text-sm font-black uppercase tracking-wider">Trash Email Node</h4>
              </div>
              <p className="text-xs text-white/70">Move email "{tgtTrashMessage.subject}" to Trash folder?</p>
              <div className="flex gap-2 justify-end">
                <button onClick={() => setConfirmTrashOpen(false)} className="px-4 py-2 bg-white/5 text-white/70 rounded-lg text-xs">Cancel</button>
                <button onClick={executeTrashMessage} className="px-5 py-2 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-bold">Trash</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 3. Drive File Delete Confirmation */}
      <AnimatePresence>
        {confirmTrashDriveOpen && tgtTrashDriveFile && (
          <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 cursor-default pointer-events-auto">
            <motion.div
              is="modal"
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="w-full max-w-md bg-[#0e0e11] border border-red-500/20 p-6 rounded-2xl shadow-2xl space-y-5 text-white"
            >
              <div className="flex items-center gap-3 text-red-500">
                <AlertTriangle size={24} />
                <h4 className="text-sm font-black uppercase tracking-wider text-red-400">Delete Drive File</h4>
              </div>
              <p className="text-xs text-white/70">Are you sure you want to delete <b className="text-white font-mono break-all">"{tgtTrashDriveFile.name}"</b> from Google Drive? This is irreversible.</p>
              <div className="flex gap-2 justify-end">
                <button onClick={() => setConfirmTrashDriveOpen(false)} className="px-4 py-2 bg-white/5 text-white/70 rounded-lg text-xs">Cancel</button>
                <button onClick={executeDeleteDriveFile} className="px-5 py-2 bg-red-600 text-white rounded-lg text-xs font-bold hover:bg-red-500">Confirm Delete</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 4. Google Task Delete Confirmation */}
      <AnimatePresence>
        {confirmDeleteTaskOpen && tgtDeleteTask && (
          <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 cursor-default pointer-events-auto">
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="w-full max-w-md bg-[#0e0e11] border border-red-500/20 p-6 rounded-2xl shadow-2xl space-y-5 text-white"
            >
              <div className="flex items-center gap-3 text-red-500">
                <AlertCircle size={24} />
                <h4 className="text-sm font-black uppercase tracking-wider">Delete Task Node</h4>
              </div>
              <p className="text-xs text-white/70">Remove task <b className="text-white font-mono">"{tgtDeleteTask.title}"</b> forever?</p>
              <div className="flex gap-2 justify-end">
                <button onClick={() => setConfirmDeleteTaskOpen(false)} className="px-4 py-2 bg-white/5 text-white/70 rounded-lg text-xs">Cancel</button>
                <button onClick={executeDeleteTask} className="px-5 py-2 bg-red-600 text-white rounded-lg text-xs font-bold hover:bg-red-500">Delete</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 5. Google Contacts Delete Confirmation */}
      <AnimatePresence>
        {confirmDeleteContactOpen && tgtDeleteContact && (
          <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 cursor-default pointer-events-auto">
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="w-full max-w-md bg-[#0e0e11] border border-red-500/20 p-6 rounded-2xl shadow-2xl space-y-5 text-white"
            >
              <div className="flex items-center gap-3 text-red-500">
                <AlertTriangle size={24} />
                <h4 className="text-sm font-black uppercase tracking-wider text-red-400">Delete Contact Node</h4>
              </div>
              <p className="text-xs text-white/70">Delete connection for <b className="text-white">"{tgtDeleteContact.name}"</b>? It will completely erase their email/phone from Google People roster.</p>
              <div className="flex gap-2 justify-end">
                <button onClick={() => setConfirmDeleteContactOpen(false)} className="px-4 py-2 bg-white/5 text-white/70 rounded-lg text-xs">Cancel</button>
                <button onClick={executeDeleteContact} className="px-5 py-2 bg-red-600 text-white rounded-lg text-xs font-bold hover:bg-red-500">Delete Connection</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 6. Google Contacts Create Overlay form */}
      <AnimatePresence>
        {showAddContact && (
          <div className="fixed inset-0 z-[90] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 cursor-default pointer-events-auto">
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="w-full max-w-md bg-[#0b0b0d] border border-white/10 rounded-2xl p-6 shadow-2xl text-white space-y-5"
            >
              <div className="flex items-center justify-between border-b border-white/5 pb-3">
                <h3 className="text-xs font-black uppercase text-purple-400 tracking-wide">Sync Contact Connection</h3>
                <button onClick={() => setShowAddContact(false)} className="p-1 rounded-full bg-white/5 text-white/60 hover:text-white cursor-pointer hover:bg-white/10">
                  <X size={14} />
                </button>
              </div>

              <form onSubmit={handleCreateContactSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-3.5">
                  <div className="space-y-1.5">
                    <label className="text-[9px] font-mono uppercase text-white/40">First Name</label>
                    <input 
                      type="text" 
                      required
                      value={newContactFirstName} 
                      onChange={(e) => setNewContactFirstName(e.target.value)}
                      className="w-full bg-white/[0.02] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-purple-500/40"
                      placeholder="Kabir"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[9px] font-mono uppercase text-white/40">Last Name</label>
                    <input 
                      type="text" 
                      value={newContactLastName} 
                      onChange={(e) => setNewContactLastName(e.target.value)}
                      className="w-full bg-white/[0.02] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-purple-500/40"
                      placeholder="Siddique"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono uppercase text-white/40">Email Address</label>
                  <input 
                    type="email" 
                    value={newContactEmail} 
                    onChange={(e) => setNewContactEmail(e.target.value)}
                    className="w-full bg-white/[0.02] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-purple-500/40"
                    placeholder="kabir.sidd@email.com"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono uppercase text-white/40">Phone number</label>
                  <input 
                    type="text" 
                    value={newContactPhone} 
                    onChange={(e) => setNewContactPhone(e.target.value)}
                    className="w-full bg-white/[0.02] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-purple-500/40"
                    placeholder="+8801700000000"
                  />
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-gradient-to-tr from-purple-500 to-fuchsia-500 rounded-xl text-xs font-bold text-white shadow-xl flex items-center gap-1.5 cursor-pointer hover:scale-[1.01]"
                  >
                    Save Contact
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 5. Create Google Spreadsheet Modal */}
      <AnimatePresence>
        {showCreateSpreadsheet && (
          <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 cursor-default pointer-events-auto">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md bg-[#0e0e11] border border-emerald-500/20 p-6 rounded-3xl shadow-2xl space-y-5 text-white"
            >
              <div className="flex items-center justify-between pb-3 border-b border-white/5">
                <div className="flex items-center gap-2 text-emerald-400">
                  <FileSpreadsheet size={20} />
                  <h4 className="text-xs font-black uppercase tracking-wider font-sans">Create Google Spreadsheet (নতুন স্প্রেডশিট)</h4>
                </div>
                <button
                  onClick={() => setShowCreateSpreadsheet(false)}
                  className="p-1 hover:bg-white/5 rounded-lg text-white/40 hover:text-white transition-colors cursor-pointer"
                >
                  <X size={14} />
                </button>
              </div>

              <form onSubmit={handleCreateNewSpreadsheet} className="space-y-4">
                <div className="space-y-1.5 font-sans">
                  <label className="text-[9px] font-mono uppercase text-white/40">Spreadsheet Title</label>
                  <input
                    type="text"
                    required
                    value={newSpreadsheetTitle}
                    onChange={(e) => setNewSpreadsheetTitle(e.target.value)}
                    className="w-full bg-white/[0.02] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500/40"
                    placeholder="e.g. Finance Ledger 2026, Customer Registry"
                  />
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="submit"
                    disabled={!newSpreadsheetTitle.trim() || isCreatingSpreadsheet}
                    className="px-5 py-2.5 bg-gradient-to-tr from-emerald-600 to-green-600 rounded-xl text-xs font-bold text-white shadow-xl flex items-center gap-1.5 cursor-pointer hover:scale-[1.01] disabled:opacity-40"
                  >
                    {isCreatingSpreadsheet ? <Loader2 size={13} className="animate-spin" /> : null}
                    Create Spreadsheet
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}

function Loader2({ className, size }: { className?: string; size?: number }) {
  return (
    <svg 
      className={`animate-spin ${className}`} 
      style={{ width: size, height: size }} 
      xmlns="http://www.w3.org/2000/svg" 
      fill="none" 
      viewBox="0 0 24 24"
    >
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
  );
}
