/**
 * Utility for detecting mood sentiment from user's input text or speech,
 * with comprehensive support for sad words, cheerful, sassy, and serious emotions.
 */

export type MoodSentiment = "cheerful" | "sassy" | "serious" | "sad";

// Latest Sad Words dictionary in English, Bengali, and Hinglish
export const SAD_KEYWORDS = [
  // English words
  "sad", "saddened", "sadness", "unhappy", "depressed", "depression", "crying", "cry",
  "tears", "tearful", "heartbroken", "heartbreak", "broken", "lonely", "alone",
  "sorrow", "grief", "pain", "hurt", "hopeless", "lost", "tired of life", "exhausted",
  "miserable", "down", "upset", "melancholy", "gloom", "gloomy", "heavy heart",
  "missing you", "breakup", "rejected", "regret", "weeping", "sobbing", "despair",
  "worthless", "nobody loves me", "suicidal", "hurting", "agony", "suffering",
  
  // Bengali words
  "kharap lagche", "mon kharap", "kosto", "dukhi", "dukkho", "kanna", "kadchi", "ekla",
  "bhalo lagche na", "mon bhalo nei", "bhenge porchi", "buk fate", "bedona", "hataash",
  "nirash", "moron", "shantona", "bhoy korche", "ekaki", "shunyo", "mon kharap keno",
  "moner kosto", "chokhe jol", "chokher pani", "boka lagche", "osustho", "bhalo nei",
  "খারাপ লাগছে", "মন খারাপ", "কষ্ট", "দুঃখ", "কান্না", "কাঁদছি", "একলা", "ভালো লাগছে না",
  "মন ভালো নেই", "ভেঙে পড়ছি", "হতাশ", "হতাশা", "বেদনা", "শূন্যতা", "কান্না পাচ্ছে",

  // Hinglish
  "dard", "rona aa raha hai", "udaas", "udas", "tanha", "gham", "dil toot gaya", "pareshaan"
];

export function detectMoodSentiment(text: string): MoodSentiment {
  const normalized = text.toLowerCase().trim();

  const sadKeywords = SAD_KEYWORDS;

  const seriousKeywords = [
    "serious", "seriously", "debug", "code", "error", "problem", "fix", "run", "test",
    "important", "urgent", "help", "work", "job", "study", "exam", "report", "fail", "failed",
    "gombhir", "baje", "tension", "scared", "fear", "anxious", "sorry", "kotha"
  ];

  const sassyKeywords = [
    "sassy", "tease", "roast", "attitude", "whatever", "boring", "really", "possessive",
    "drama", "jealous", "funny", "witty", "joke", "sarcastic", "sarcasm", "chup", "faltu",
    "pagol", "shona", "jan", "babe", "dumb", "stupid", "silly", "shut up", "bored"
  ];

  const cheerfulKeywords = [
    "cheerful", "happy", "excited", "joy", "cheer", "glad", "awesome", "great", "nice",
    "smile", "fun", "good", "perfect", "amazing", "beautiful", "yay", "haha", "hehe",
    "lol", "bhalo", "khushi", "anondo", "shundor", "mishti", "sweet", "love", "cute"
  ];

  // 1. Calculate matching scores
  let sadScore = 0;
  let seriousScore = 0;
  let sassyScore = 0;
  let cheerfulScore = 0;

  for (const word of sadKeywords) {
    if (normalized.includes(word.toLowerCase())) sadScore += 2.0; // Higher weight for sadness so Mimi can comfort immediately
  }
  for (const word of seriousKeywords) {
    if (normalized.includes(word)) seriousScore += 1;
  }
  for (const word of sassyKeywords) {
    if (normalized.includes(word)) sassyScore += 1;
  }
  for (const word of cheerfulKeywords) {
    if (normalized.includes(word)) cheerfulScore += 1;
  }

  // Emoji detection
  if (/[\uD800-\uDFFF].*[😢😭🥺💔😿😞😔🙁😥🖤🥀]/.test(normalized)) {
    sadScore += 3.0;
  }
  if (/[\uD800-\uDFFF].*[😊😀😁🌟🎉✨💖❤️🌸👑🍰🧸🥂]/.test(normalized)) {
    cheerfulScore += 1.5;
  }
  if (/[\uD800-\uDFFF].*[😜🤪😎😏🙄💅🔥😈😹🤦‍♀️🤦‍♂️]/.test(normalized)) {
    sassyScore += 1.5;
  }
  if (/[\uD800-\uDFFF].*[🛑⚠️🚨🔍🧠📋💻💼📁📊]/.test(normalized)) {
    seriousScore += 1.5;
  }

  // 2. Select highest score
  const maxScore = Math.max(sadScore, cheerfulScore, sassyScore, seriousScore);

  if (maxScore === 0) {
    return "cheerful";
  }

  if (maxScore === sadScore) return "sad";
  if (maxScore === cheerfulScore) return "cheerful";
  if (maxScore === sassyScore) return "sassy";
  return "serious";
}
