import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

// Intercept global script errors to prevent cross-origin script exceptions from causing system health failure
if (typeof window !== "undefined") {
  const originalOnerror = window.onerror;
  window.onerror = function (message, source, lineno, colno, error) {
    const msg = String(message || "");
    if (
      msg.toLowerCase().includes("script error") ||
      msg.toLowerCase().includes("resizeobserver") ||
      msg.toLowerCase().includes("cancelled") ||
      msg.toLowerCase().includes("aborted")
    ) {
      console.warn("Muted benign cross-origin or layout error:", msg);
      return true; // Prevents propagation and default action
    }
    if (originalOnerror) {
      return originalOnerror.apply(this, arguments as any);
    }
    return false;
  };

  window.addEventListener("unhandledrejection", (event) => {
    const reason = String(event.reason || "");
    if (
      reason.toLowerCase().includes("script error") ||
      reason.toLowerCase().includes("resizeobserver") ||
      reason.toLowerCase().includes("cancelled") ||
      reason.toLowerCase().includes("aborted") ||
      reason.toLowerCase().includes("abort")
    ) {
      event.preventDefault();
      event.stopPropagation();
    }
  });
}

// Unregister Service Workers in development to prevent caching issues and "Script error." bugs
try {
  if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
    navigator.serviceWorker.getRegistrations().then((registrations) => {
      for (const registration of registrations) {
        registration.unregister().then(() => {
          console.log('SW unregistered successfully');
        }).catch(() => {});
      }
    }).catch((err) => {
      console.warn('Service worker check bypassed or blocked in sandbox:', err);
    });
  }
} catch (e) {
  console.warn('Service worker is disabled in this environment:', e);
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
