# Mimi AI — Upgrade Notes

## Existing architecture retained
This is the original React + TypeScript + Vite + Express + Gemini project. The existing Live voice bridge, Firebase history, command services and UI are retained. The upgrade adds a real server-side multi-provider parallel endpoint and an Android/Capacitor configuration starting point.

## Multi-AI Parallel Brain
Set provider credentials in the server environment (never in browser code or committed files):
- `GEMINI_API_KEY` — Gemini responses and central synthesis (recommended)
- `OPENAI_API_KEY` / optional `OPENAI_MODEL`
- `ANTHROPIC_API_KEY` / optional `ANTHROPIC_MODEL`
- `DEEPSEEK_API_KEY` / optional `DEEPSEEK_MODEL`
- `GROK_API_KEY` / optional `GROK_MODEL`

The model picker includes **Mimi Parallel Brain**. Selecting ChatGPT, Claude, DeepSeek, or Grok routes directly to that provider (and fails clearly if its server key is absent). The server concurrently calls every configured provider, records individual failures, and asks Gemini to synthesize successful responses when Gemini is configured. If Gemini is not configured, the server returns a clearly labelled concatenation of successful model responses; it does not pretend this is AI synthesis.

Provider status (no secrets) is available at `GET /api/brain/providers`.
Parallel request endpoint: `POST /api/brain/parallel`. Direct provider endpoint: `POST /api/brain/provider`.
Only providers with server-side keys are available. User-supplied provider keys are not accepted or stored by this implementation. The endpoints include basic in-memory per-IP rate limits; add authentication and a shared production rate limiter before public deployment.

### Run locally
1. Install Node.js 20 or later.
2. Copy `.env.example` to `.env` and add keys for the providers you want.
3. Run `npm install`.
4. Run `npm run dev` and open `http://localhost:3000`.

## Android packaging
The project now contains `capacitor.config.json` targeting the existing Vite `dist` output. Android packaging requires a machine with Android Studio, Android SDK, Java 17+, and network access to install Capacitor packages and Gradle dependencies.

From the project directory:
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
Build the APK in Android Studio using **Build > Build Bundle(s) / APK(s) > Build APK(s)**. This source archive does not contain a generated `android/` Gradle project or a signed APK because the build environment used for this repair does not include Android Studio/SDK. Capacitor sync/build must be completed on an Android development machine.

For native camera/microphone/file access, use Capacitor plugins and request runtime permissions at the point of use. Browser media APIs continue to require HTTPS or localhost. Background wake-word listening and always-on screen capture are not implemented; Android restricts these capabilities and requires native foreground-service design and explicit user consent.

## Known limitations / not claimed as complete
- Only Gemini, OpenAI, Anthropic, DeepSeek and xAI Grok are wired into the parallel endpoint. Other providers and arbitrary custom API schemas need explicit adapters.
- Provider API keys are read from server environment variables; there is no in-app credential vault or UI for adding secrets.
- Central synthesis currently uses Gemini. Without a Gemini key, successful provider outputs are returned separately rather than falsely claiming synthesis.
- The existing live voice bridge is Gemini-specific. The new parallel endpoint is text-chat, not multi-provider realtime audio.
- Screen sharing/video capture depends on browser/platform permission and the upstream Gemini Live API. Full Android native screen capture, foreground audio service, push notifications, and background wake word are not delivered by this web source upgrade.
- Firebase configuration and security rules must be reviewed and configured for the deployment project.
- Do not expose the Express server directly to the public internet without authentication, request throttling, and deployment-specific access controls.
